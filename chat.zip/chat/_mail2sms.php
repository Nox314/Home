<?php

include("chat_config.php");

if (isset($_SESSION["chatuser"])) {


	$user = $_SESSION["chatuser"].' hat den Chat betreten.' ;
	$zeit = date("H:i ");
	$text = $zeit.$user;

	foreach ($sms_empfaenger as $key => $email) {
		$betreff = $text;
		$from = ""; 
		
		$nachricht = '';
		$header = 'From: '.$email . "\r\n" .
		    'Reply-To: '.$email . "\r\n" .
		    'X-Mailer: PHP/' . phpversion();
		
		
		// mail($email, $betreff, $from);
		
		mail($email, $betreff, $nachricht, $header);
	}
}
?>

