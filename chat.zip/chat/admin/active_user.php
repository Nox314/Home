<?php
header('Content-type: text/html; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
	session_start();
}
define('ADMIN_INC', true);
session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird

// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}


if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['access_token'] ?? '')) {
    die("Du hast keinen Zugriff.");
}
?>

<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="admin.css" >
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Aktive User</title>

<style>
	body {
		max-width: 42em;
		margin: auto;
	}
		
	ol {
		/*border: 1px solid #aaa;
		max-width: fit-content;*/
		margin-top:1em;
		padding: 0 2em;
		width: 600px;
		column-count: 3;
	}
	ol li {margin:0;}
	#eintag2, #zeitraum2 {
		border: 0;
		font-weight: bold;
		font-size: 1em;
		width:2.2em;
		outline:none;
		margin:0;
		padding:0;
	}
	
	#zeitraum2 {
		width:2.8em;
	}
	
	input[type=number]::-webkit-inner-spin-button {
	    opacity: 1
	}
		
	@media only screen and (max-width: 600px) {
/*		body {max-width: 90vw;}*/
		ol {
			max-width: calc(100vw - 2em); 
			padding:0 0 0 2em;
			column-count: 2;
		}
		h2, #eintag2, #zeitraum2 { font-size:16px;}
		#eintag2, #zeitraum2 {
			width:unset;
		}
		
	}
	
	</style>

</head>
<body>

<?php

if (isset($_POST["eintag"])) {
	$eintag = $_POST["eintag"];
} else {
	$eintag = 2;
}

if (isset($_POST["zeitraum"])) {
	$zeitraum = $_POST["zeitraum"];
} else {
	$zeitraum = 180;
}

$user_dateiname = "../user/user.txt";
if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);
	$newline4 = [];
	$newline = [];
	foreach($lines as $key => $val) {
		$teile = explode("****", $val);
		if (!isset($teile[4]) || !isset($teile[3])) continue;
		$eintagsfliege = trim($teile[4]);
		
		$date = new DateTime($teile[3]);
		$date2 = $date->getTimestamp();
		
		if (time() - $date2 < $zeitraum * 24 * 3600) {
			$eintagsfliege = str_pad($eintagsfliege,3,"0",STR_PAD_LEFT);
			if ($eintagsfliege >= $eintag && $teile[0] !== "Support" && $teile[0] !== "System") {
				$newline4[] = $eintagsfliege.$teile[0];
			}
		}
	}
	
	rsort($newline4);
	
	foreach($newline4 as $key => $val) {
		$num = substr($val,0,3) + 0;
		$user = substr($val,3);
		if ($zeitraum == 180) {
			$newline[] = '<li>'.$user.' ('.$num.') </li>';
		} else {
			$newline[] = '<li>'.$user.' </li>';
		}
	}
	$line = implode("\n",$newline);
		
	echo '<h1>Aktive User</h1>';
	echo '<form id ="eintag" method="post">';
	echo '<h2 style="margin:0 0 0 0;">User, die an <span style="white-space:nowrap">mindestens ';
	echo '<input autofocus type="number" min="2" max="50" name="eintag" id="eintag2"  onchange=" this.form.submit();" value="'.$eintag.'" >';
	echo 'Tagen, und</span> ';
	echo '<span style="white-space:nowrap"> während der letzten '; 
	echo '<input autofocus type="number" min="1" max="180" name="zeitraum" id="zeitraum2"  onchange=" this.form.submit();" value="'.$zeitraum.'" >';
	echo 'Tage</span>';
	echo ' im Chat waren.</h2>';
	echo '</form>';	
		
	echo '<p style="margin-top:1em">(Gäste ohne Registrierung werden in dieser Statistik nicht erfasst.)</p>';
	echo '<ol>';
	echo $line;
	echo '</ol>';

	
}

include ("admin_inc.php");
	
?>
