<?php
if (!defined('ADMIN_INC')) {
    http_response_code(403);
    exit('Direkter Aufruf nicht erlaubt.');
}

if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

// Sicherstellen, dass die Session aktiv ist
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Kein gültiger Token gefunden.");
}

	
$time_on = time() - $_COOKIE['arrival'];
if (!isset($_COOKIE['arrival']) || $time_on > 60 * 60 *3) {
	echo '<br><p><a class="tochat" href="../login.php">zum Chat-Login</a></p>';
} else {
	echo '<br><p><a class="tochat" href="../chat.php">zum Chat</a></p>';
}



include("../chat_config.php");
if (file_exists("../personal_config_inc.php")) {include("../personal_config_inc.php");}


$a = $_SERVER['SCRIPT_NAME'];

echo '<h2>Weitere Admin Tools</h2>';


echo '<ul class="weitere">';

if (strpos($a,'admin.php')!==false) {
	echo '<li>Registrierungs-Verwaltung zeilenweise</li>';
} else {
	echo '<li><a href="admin.php?token='.urlencode($_SESSION['access_token']).'">Registrierungs-Verwaltung zeilenweise</a></li>';
}

if (strpos($a,'admin_reg.php')!==false) {
	echo '<li>Registrierung Batch-Bereinigung</li>';
} else {
	echo '<li><a href="admin_reg.php">Registrierung Batch-Bereinigung</a></li>';
}

// if (strpos($a,'clean_user.php')!==false) {
// 	echo '<li>Alle Registrierungen letzter Besuch &auml;lter als 180 Tage l&ouml;schen OHNE R&Uuml;CKFRAGE! </li>';
// } else {
// 	echo '<li><a href="clean_user.php">Alle Registrierungen letzter Besuch &auml;lter als 180 Tage l&ouml;schen OHNE R&Uuml;CKFRAGE!</a></li>';
// }

if (file_exists("gema_q.php")) {
	echo '<li>Info: <a href="gema_q.php?token='.urlencode($_SESSION['access_token']).'">Gestreamte mp3</a></li>';
}

if (file_exists("uo_chart.php")) {
	if (strpos($a,'uo_chart.php')!==false) {
		echo '<li>Info: User online Statistik</li>';
	} else {
		echo '<li>Info: <a href="uo_chart.php?token='.urlencode($_SESSION['access_token']).'">User online Statistik</a></li>';
	}
}

if (file_exists("active_user.php")) {
	if (strpos($a,'active_user.php')!==false) {
		echo '<li>Info: Aktive User (Statistik)</li>';
	} else {
		echo '<li>Info: <a href="active_user.php?token='.urlencode($_SESSION['access_token']).'">Aktive User (Statistik)</a></li>';
	}
}

if (file_exists("../show_img_in_dir.php")) {
	echo '<li>Info: <a href="../show_img_in_dir.php" target="_blank">Bilder-Browser</a></li>';
}

if (!isset($bis_offen)) {
	if (strpos($a,'set_offline.php')!==false) {
		echo '<li>Chat temporär öffnen / schließen </li>';
	} else {
		echo '<li><a href="set_offline.php?token='.urlencode($_SESSION['access_token']).'">Chat temporär öffnen / schließen </a></li>';
	}
}

if (strpos($a,'admin_ban.php')!==false) {
	echo '<li>Ban-Verwaltung </li>';
} else {
	echo '<li><a href="admin_ban.php?token='.urlencode($_SESSION['access_token']).'">Ban-Verwaltung</a></li>';
}

if (strpos($a,'admin_maul.php')!==false) {
	echo '<li>Maulkorb-Verwaltung </li>';
} else {
	echo '<li><a href="admin_maul.php?token='.urlencode($_SESSION['access_token']).'">Maulkorb-Verwaltung</a></li> ';
}

$neu ="";
if ((time() - strtotime('25.09.2022')) < 3600*24*7 ){$neu = '<span style="color:#de0000">+++ NEU +++ </span>';}

if (strpos($a,'admin_nopv.php')!==false) {
	echo '<li>'.$neu.'"Flüstermaulkorb" (nopv)-Verwaltung </li>';
} else {
	echo '<li>'.$neu.'<a href="admin_nopv.php?token='.urlencode($_SESSION['access_token']).'">"Flüstermaulkorb" (nopv)-Verwaltung</a></li> ';
}

$tor = '';
if (file_exists('../tor_test.php')) { $tor = ' – Tor-User-Zugang verwalten';}

if (file_exists("admin_ip_sperren.php")) {
	if (strpos($a,'admin_ip_sperren.php')!==false) {
		echo '<li>'.$neu.'IPs sperren'.$tor.'</li>';
	} else {
		echo '<li>'.$neu.'<a href="admin_ip_sperren.php?token='.urlencode($_SESSION['access_token']).'">IPs sperren'.$tor.'</a></li> ';
	}
}

// if (file_exists("admin_tor_vpn.php")) {
// 	if (strpos($a,'admin_tor_vpn.php')!==false) {
// 		echo '<li>'.$neu.'Tor- und VPN-User-Zugang verwalten</li>';
// 	} else {
// 		echo '<li>'.$neu.'<a href="admin_tor_vpn.php?token='.urlencode($_SESSION['access_token']).'">Tor- und VPN-User-Zugang verwalten</a></li> ';
// 	}
// }

if (file_exists("admin_add_admins.php")) {
	if (strpos($a,'admin_add_admins.php')!==false) {
		echo '<li>Admins verwalten </li>';
	} else {
		echo '<li><a href="admin_add_admins.php?token='.urlencode($_SESSION['access_token']).'">Admins verwalten</a></li> ';
	}
}

if (strpos($a,'admin_mods.php')!==false) {
	echo '<li>Mods verwalten </li>';
} else {
	echo '<li><a href="admin_mods.php?token='.urlencode($_SESSION['access_token']).'">Mods verwalten</a></li> ';
}

// if (!isset($verified_min)) {
// 	if (strpos($a,'admin_verified.php')!==false) {
// 		echo '<li>Verifizierte User verwalten </li>';
// 	} else {
// 		echo '<li><a href="admin_verified.php?token='.urlencode($_SESSION['access_token']).'">Verifizierte User verwalten</a></li> ';
// 	}
// }

if (file_exists("../rooms/Intern")) {
	if (strpos($a,'admin_interne.php')!==false) {
		echo '<li>Zugang zu Sonderräumen verwalten </li>';
	} else {
		echo '<li><a href="admin_interne.php?token='.urlencode($_SESSION['access_token']).'">Zugang zu Sonderräumen verwalten</a></li>';
	}
}
?>


<style>
textarea {
	field-sizing: content;
	min-width: 250px;
	min-height: 60px;
	max-height: 50vh;
	resize: none;
	overflow: auto;
}
ul {margin-left:2em;}
</style>

</ul>

<h3>Räume bereinigen</h3>
<ul class="weitere">

<li><a href="clean_msg_pn.php?token=<?php echo urlencode($_SESSION['access_token']) ?>">Geflüsterte und gelöschte Nachrichten sowie "betritt..." usw. endgültig entfernen (und nicht archivieren).</a></li>
<li><a href="clean_msg_del.php?token=<?php echo urlencode($_SESSION['access_token']) ?>">(Nur) gelöschte Nachrichten endgültig entfernen (und nicht archivieren).</a></li>

<li><a href="clean_cookies.php?token=<?php echo urlencode($_SESSION['access_token']) ?>">Alle Cookies löschen.<br>(Setzt OHNE RÜCKFRAGE! alle Optionen auf Standardwerte, und entfernt Müll.)</a></li>
</ul>


<script>
// Backlink in /admin verbergen, wenn /admin in neuem Tab 
	
(function(){
	const links = document.querySelectorAll('.tochat');
	const params = new URLSearchParams(location.search);
	const token = params.get('token');

	// Seite A gilt als offen, wenn Eintrag existiert
	const seiteAoffen = token && localStorage.getItem('seiteA_open_' + token);

	links.forEach(link => {
		// Link NUR anzeigen, wenn Seite A NICHT offen ist
		link.style.display = seiteAoffen ? 'none' : '';
	});
})();
</script>
