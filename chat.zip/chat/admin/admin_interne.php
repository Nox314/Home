<?php
session_start();
define('ADMIN_INC', true);
session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird

// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}


if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['access_token'] ?? '')) {
    die("Du hast keinen Zugriff.");
}

if (isset($edit)) {
      // carriage return entfernen
      $textfile = trim(str_replace("\r", '', $textfile));

	// jetzt mindestens ein zeilenumbruch am ende
	$textfile .= "\n"; 

      // doppelte zeilenumbrueche weg
      while (false!==strpos($textfile, "\n\n")) {
          $textfile = str_replace("\n\n", "\n", $textfile);
      }

      $handler = fopen($userfile,"w");
      if(fwrite($handler, $textfile)) {
           $gespeichert = 1;
      }
      fclose($handler);
}
?>

<!DOCTYPE html>

<head>
<meta http-equiv="content-type" content="application/xhtml+xml;charset=utf-8" />
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<title>Der Chat von webdesign.weisshart.de - Zugang Sonderräume verwalten</title>
<link rel="shortcut icon" href="favicon.ico" />

<link rel="stylesheet" type="text/css" media="screen" href="admin.css" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" /> <!-- iPhone -->

</head>

<body>

<h1>Zugang zu Sonderräumen verwalten</h1>
<p><em>ACHTUNG!</em> Hier nur Nicknamen eintragen, pro Zugangsberechtigtem eine Zeile - keine leeren Zeilen!</p>
<p style="color:red"><em>ACHTUNG!</em> Die Nicknames MÜSSEN bereits registriert sein, <br>sonst hat jeder Gast, der sich mit einem der folgenden Nicknamen anmeldet, Zugang zu Sonderräumen!
</p>


<?php if(isset($gespeichert)){echo "<p>Berechtigungsdatei wurde gespeichert.</p>";}?>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div>
<input type="hidden" name="edit" value="1" />
<textarea name="textfile" cols="30" rows="20">
<?php
if (file_exists($userfile)) {
   readfile($userfile);
} else {
   echo "";
}
?>
</textarea>
<br />
<input type="submit" value="speichern" />
<input type="reset" value="zur&uuml;cksetzen" />
</div>
</form>
<?php include ("admin_inc.php")?>



</body>
</html>