<?php
header('Content-type: text/html; charset=utf-8');
session_start();
session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird
define('ADMIN_INC', true);
// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}

// Falls das Formular abgeschickt wurde, überprüfe den Token
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['access_token']) {
		die("Fehler: Ungültiger Token.");
	}
	// Stelle sicher, dass der Inhalt korrekt übernommen wird
	$textfile = $_POST['textfile'] ?? '';

	// Datei speichern (nur Beispiel)
	file_put_contents("../user/sperre.txt", $textfile);

	// Nach dem Speichern die Seite neu laden
	header("Location: " . $_SERVER['PHP_SELF'] . "?token=" . $_SESSION['access_token']);
	exit;
}

if ($_GET['token'] !== $_SESSION['access_token']) {
    die("Du hast keinen Zugriff.");
}
include ('admin_schutz_abfragen.php');

if (isset($_REQUEST['textfile'])) $textfile = $_REQUEST['textfile'];
if (isset($_REQUEST['edit'])) $edit = $_REQUEST['edit'];
if (isset($_REQUEST['gespeichert'])) $gespeichert = $_REQUEST['gespeichert'];
$userfile = "../user/sperre.txt";


if (isset($_REQUEST['torfrei'])) {
	// echo "freischalten";
	rename ("../tor_test.php", "../_tor_test.php");
}
if (isset($_REQUEST['torsperren'])) {rename ("../_tor_test.php", "../tor_test.php");} 


if (isset($_REQUEST['vpnfrei'])) {
	// echo "freischalten";
	rename ("../proxy_erkennen.php", "../_proxy_erkennen.php");
	rename ("../tor_test.php", "../_tor_test.php");
}
if (isset($_REQUEST['vpnsperren'])) {
	rename ("../_proxy_erkennen.php", "../proxy_erkennen.php");
	rename ("../_tor_test.php", "../tor_test.php");
} 


if (isset($edit)) {
	// carriage return entfernen
	$textfile = str_replace("\r", '', $textfile);
	// entfernt eine erste Leerzeile
	$textfile = preg_replace('/(\A[\r\n]+|[\r\n]+\z)/', '', $textfile);


	// jetzt mindestens ein zeilenumbruch am ende
	$textfile .= "\n"; 


	// doppelte zeilenumbrueche weg
	while (false!==strpos($textfile, "\n\n")) {
		$textfile = str_replace("\n\n", "\n", $textfile);
	}

	$handler = fopen($userfile,"w");
	if(fwrite($handler, $textfile)) {
		$gespeichert = 1;
	}
	fclose($handler);
}

$formatter = new IntlDateFormatter(
	'de_DE',
	IntlDateFormatter::FULL,
	IntlDateFormatter::FULL,
	'GMT',
	IntlDateFormatter::GREGORIAN,
	'dd.MM.yyyy'
);


?>

<!DOCTYPE html>
<html lang="de">

<head>
<meta charset="utf-8">
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" />
<title>Der Chat von webdesign.weisshart.de - User verwalten</title>
<link rel="shortcut icon" href="favicon.ico" />

<link rel="stylesheet" type="text/css" media="screen" href="admin.css" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" /> <!-- iPhone -->

</head>

<body>

<h1>IPs sperren</h1>
<p style="color:red;"><em><b>ACHTUNG! Benutze dieses Tool nur, wenn du wirklich weißt, was du tust.</b></em>
<br>Pro Sperre eine Zeile - keine leeren Zeilen!
<br>IPs nur mit Bedacht sperren! 
<br>Da IPs meist dynamisch zugeordnet werden, sperrst du evtl. unabsichtlich andere User!
<br>Im schlimmsten Fall sperrst du dich sogar selbst aus!
<br>Daher werden alle IP-Sperren 24 Std. nach dem letzten Eintrag automatisch zurückgesetzt.
</p>


<?php if(isset($gespeichert)){echo "<p>Userdatei wurde gespeichert.</p>";}?>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div>
<input type="hidden" name="edit" value="1" />
<input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['access_token'] ?? '') ?>">
<textarea name="textfile" cols="30" rows="10">
<?php
if (file_exists($userfile)) {
   readfile($userfile);
} else {
   echo "Die Datei ../user/sperre.txt existiert nicht";
}
?>
</textarea>
<br />
<input type="submit" value="speichern" />
<input type="reset" value="zur&uuml;cksetzen" />



</div>

</form>


<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['access_token'] ?? '') ?>">

<?php
if (file_exists('../tor_test.php')) {
	
	$zeilen = count(file("../tmp/torips.txt"));


	$log_dateiname = "../tmp/torlog.txt";
	if (file_exists($log_dateiname)) {
		$lines = file($log_dateiname);

		$count = 0;
		foreach($lines as $key => $val) {

			$teile = explode(" ", $val);
			$logdate = trim($teile[1]);
			
			$days = $formatter->parse($logdate);
			
			$hour = 12;
			$today              = strtotime($hour . ':00:00');
			$yesterday          = strtotime('-1 day', $today);
			$dayBeforeYesterday = strtotime('-1 day', $yesterday);
			$day2BeforeYesterday = strtotime('-1 day', $dayBeforeYesterday);
			$day7BeforeYesterday = strtotime('-5 day', $day2BeforeYesterday);

			if ($days >= $day7BeforeYesterday ) {
				$count ++;				
			}
		}
	}
	
	echo "<br><p>Tor-User (".$zeilen." IPs) werden derzeit blockiert.";
	
	if ($count == 1) {
		echo "<br>".$count." Login-Versuch von Tor wurde in den letzten 7 Tagen abgewehrt.";
	} elseif ($count > 1) {
		echo "<br>".$count." Login-Versuche von Tor wurden in den letzten 7 Tagen abgewehrt.";
	}
	echo "<br><p><button name='torfrei'>Tor-User wieder erlauben</button>";
   
   
} else {
	if (file_exists('../_tor_test.php')) {
		echo "<br><p>Tor-User haben Zugang. ";
		echo "<button name='torsperren'>Tor-User sperren</button>";
	}
}

if (file_exists('../proxy_erkennen.php')) {
	
	
		$log_dateiname = "../tmp/vpnlog.txt";
		if (file_exists($log_dateiname)) {
			$lines = file($log_dateiname);

			$count = 0;
			foreach($lines as $key => $val) {

				$teile = explode(" ", $val);
				$logdate = trim($teile[1]);
			
				$days = $formatter->parse($logdate);
			
				$hour = 12;
				$today              = strtotime($hour . ':00:00');
				$yesterday          = strtotime('-1 day', $today);
				$dayBeforeYesterday = strtotime('-1 day', $yesterday);
				$day2BeforeYesterday = strtotime('-1 day', $dayBeforeYesterday);
				$day7BeforeYesterday = strtotime('-5 day', $day2BeforeYesterday);

				if ($days >= $day7BeforeYesterday ) {
					$count ++;				
				}
			}
		}
	
	
		if ($count == 1) {
			echo "<p><br>".$count." Login-Versuch mit VPN wurde in den letzten 7 Tagen abgewehrt.";
		} elseif ($count > 1) {
			echo "<p><br>".$count." Login-Versuche mit VPN wurden in den letzten 7 Tagen abgewehrt.";
		}
	
	
	
	
	echo "<br><p>Gäste mit VPN sind gesperrt. <br><p><button name='vpnfrei'>Alle VPN-User erlauben</button>";
} else {
	if (file_exists('../_proxy_erkennen.php')) {
		echo "<br><br><p>VPN-User haben Zugang. ";
		echo "<button name='vpnsperren'>Gäste mit VPN sperren</button>";
	}
}



?>



</form>
<!-- <p><a href="http://www.onlineconversion.com/unix_time.htm" target="_blank">Unix Timestamp Converter</a></p> -->
<?php include ("admin_inc.php")?>



</body>
</html>