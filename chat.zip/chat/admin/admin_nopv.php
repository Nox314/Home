<?php
header('Content-type: text/html; charset=utf-8');
session_start();
session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird
define('ADMIN_INC', true);
// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}

// Falls das Formular abgeschickt wurde, überprüfe den Token
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['access_token']) {
		die("Fehler: Ungültiger Token.");
	}
	// Stelle sicher, dass der Inhalt korrekt übernommen wird
	$textfile = $_POST['textfile'] ?? '';

	// Datei speichern (nur Beispiel)
	file_put_contents("../user/nopv.txt", $textfile);

	// Nach dem Speichern die Seite neu laden
	header("Location: " . $_SERVER['PHP_SELF'] . "?token=" . $_SESSION['access_token']);
	exit;
}

if ($_GET['token'] !== $_SESSION['access_token']) {
    die("Du hast keinen Zugriff.");
}
include ('admin_schutz_abfragen.php');

if (isset($_REQUEST['textfile'])) $textfile = $_REQUEST['textfile'];
if (isset($_REQUEST['edit'])) $edit = $_REQUEST['edit'];
if (isset($_REQUEST['gespeichert'])) $gespeichert = $_REQUEST['gespeichert'];
$userfile = "../user/nopv.txt";

if (isset($edit)) {
      // carriage return entfernen
      $textfile = str_replace("\r", '', $textfile);

	// jetzt mindestens ein zeilenumbruch am ende
	// $textfile .= "\n"; 


      // doppelte zeilenumbrueche weg
      while (false!==strpos($textfile, "\n\n")) {
          $textfile = str_replace("\n\n", "\n", $textfile);
      }

      $handler = fopen($userfile,"w");
      if(fwrite($handler, $textfile)) {
           $gespeichert = 1;
      }
      fclose($handler);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">

<head>
<meta http-equiv="content-type" content="application/xhtml+xml;charset=utf-8" />
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" />
<meta http-equiv="Content-Script-Type" content="text/javascript" />
<title>Der Chat von webdesign.weisshart.de - User verwalten</title>
<link rel="shortcut icon" href="favicon.ico" />

<link rel="stylesheet" type="text/css" media="screen" href="admin.css?11" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" /> <!-- iPhone -->

</head>

<body>

<h1>"Flüstermaulkörbe" (nopv) verwalten</h1>
<p><em>ACHTUNG!</em>
<br />hier nur Maulkörbe l&ouml;schen, keine neuen anlegen
<br />Beim L&ouml;schen darauf achten: Pro Maulkorb eine Zeile - keine leeren Zeilen!</p>


<?php if(isset($gespeichert)){echo "<p>Userdatei wurde gespeichert.</p>";}?>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div>
<input type="hidden" name="edit" value="1" />
<textarea name="textfile" cols="100" rows="12">
<?php
if (file_exists($userfile)) {
   readfile($userfile);
} else {
   echo "Die Datei ../user/nopv.txt existiert nicht";
}
?>
</textarea>
<br />
<input type="submit" value="speichern" />
<input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['access_token'] ?? '') ?>">
<input type="reset" value="zur&uuml;cksetzen" />
</div>
</form>
<p><a href="https://rechner-tools.de/51-unix-timestamp.php" target="_blank">Unix Timestamp Converter</a></p>
<?php include ("admin_inc.php")?>



</body>
</html>