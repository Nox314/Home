<?php

header('Content-type: text/html; charset=utf-8');
session_start();
session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird

// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}


if ($_GET['token'] !== $_SESSION['access_token']) {
    die("Du hast keinen Zugriff.");
}


$pfad = dirname($_SERVER['SCRIPT_FILENAME']);
$parts = explode('/',$pfad);
end($parts);
$install = '/'.prev($parts);

$chatcookies = array(
'showip',
'afk',
'pop_up',
'showip',
'time_real',
'time_online',
'listen',
'size',
'Style',
'lang',
'LoginCookie',
'Login',
'watch',
'stop',
'Ankunft',
'bilder',
'chat_up_player',
'html5player',
'mehrzeilig',
'nickfarben',
'nickfarben2',
'reverse',
'sound',
'schrift',
'arrival',
'img_size',
'Station',
'nick',
'schrift',
'bg_mob',
'correct_logout',
'hide_message',
'last',

);


echo 'Folgende Cookies wurden geloescht:<br><br>';


if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
	
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
		
		if (in_array($name, $chatcookies)) {
			echo $name;
			echo ': ';
			echo $_COOKIE[$name];
			echo '<br>';
			unset($_COOKIE[$name]);
			$res = setcookie($name, '', time() - 3600,$install);
		}
    }
}

echo '<p><a href="admin.php?token='.urlencode($_SESSION['access_token']).'">zurueck zu den Admin-Tools</a></p>';

echo '<p><a href="../login.php">zurueck zum Chat</a></p>';

?>
