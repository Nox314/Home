<?php
/* Logdateien für GEMA Meldung aufbereiten */
error_reporting(E_ALL);
session_start();
session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird

// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}


if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['access_token'] ?? '')) {
    die("Du hast keinen Zugriff.");
}

if (date('m') < 10) {$akt = $quart = "3.".date('y');}
if (date('m') < 7) {$akt = $quart = "2.".date('y');}
if (date('m') < 4) {$akt = $quart = "1.".date('y');}
if (date('m') >= 10) {$akt = $quart = "4.".date('y');}	

$fehler = false;

/* GET abfragen */

if (isset($_GET['quartal'])) {
	if (preg_match("/^[1-4]\.[0-9][0-9]$/",$_GET['quartal'])) {
		$quart = $_GET['quartal'];
	} else {
		die ("Ungültiges Quartal eingeben.");
	}
}

if (substr($quart,0,1) == "1") {
	$monate = array(substr($quart,2,2)."01",substr($quart,2,2)."02",substr($quart,2,2)."03");
} elseif (substr($quart,0,1) == "2") {
	$monate = array(substr($quart,2,2)."04",substr($quart,2,2)."05",substr($quart,2,2)."06");
} elseif (substr($quart,0,1) == "3") {
	$monate = array(substr($quart,2,2)."07",substr($quart,2,2)."08",substr($quart,2,2)."09");
} else {
	$monate = array(substr($quart,2,2)."10",substr($quart,2,2)."11",substr($quart,2,2)."12");	
}

/* Vorquartale fuer select aufbereiten */

if (strlen(substr($quart,2,2) - 1)  == 1) {
	$vorjahr = '0'.(substr($quart,2,2) - 1);
} else {
	$vorjahr = (substr($quart,2,2) - 1);	
}


if (substr($quart,0,1) == "1") {
	$vor_quart = "4.".$vorjahr;
	$vor_2quart = "3.".$vorjahr;
} elseif (substr($quart,0,1) == "2") {
	$vor_quart = "1.".substr($quart,2,2);
	$vor_2quart = "4.".$vorjahr;
} elseif (substr($quart,0,1) == "3") {
	$vor_quart = "2.".substr($quart,2,2);
	$vor_2quart = "1.".substr($quart,2,2);
} else {
	$vor_quart = "3.".substr($quart,2,2);	
	$vor_2quart = "2.".substr($quart,2,2);	
}


/* Titel mit bestimmtem String nicht in die Auswertung aufnehmen: */
$ausnahme = "Audio:";



/* *********** ENDE Konfig ************ */

@include("../chat_config.php");
if (file_exists("../personal_config_inc.php")) {@include("../personal_config_inc.php");}
if (isset($gema) && $gema === true) { $gema_set = true;}


FUNCTION substr_in_array($haystack, $needle){
 
  $found = ARRAY();
 
	// cast to array 
    $needle = (ARRAY) $needle;
 
    // map with preg_quote 
    $needle = ARRAY_MAP('preg_quote', $needle);
 
    // loop over  array to get the search pattern 
    FOREACH ($needle AS $pattern)
    {
        IF (COUNT($found = @preg_grep("/$pattern/", $haystack, PREG_GREP_INVERT)) > 0) {
        	RETURN $found;
        }
    }
 
    // if not found 
    RETURN FALSE;
}


?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	
<title>Gema-Abrechnung</title>	

<style>

	body {
		margin:0 0 1em 3em;
		font-family: Arial;
		font-size: .9em;
	}

	table {
		border-collapse:collapse;
	}

	td {
		border: 1px solid #ccc;
		padding: .2em .5em;
	}
	td.anz {text-align:right}
	td.summe {font-weight:bold;}
	td.leer {width:50%;}
	.warning {color:red; font-size: .9em;}
	h2 {font-size: 1em; margin-bottom: 0}
	select {font-size: 1em;}

</style>	

</head>
<body>

<h1>Gestreamte mp3 im Chat</h1>

<form action="<?php  echo $_SERVER['PHP_SELF'] ?>" method="GET">
  <label for="quartal">Quartal für die GEMA-Abrechnung:</label>
<input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['access_token'] ?? '') ?>">
	
	<!--[IF !IE]> -->
    <select name="quartal" id="quartal" onchange="this.form.submit();">
	<!-- <![ENDIF]-->
	
	<!--[IF IE]>
    <select name="quartal">
	<![ENDIF]-->
	
	
      <option value=<?php echo $quart; ?> ><?php echo substr($quart,0,1); ?>. Quartal 20<?php echo substr($quart,2,2) ?> </option>
      <option value=<?php echo $vor_quart; ?> >Ein Quartal zurück - <?php echo substr($vor_quart,0,1); ?>. Quartal 20<?php echo substr($vor_quart,2,2) ?> </option>
      <option value=<?php echo $vor_2quart; ?> >Zwei Quartale zurück - <?php echo substr($vor_2quart,0,1); ?>. Quartal 20<?php echo substr($vor_2quart,2,2) ?> </option>
      <option value=<?php echo $akt; ?> >Aktuelles Quartal </option>
    </select>

	<!--[if IE]>
	<input type="submit" value=" Wählen ">
	<!<![endif]-->


</form>

<?php

echo '<h2>Auswertung für '.substr($quart,0,1).'. Quartal 20'.substr($quart,2,2).'</h2>';


foreach ($monate as $key => $monat) {
	if (file_exists('mp3log_'.$monat.'.txt')) { 
		$monat = 'mp3log_'.$monat.'.txt';
		$gema_file = file($monat);
		// $gema_file = substr_in_array(file($monat),$ausnahme);

		// print_r ($gema_file);

		if(isset($ausnahme))  {	$gema_file = substr_in_array($gema_file,$ausnahme); }
		
		// if(isset($ausnahme2)) {	$gema_file = substr_in_array($gema_file,$ausnahme2); }
		// if(isset($ausnahme3)) {	$gema_file = substr_in_array($gema_file,$ausnahme3); }
		// if(isset($ausnahme4)) {	$gema_file = substr_in_array($gema_file,$ausnahme4); }
		// if(isset($ausnahme5)) {	$gema_file = substr_in_array($gema_file,$ausnahme5); }
		// if(isset($ausnahme6)) {	$gema_file = substr_in_array($gema_file,$ausnahme6); }
		// if(isset($ausnahme7)) {	$gema_file = substr_in_array($gema_file,$ausnahme7); }


		if ($gema_file) {
			foreach($gema_file as $key => $zeile) {
				$titel = explode('|',$zeile);
				$temp = trim(str_replace('.mp3','',$titel[1]));
				// $titel_arr[] = trim(str_replace('.mp3','',$titel[1]));
				$titel_arr[] = trim(str_replace('https:','',$temp));
			}
		}
				 
	} else {
		$monat_klartext = substr($monat, 2,2).'.'.substr($monat, 0,2);
		if ($fehler !== true) {
			echo '<br /><span class="warning">Achtung! (Noch) keine Daten verfügbar für Monat(e): '.$monat_klartext.'</span>';
		} else {
			echo '<span class="warning"> - '.$monat_klartext.'</span>';
		}
		$fehler = true;		
	} 
}

if (isset($titel_arr)) {
	$summen = @array_count_values($titel_arr);
}

echo "<br /><br /><br /><table>";
echo "<tr><th>Titel</th><th>Abrufe</th></tr>";
if (isset($summen)) {
	foreach($summen as $key => $zeile2) {
		echo "<tr>";
		echo '<td>'.$key.'</td><td class="anz">'.$zeile2.'</td>';
		echo "</tr>";
	}
}

echo '</table><br /><br /><br /><br /><table>';

echo '<tr><td class="summe">Summe Streams</td><td class="anz summe">';
if (isset($titel_arr)) {
	echo count($titel_arr);
}
echo '</tr>';

if (isset($gema_set) && isset($titel_arr) && $gema_set === true) {
	echo '<tr><td class="summe">Mindestverg&uuml;tung gem. Tarif VR-OD 9 3b (Niedrige Interaktivität )<br />(0,001 € pro Stream)</td><td class="anz summe">';
	$betrag = @count($titel_arr) * 0.001;
	// echo money_format('€ %!n', $betrag);
	echo number_format($betrag, 2, ',', ' ').'&nbsp;€';
	
	echo '</td><td style="border:0">zzgl. MWSt. </td></tr>';
} else {
	// echo '<tr><td class="summe">Mindestverg&uuml;tung gem. Tarif VR-OD 9 3a (Hohe Interaktivität )<br />(0,00375 € pro Stream)</td><td class="anz summe">';
	// $betrag = @count($titel_arr) * 0.00375;
	// // echo money_format('€ %!n', $betrag);
	// echo number_format($betrag, 2, ',', ' ').'&nbsp;€';
	// echo '</td><td style="border:0">zzgl. MWSt. </td></tr>';
}

echo "</table>";

?>

<p><a href="https://www.gema.de/musiknutzer/tarife-formulare/tarif-vr-od-9/">Tarif für die Nutzung von Werken des GEMA-Repertoires</a> - 
<a href="https://www.gema.de/fileadmin/user_upload/Musiknutzer/Tarife/Tarife_VRA/tarif_vr_od9.pdf">GEMA Tarif VR-OD 9 [PDF]</a></p>

<h2>Zur Übernahme in die GEMA Excel-Tabelle:</h2>
<ol>
	<li>Leere Excel Tabelle öffnen ⇒ Daten ⇒ Externe Daten importieren ⇒ Neue Webabfrage ⇒ Die obige Tabelle auswählen (die Adresse dieser Seite aus dem Browserfenster kopieren und in Excel einf&uuml;gen)</li>
	<li>Titel entfernen, die nicht Werke und Rechte des GEMA-Repertoires nach Tarif VR-OD 9 5b sind! <a target="_blank" title="Link öffnet in neuem Tab" href="https://online.gema.de/werke/">GEMA Datenbank</a></li>
	<li>Mit copy &amp; paste in GEMA Tabelle kopieren. Dort fehlende Angaben manuell ergänzen.</li>
</ol>

<?php
$time_on = time() - $_COOKIE['arrival'];		
if (!isset($_COOKIE['arrival']) || $time_on > 60 * 60 * 3) {
	echo '<p><a href="../login.php">zum Chat-Login</a></p>';
} else {
	echo '<p><a href="../chat.php">zum Chat</a></p>';
}

	
?>



</body>
</html>