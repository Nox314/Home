<?php
header('Content-type: text/html; charset=utf-8');

session_start();

session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird
define('ADMIN_INC', true);
// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}

// Falls das Formular abgeschickt wurde, überprüfe den Token
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['access_token']) {
		die("Fehler: Ungültiger Token.");
	}
	// Stelle sicher, dass der Inhalt korrekt übernommen wird
	$textfile = $_POST['textfile'] ?? '';

	// Datei speichern (nur Beispiel)
	file_put_contents("set_offline.txt", $textfile);

	// Nach dem Speichern die Seite neu laden
	header("Location: " . $_SERVER['PHP_SELF'] . "?token=" . $_SESSION['access_token']);
	exit;
}

if (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['access_token'] ?? '')) {
    die("Du hast keinen Zugriff.");
}


include ('admin_schutz_abfragen.php');
include ('../chat_config.php');
if (file_exists('../personal_config_inc.php')) {include ('../personal_config_inc.php');}

if (isset($_REQUEST['textfile'])) $textfile = $_REQUEST['textfile'];
if (isset($_REQUEST['edit'])) $edit = $_REQUEST['edit'];
if (isset($_REQUEST['gespeichert'])) $gespeichert = $_REQUEST['gespeichert'];
$userfile = "set_offline.txt";

if (isset($edit)) {

	$textfile1 = preg_replace("/\s+/", "", $textfile);
	
// https://www.massiveart.com/de-de/blog/regex-zeichenfolgen-die-das-entwickler-leben-erleichtern
// https://www.regextester.com/	// [0-9]{2}:{1}[0-9]{2} ?- ?[0-9]{2}:{1}[0-9]{2}
	
	if (preg_match("/^\d{2}:{1}\d{2} ?- ?\d{2}:{1}\d{2}$/", $textfile) || strlen($textfile1) == 0) {

		$handler = fopen($userfile,"w");
		if(fwrite($handler, $textfile)) {
			$gespeichert = 1;
		}
		fclose($handler);
	} else {
		$eingabefehler = 1;
	}
	
}
?>

<!DOCTYPE html>
<html  lang="de">

<head>
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" >
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" >
<meta name="generator" content="notepad ;-)" >
<meta name="robots" content="index, follow" >
<title>Der Chat von webdesign.weisshart.de - Chat temporär öffnen</title>
<link rel="shortcut icon" href="favicon.ico" >

<link rel="stylesheet" type="text/css" media="screen" href="admin.css" >
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" > <!-- iPhone -->

</head>

<body>

<h1>Chat temporär öffnen / schließen</h1>

<?php
if (isset($ab_offen)) {
	echo '<p style="color:#d00;font-weight:bold">ACHTUNG! Die Variablen $ab_offen und $bis_offen müssen aus der config-Datei entfernt werden, wenn dieses Tool benutzt werden soll.</p>'; 
}
?>
<p><em>ACHTUNG!</em><br>Das Format exakt beachten, z.B.: 08:00 - 23:00
	<br>Um den Chat 24&nbsp;Std. zu öffnen das Feld einfach leer lassen.</p>




<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
<div>
<input type="hidden" name="edit" value="1" >
<input type="hidden" name="token" value="<?= htmlspecialchars($_SESSION['access_token'] ?? '') ?>">
<label for = "textfile">Öffnungszeit:</label><br>
<input type="text" name="textfile" id="textfile" value = "
<?php
if (file_exists($userfile)) {
   readfile($userfile);
} else {
   echo '';
}

?>
">
<br>
<input type="submit" value="speichern" >

</div>
</form>

<?php 
// echo strlen($textfile1);

if (isset($eingabefehler)) {
echo "<p style='color:red'>Eingabe fehlerhaft? Bitte prüfen!</p>";	

} elseif (strlen($textfile1) == 11){
echo "<p>Öffnungszeit ".$textfile." wurde gespeichert.</p>";	

} elseif (isset($edit) && strlen($textfile1) <= 1) {
echo "<p>Der Chat ist 24&nbsp;Std. geöffnet.</p>";	
}
	
?>


<?php include ("admin_inc.php")?>



</body>
</html>