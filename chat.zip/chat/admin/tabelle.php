<?php

$path = '../user/max_on_*';
$filenames = glob($path);
$count = 30;

foreach ($filenames as $filename) {
			
	if (time()-filemtime($filename) < $count *24 * 3600 && strpos($filename,'average') === false && strpos($filename,'tag') === false) {
		$array = file($filename);
		for($i = 0; $i <= 23; $i++) {
			${"summe$i"} +=  $array[$i];
		}		
	}
}

for($i = 0; $i <= 23; $i++) {
	$line = round(${"summe$i"} / $count,2);
	if ($line <= 0.5) $line = 0; // unterdrückt Werte < 1 in der Tabelle
	$newline .= $line ."\n";
}

$handler = fopen("../user/max_on_average.php", "w");
flock($handler,LOCK_EX);
fwrite($handler , $newline);
flock($handler,LOCK_UN);
fclose($handler);

?>