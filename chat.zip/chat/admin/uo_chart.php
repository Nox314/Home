<?php 

session_start();
session_regenerate_id(false); // Verhindert, dass die Session überschrieben wird

define('ADMIN_INC', true);

// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
    die("Fehler: Ungültiger Zugriff.");
}

date_default_timezone_set('Europe/Berlin');

$self_call = isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], $_SERVER['PHP_SELF']) !== false;

if (!$self_call && (!isset($_GET['token']) || $_GET['token'] !== ($_SESSION['access_token'] ?? ''))) {
    die("Du hast keinen Zugriff.");
}

// require_once("tabelle.php"); Durchschnitt 30 Tage direkt in user_stat_dyn.php


if (file_exists("../Mobile_Detect.php")) {	
	require_once "../Mobile_Detect.php";
	$detect = new Mobile_Detect;
}

if (date('Hi', time()) == '2359') {
	header("refresh: 70;");
} else {
	header("refresh: 60;");
}

error_reporting(E_ALL);


$vorgestern = date("d.m.Y", strtotime("-2 days"));
$dayselect = '../user/max_on_'.$vorgestern.'.php';

// $dayselect = " ";

// if (isset($_COOKIE["dayselect"])) {
// 	$dayselect = $_COOKIE["dayselect"];
// }
if (isset($_POST['day-select'])) {
	$dayselect = htmlspecialchars($_POST['day-select']); 
	// setcookie("dayselect",$dayselect, time()+60);
} 

?>

<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=.7">
<link rel="stylesheet" type="text/css" media="screen" href="admin.css" >


<style>
	html {
		-webkit-text-size-adjust: 100%; /* Prevent font scaling in landscape while allowing user zoom */
		scrollbar-width: none; /* damit der Fux beim Reload keine Scrollbar zeigt */
	}
	body {
		font-family:sans-serif;
		padding:5px;
		max-width:42em;
		margin:auto;
	}
	h1 {
/*		font-size: calc(12px + (22 - 12) * ((100vw - 320px) / (1600 - 320)));*/
/*		text-align:center;*/
	}
		
	h2 {font-size:1em;}
	h3 {font-size:1em;}
	form {width:max-content;}
	.graph a {font-size:.9rem;}
	
	select {
		-moz-appearance: none;
		-webkit-appearance: none;
		appearance: none;
		border: none;
		font-size: .8em;
		cursor:pointer;
		margin-bottom:.5em;
		color:#000;
		background-color:transparent;
		padding-left:0;
	}	
	
	#content {max-width:525px;margin:0 auto 6em;padding:0;}

	.graph {
		border: 1px solid #888;
		padding: .5em .5em 0;
		background:#f5f5f5;
		width:fit-content;
		margin-bottom:1em;
	}
	

	.graph * {
		margin: 0;
		padding: 0;
	}

	.graph .title {
		font-family:"Courier New", monospace;
		font-size:.9em;
		white-space:nowrap;
	}

	.graph .data {
		list-style-type: none;
		position: relative;
		overflow: hidden;
	}

	.graph .bar {
		position: absolute;
		bottom: 0;
		background: #666;
	}

	.graph .value {
		margin-top: 2px;
		display: block;
		color: #ffffff;
		text-align: center;
		font-size:14px;
	}

	.graph .outer {
		margin-top: -16px;
		color: #000000;
	}

	.graph .label {
		margin-top: 85px;
		height: 1.5em;
		list-style-type: none;
		white-space:nowrap;
	}

	.graph .label li {
		float: left;
		text-align: right;
		font-size: 12px;
		transform: rotate(270deg);
		font-family:"Courier", monospace;
	}
	
	input {
		display: none;
	}

	/* https://codepen.io/sparku/pen/JjoWNXj -  leider nicht bf */
	.test {
		-webkit-transition: height .3s ease;
		height: 0;
		overflow: hidden;
	}

	input:checked + .test {
		height: 6em;
	} 
	
	#draggable {
		border-right: 1px solid #000;
		width: 0;
		height: 130vh;
		position: relative;
		top: 128vh;
		left: -15px;
		margin-top: -130vh;
		cursor: move;
		z-index: 3;
		padding:0 3px;
	}
	
	@media screen and (max-width:800px) {
		input:checked + .test {
			height: 9em;
		}
		h2,h3,.test {font-size:1.3em;}
		.weitere li {font-size:1.2em !important;}
		.tochat {font-size:1.4em !important;}
	}
	
</style>

<title>User online Statistik (Chart)</title>


<?php
if (!$detect->isMobile()){
echo '
	<script src="https://webdesign.weisshart.de/scripts/jquery-4.0.0-rc.1.min.js"></script>
	<script src="https://webdesign.weisshart.de/scripts/jquery-ui_1.13.2.min.js"></script>
	<script>
		$( function() {
			$( "#draggable" ).draggable();
		} );
	</script>
	
	<style>	body {visibility: hidden;}</style>
	';
}	
?>



</head>
<body>



<div id="content">
<h1>Zu welcher Zeit sind die meisten User im Chat?</h1>



<?php

if (isset($_COOKIE['arrival'])) {
	$time_on = time() - $_COOKIE['arrival'];		
	if (!isset($_COOKIE['arrival']) || $time_on > 60 * 60 *3) {
		echo '<p style="margin:0 0 1em 0;text-align:right"><a class="tochat" href="../login.php">zum Chat-Login</a></p>';
	} else {
		echo '<p style="margin:0 0 1em 0;text-align:right"><a class="tochat" href="../chat.php">zum Chat</a></p>';
	}
}

if (!$detect->isMobile()){
echo '
	<div id="draggable" class="ui-widget-content">
	<img  src="../img/0.gif" alt="" >
	</div>
	';
}	
?>
 

<?php
// if (date('Hi', time()) == '0000') {
// 	sleep(5);
// }

require_once("SimpleBars.php");
$dayfile = "../user/max_on_tag.php";

// $formatter = new IntlDateFormatter('de_DE.UTF-8', IntlDateFormatter::NONE, IntlDateFormatter::SHORT);
$formatter2 = new IntlDateFormatter('de_DE.UTF-8', IntlDateFormatter::FULL, IntlDateFormatter::NONE);
$formatter3 = new IntlDateFormatter('de_DE.UTF-8', IntlDateFormatter::FULL, IntlDateFormatter::NONE);
$formatter4 = new IntlDateFormatter('de_DE.UTF-8', IntlDateFormatter::FULL, IntlDateFormatter::SHORT);


if (file_exists($dayfile)) {

	$zeit = '<p class="date">Letzte Aktualisierung: <br>Heute '.$formatter4->format(strtotime(date (" ", time()))).' Uhr';	
	$stundenwerte = file($dayfile);	
	$graph = new SimpleBars();
	$graph
		->setTitle($zeit)
		->setData($stundenwerte);
	echo $graph->render();
} else {
	echo '<p>(Aktueller Tag momentan (noch) nicht verfügbar.)';
}


$gestern = date("d.m.Y", strtotime("-1 days"));
$yesterdayfile = '../user/max_on_'.$gestern.'.php';

if (file_exists($yesterdayfile)) {

	// weil Archivfiles immer um 00:00:00 des Folgetags geschrieben wird:
	$vortag2 = filemtime($yesterdayfile)-86400;
	$zeit2 = '<p class="date">Gestern, '.$formatter2->format(strtotime(date ("l, d.m.Y", $vortag2)));
	$stundenwerte2 = file($yesterdayfile);
	$graph = new SimpleBars();
	$graph
		->setTitle($zeit2)
		->setData($stundenwerte2);
	echo $graph->render();
}

$averagefile = '../user/max_on_average.php';

if (file_exists($averagefile)) {

	$zeit4 = '<p class="date">Durchschnitt 30 Tage';
	$stundenwerte4 = file($averagefile);
	$graph = new SimpleBars();
	$graph
		->setTitle($zeit4)
		->setData($stundenwerte4);
	echo $graph->render();
}




$alltimemaxfile = '../user/max_on_alltime.php';

if (file_exists($alltimemaxfile)) {

	$zeit5 = '<p class="date">All time max';
	$stundenwerte5 = file($alltimemaxfile);
	$graph = new SimpleBars();
	$graph
		->setTitle($zeit5)
		->setData($stundenwerte5);
	echo $graph->render();
}






echo '
<form action="uo_chart.php" method="post" onchange="submit()">
<label for="day-select">Zeige einen Tag aus dem Archiv: </label>
<select name="day-select" id="day-select">
<option value="">Auswahl&nbsp;▽</option>
';

$start = microtime(true);

$temp = array();
$handle = opendir("../user");
while($file = readdir($handle)) {
	if(strpos($file,"max_on_") !== false && strpos($file,"tag") === false  && strpos($file,"average") === false ) {
		$temp[] = substr($file,7,10);
	}
}
closedir($handle);

array_walk_recursive($temp, function(&$element) {
	$element = strtotime($element);
});

rsort($temp);

// Gestern nicht doppelt anzeigen
unset($temp[0]);

// max. Anzahl Tage
// array_splice($temp, 7);


array_walk_recursive($temp, function(&$element) {
	global $formatter3;
	$element2 = $formatter3->format(strtotime(date ("d.m.Y", $element)));
	$element = date('d.m.Y',$element);
	echo '<option value="max_on_'.$element.'.php">'.$element2.'</option>';
});

echo '<option value="max_on_xxx.php"> --- nichts anzeigen --- </option>';

echo '</select>';
// echo ' <input type="submit" value="Tag zeigen" />';
echo '</form>';


$archfile = "../user/$dayselect";
if (file_exists($archfile)) {
	
	$vortag3 = filemtime($archfile)-86400;
	$zeit3 = '<p class="date">Archiv: '.$formatter2->format(strtotime(date ("l, d.m.Y", $vortag3)));

	$stundenwerte3 = file($archfile);	
	$graph = new SimpleBars();
	$graph
		->setTitle($zeit3)
		->setData($stundenwerte3);
	echo $graph->render();
} else {
	echo '<div class="graph" style="width:31.5em;height:15.5em;"></div>';
}

$end = microtime(true);
// echo $run = $end - $start."<br>";
?>



<label class="test" for="check" style="cursor:pointer">Wie wird gemessen? ▽</label>
<input id="check" type="checkbox">

<div class="test">
<p  style="color: #555;font-size: .9em;line-height:1.4em">Die Anzahl der anwesenden User wird jede Minute einmal erfasst.<br>Gezählt werden alle zu diesem Zeitpunkt anwesenden (sichtbaren) User im Standard-Raum (Lobby).   <br>Der höchste Wert innerhalb jeder Stunde geht in die Statistik ein.</p>
</div>




</div>


<?php include_once('admin_inc.php') ?>


<script>
//mobile viewport hack
(function(){

  function apply_viewport(){
    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)   ) {

      var ww = window.screen.width;
      var mw = 800; // min width of site
      var ratio =  ww / mw; //calculate ratio
      var viewport_meta_tag = document.getElementById('viewport');
      if( ww < mw){ //smaller than minimum size
        viewport_meta_tag.setAttribute('content', 'initial-scale=' + ratio + ', maximum-scale=' + ratio + ', minimum-scale=' + ratio + ', user-scalable=no, width=' + mw);
      }
      else { //regular size
        viewport_meta_tag.setAttribute('content', 'initial-scale=1.0, maximum-scale=1, minimum-scale=1.0, user-scalable=yes, width=' + ww);
      }
    }
  }

  //ok, i need to update viewport scale if screen dimentions changed
  window.addEventListener('resize', function(){
    apply_viewport();
  });

  apply_viewport();

}());

// Speichern der Scrollposition bevor die Seite verlassen wird
window.addEventListener("beforeunload", function () {
	sessionStorage.setItem("scrollPosition", window.scrollY);
});

// Wiederherstellen der Scrollposition nach dem Laden der Seite
window.addEventListener("pageshow", function () {
	const scrollPosition = sessionStorage.getItem("scrollPosition");
	if (scrollPosition !== null) {
		window.scrollTo(0, parseInt(scrollPosition, 10));
		sessionStorage.removeItem("scrollPosition");
	}
// Sichtbarkeit wiederherstellen, nachdem gescrollt wurde
      document.body.style.visibility = 'visible';
});


</script>
	
</body>
</html>