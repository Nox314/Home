<?php
header('Content-type: text/html; charset=utf-8');

if (strpos($_SERVER['HTTP_REFERER'],"/chat.php") === false) {
   echo "Sie haben keine Berechtigung, diese Seite zu besuchen.";
   exit;
}
?>

<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">


<title>Cookies</title>

</head>
<body>

<h1>Was sind Cookies? Sind Cookies böse oder gefährlich?</h1>

<p>Ein ausführliche Beschreibung gibt es hier vom <a href="https://www.verbraucherportal-bw.de/,Lde/Startseite/Verbraucherschutz/Cookies+_+hilfreich+oder+gefaehrlich_">Verbraucherportal Baden-Württemberg</a></p>
<p>Auch auf der Website der <a href="https://www.verbraucherzentrale.de/wissen/digitale-welt/datenschutz/cookies-kontrollieren-und-verwalten-so-gehts-11996">Verbraucherzentrale</a> findet sich ein ausführlicher Artikel zum Thema.	
	
	
<p>Der Chat verwendet Cookies ausschließlich, um von dir selbst gewählte Einstellungen zu speichern.<br>Der Chat setzt keine Drittanbieter-Cookies, und keine Tracking-Cookies, also keine „bösen“ Cookies.</p>
<h2>Diese Einstellungen werden aktuell vom Chat als Cookies in deinem Browser gespeichert:</h2>
<?php
// Durch den Web-Server generierter Cookie-Inhalt
$allowed = ['img_size','schrift','dc','showip','correct_logout','Style','color','freeze','arrival','last','avt','chat_up_player','enable_dark','nickfarben','nickfarben2','pic','rev','sound','uhr','watch','listen'];


foreach ($_COOKIE as $k => $v) {
	if (in_array($k, $allowed)) {
		echo "$k = $v<br>\n";
	};
}

?>


</body>
</html>