<?php
// // Anzeige der Anzahl user online
// // cachen der AJAX Daten verhindern (IE):
// // Bust cache in the head
// header ("Expires: Mon, 26 Jul 1997 05:00:00 GMT");    // Date in the past
// header ("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
//
// // always modified
// header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
// header ("Pragma: no-cache");                          // HTTP/1.0

$show_dir = 'user/';
$dir=opendir($show_dir);
$liste = "";
$anzahl = 0;
while (false !== ($file = readdir($dir))) {
       	if(strpos($file,"ip_") !== false
               && strpos($file,"_pr") === false // private Raeume nicht anzeigen
               && time() - filemtime($show_dir.$file) < 15) {

               $userfile = $show_dir.$file;
               $lines = file($userfile);
               foreach ($lines as $line_num => $line) {
                        $user = explode("++++",$line);
                        //if (strlen($user[1]) > 1) {
						if (strlen($user[1]) > 1 && strpos($user[1],"ghost") === false) {
                               $anzahl = $anzahl +1;
                        }
               }
        }
}
echo $on = $anzahl;
?>