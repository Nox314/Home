<?php 

include("chat_config.php");

if (file_exists("admin/admins.txt") && file_exists("admin/admin_admins.php")) {
	$admins2 = file("admin/admins.txt",FILE_IGNORE_NEW_LINES); 
	$admins = array_merge($admins, $admins2); // und was, wenn kein $admins?
}

if (file_exists("admin/mods.txt") && file_exists("admin/admin_mods.php")) {
	$mods = file("admin/mods.txt",FILE_IGNORE_NEW_LINES); 
}


//if ($admintrue || modtrue) {
if (strpos($msg_explode[1],"/ban ") !== false
	// || strpos($msg_explode[1],"/kick ") !== false
	|| strpos($msg_explode[1],"/maulkorb ") !== false
		|| strpos($msg_explode[1],"/nopv ") !== false) {

	if (strpos($msg_explode[1],"/ban ") !== false) $mess = "you're banished";
	// if (strpos($msg_explode[1],"/kick ") !== false) $mess = "you've been kicked";
	if (strpos($msg_explode[1],"/maulkorb ") !== false) $mess = "you're muzzled";
	if (strpos($msg_explode[1],"/nopv ") !== false) $mess = "Flüstern ist dir jetzt leider nicht mehr erlaubt. ";


	$banmsg = trim($msg_explode[1]);
	$banmsg = preg_replace("/\s+/"," ", $banmsg); // mehrfache Leerzeichen weg

	$banned_nick = explode(" ",$banmsg);
	$banned_nick = str_replace("@","",$banned_nick);

	$nickban = $banned_nick[1];

	// $nickban1 = explode(" ",$nickban);
	// $nickban2 = $nickban1[1];
	
	
	// Admins können nicht gebannt werden:		
	foreach($admins as $key => $val) {
		if (utf8_decode($nickban) == trim(utf8_decode($val))) {exit;}
	}
	// Mods können nicht gebannt werden:		
	foreach($mods as $key => $val2) {
		if (utf8_decode($nickban) == trim(utf8_decode($val2))) {exit;}
	}
	

	// jetzt noch die ban Zeit:
	$banparts = end($banned_nick);	
	
	if ($banparts == $nickban  || $banparts < .1) $banparts = $bantime; // Vorgabezeit für ban, wenn keine Zeit angegeben
	
	if (!is_numeric($banparts)) { 		
		$banparts = preg_replace('/[^0-9]/', '', $banparts);  
	}

	if ($banparts > 43200) $banparts = 43200; // banzeit max. 30 Tage

	$bantime = time() + 60*$banparts;


	// und jetzt die IP zum nick suchen:
	$roomid = str_replace("rooms/","_",$room);
	$ipfile = 'user/ip'.$roomid.'.txt';

	$lines = file($ipfile);
	$ipparts = "";
	foreach ($lines as $line_num => $line) {
		if (strpos($line,$nickban) !== false) {
			$ipparts = explode("****", $line);
			$banip = $ipparts[0];
		}
	}


	$banstrg = $nickban."****".$bantime."++++".$banip."\n";

	if (strpos($msg_explode[1],"/maulkorb") !== false) {
		$banned = "user/maulkorb.txt";
	} elseif (strpos($msg_explode[1],"/nopv") !== false) {
		$banned = "user/nopv.txt";
	} else {
		$banned = "user/ban.txt";
	}
	$fb = fopen($banned, "a+");
	chmod ($banned, 0646);
	fwrite($fb, $banstrg);
	fclose($fb);

	$msg_explode[1] = ' <span style="display:none">/pn @'.$nickban.' </span> '.$mess;



}





//}

?>
