

<div id="befehle">

<p id="inner_befehle" class="away" style="margin-bottom:4px" role="button" tabindex="0" onclick="klapp2('befehl_list'); return false;" onkeypress="klapp2('befehl_list'); return false;">Befehle <span style="display:inline-block; ">▷</span></p>	

<ul style="float:left" id="befehl_list">


<li class="away" style="float:left;cursor:pointer"><a onclick="ads('/ignore '); return false;" > /igno </a></li>
<li class="away" style="float:left;cursor:pointer"><a onclick="ads('/show '); return false;" > /show </a></li>

<?php
if (file_exists('gpt_bot.php') && isset($apiKey)) {
echo '	
<li class="away" style="float:left;cursor:pointer"><a onclick="ads(\'/bot \'); return false;" > /bot </a></li>
';
}

if ($admintrue || $modtrue) {
echo '	
<li class="away" style="float:left;cursor:pointer"><a onclick="ads(\'/ban \'); return false;" > /ban </a></li>
<li class="away" style="float:left;cursor:pointer"><a onclick="ads(\'/maulkorb \'); return false;" > /maul </a></li>
<li class="away" style="float:left;cursor:pointer"><a onclick="ads(\'/nopv \'); return false;" > /nopv </a></li>
';
}
?>

</ul>
</div>

<script>
	let befehlList = document.getElementById('befehl_list');
	let innerBefehle = document.getElementById('inner_befehle');

	if (befehlList && innerBefehle) {
		// Standard: immer geschlossen
		befehlList.style.display = "none";
		innerBefehle.innerHTML = ' Befehle ▷';

		// Nur wenn LocalStorage "offen" gesetzt wurde, öffnen
		if (localStorage.getItem("display_befehle") === "open") {
			befehlList.style.display = "block";
			innerBefehle.innerHTML = ' Befehle <span style="display:inline-block; transform: rotate(180deg);">▷</span>';
		}
	}

	function klapp2(beitrag) {
		let box = document.getElementById(beitrag);
		if (box && innerBefehle) {
			if (box.style.display == 'none') {
				box.style.display = "block";
				innerBefehle.innerHTML = ' Befehle <span style="display:inline-block; transform: rotate(180deg);">▷</span>';
				localStorage.setItem("display_befehle", "open");
			} else {
				box.style.display = "none";
				innerBefehle.innerHTML = ' Befehle ▷';
				localStorage.removeItem("display_befehle");
			}
		}
	}
</script>
	