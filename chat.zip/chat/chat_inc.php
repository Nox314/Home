<?php
// error_reporting(E_ALL);
  

// Abfrage, ob Admin:
$admintrue = false;
$modtrue = false;

if (!isset($admins)) {$admins=[];}
if (!isset($superadmin)) {$superadmin=[];}

//session_start(); // ist bereits in chat.php
$nickname= $_SESSION['chatuser'];


if(is_array($admins)){
	foreach($admins as $key => $val) {
		if ($nickname == trim($val)) {$admintrue = true;}
	}
}
if(is_array($mods)){
	foreach($mods as $key => $val) {
		if ($nickname == trim($val)) {$modtrue = true;}
	}
}


if (file_exists("admin/interne.txt") && file_exists("admin/admin_interne.php")) {
	$interne = file("admin/interne.txt",FILE_IGNORE_NEW_LINES); 
}

  
// if(isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] != '') {
// 	$own_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
// } else {
// 	$own_ip = $_SERVER['REMOTE_ADDR'];
// }   


$own_ip = null;

// Prüfe X-Forwarded-For (Proxy)
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
	foreach ($ips as $candidate) {
		$candidate = trim($candidate);

		// IPv4 zuerst
		if (filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
			$own_ip = $candidate;
			break;
		}
		// IPv6 merken, falls keine IPv4 kommt
		if (!$own_ip && filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
			$own_ip = $candidate;
		}
	}
}

// Fallback REMOTE_ADDR, falls noch keine IP
if (!$own_ip && !empty($_SERVER['REMOTE_ADDR'])) {
	$own_ip = $_SERVER['REMOTE_ADDR'];
}

// IPv4 aus IPv6-Mapped-Adressen extrahieren (::ffff:192.168.1.1)
if ($own_ip && strpos($own_ip, '::ffff:') === 0) {
	$own_ip = substr($own_ip, 7);
}

// Optional: IPv6 normalisieren
if ($own_ip && filter_var($own_ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
	$own_ip = inet_ntop(inet_pton($own_ip));
}


$directory = "";
if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
$abs_path = "http://".$_SERVER['SERVER_NAME'].$directory."/";


$superadmintrue = false;
if (isset($superadmin)) {
	if (in_array($nickname,$superadmin)) {$superadmintrue = true;}
}
if (file_exists("img/schluessel.png")) {
	$support_mark = '<img src="img/schluessel.png" alt="Support" title="Support"  height="12"  >';
}


if (!isset($ghostpic)) {
	if (file_exists('img/ghost.png')) {
		$ghostpic = ' <img src="img/ghost.png" alt="Ghost" title="Ghost"  style="max-height:14px" >'; 
	} else {
		$ghostpic = '[Ghost]';
	}
}

if (!isset($mod)) {$mod = "";}

if (!isset($mod_rooms)) {$mod_rooms = array("");}

if (!isset($vidallow)) {$vidallow = "";}

if (!isset($anz_msg)) {$anz_msg = 40;}
if ($anz_msg > 120) {$anz_msg = 120;}

if (!isset($refresh)) {$refresh = 1500;}
if ($refresh < 500) {$refresh = 500;}

if (!isset($maxwidth)) {$maxwidth = 250;}
if ($maxwidth > 400) {$maxwidth = 400;}

if (!isset($maxheight)) {$maxheight = 120;}
// if ($maxheight > 260) {$maxheight = 260;}

if (!isset($show_x)) {$show_x = 800;}
if ($show_x > 1200) {$show_x = 1200;}

if (!isset($max_y)) {$max_y = 600;}
if ($max_y > 900) {$max_y = 900;}

if (!isset($blankrooms)) {$blankrooms = "no";}
if (!isset($blankroom)) {$blankroom = array();}

	
// if (!isset($verified)) {$verified = '<span class="verified" title="Stammgast">✓</span>';}
if (!isset($verified)) {$verified = 'img/haken.webp';}
if (!isset($verified_min)) {$verified_min = 30;}

// Abfrage ob registrierter User
if (file_exists("user/user.txt")) {
	$d1 = file("user/user.txt");
	foreach ($d1 as $c) {
		$part1 = explode("****",$c);
		if ($part1[0] == $nickname) {
			$in_regdb = true;
		}
	}
}

// if (isset($mods)) {
// 	foreach($mods as $key => $val) {
// 		if ($nickname == trim($val) && $in_regdb === true && $admintrue !== true) {$modtrue = true;}
// 	}
// }


// wer hat ein Profil:
$prof_array[] = "";
$dir5 = 'profile/';
if ($handle = opendir($dir5)) {
	// $profil_kz = '';
	// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
	while (false !== ($file = readdir($handle))) {

		if($file != "."
			&& $file != ".."
				&& $file != ".htaccess"
					&& strpos($file,'.jpg') === false
						&& strpos($file,'.gif') === false
		){
			$prof_array[] = $file;
		}
	}
}

if(isset($_SERVER['HTTPS'])) {
	if ($_SERVER["HTTPS"] == "on") {
		$connection = 'https://';
	} 
} else {
	$connection = 'http://';
}

// in welchem Raum bin ich?
$room = "rooms/$standard";


if(isset($_GET['room'])) {

	if (preg_match('/[^0-9_a-zA-Z]/', $_GET['room'])) {echo "Achtung: Raumnamen dürfen nur Buchstaben und Ziffern, sowie den Unterstrich _ enthalten";exit;}
	
	if (strlen($_GET['room']) > 24) {echo "Achtung: Raumnamen d&uuml;rfen nicht l&auml;nger als 24 Zeichen sein!"; exit;}
	
	if (ctype_alpha (substr($_GET['room'],0,1)) !== true) {echo "Achtung: Raumnamen m&uuml;ssen mit einem Gro&szlig;buchstaben beginnen"; exit;}
	
	if ($_GET['room'] != "" && $_GET['room'] != "_pr" && !stristr($_GET['room'],$standard) ) { // so kann man Lobby_pin nicht schreiben
	// if ($_GET['room'] != "" && $_GET['room'] != "_pr") {
		if (preg_match("=^[a-z\d_]+$=i",$_GET['room']) ) {
			$room = "rooms/".ucfirst(substr($_GET['room'],0,25));			
		}
	}
}


if(isset($_POST['room'])) {
	if (strlen($_POST['room']) > 25) {echo "Achtung: Raumnamen d&uuml;rfen nicht l&auml;nger als 25 Zeichen sein!"; exit;}

	if (ctype_alpha (substr($_POST['room'],0,1)) !== true) {echo "Achtung: Raumnamen m&uuml;ssen mit einem Gro&szlig;buchstaben beginnen"; exit;}

	if ($_POST['room'] != "" && $_POST['room'] != "_pr" && !stristr($_POST['room'],$standard) ) {
		if (preg_match("=^[a-z\d_]+$=i",$_POST['room']) ) {
			$room = "rooms/".ucfirst(substr($_POST['room'],0,25));
		}
	}
}


// den Raum fuer die Shoutbox festlegen:
//if (strpos($_SERVER['SCRIPT_NAME'],"chat_shoutbox.php") !== false  && $_SERVER['SERVER_NAME'] == "webdesign.weisshart.de") {$room="rooms/Demo";}


if(file_exists($room)) {
	$roomexists = true;
}

// // damit auch kleine externe Bilder verpixelt werden, wenn pixelon:
// if (is_file("jmstv.php") === true && $admintrue === false) {
// $maxwidth = $maxheight = 115;
// }


$sav_msg = $anz_msg * 2;

$listen = false;
$showip = false;
$watch = false;
$stop = false;

if (isset($_COOKIE["listen"])) $listen = true;
// if (isset($_COOKIE["VPN"]) && $_COOKIE["VPN"] == "VPN") $vpn = true;
if (isset($_COOKIE["showip"]) && $_COOKIE["showip"] == "on" && $admintrue == true ) $showip = true;
if (isset($_COOKIE["watch"])) $watch = true;
if (isset($_COOKIE["stop"]) && $_COOKIE["stop"] == "stop") $stop = true;
if (isset($_COOKIE["color"])) $setcolor = $_COOKIE["color"];
if (isset($_COOKIE["ignore"])) $ignore = $_COOKIE["ignore"];
if (isset($_COOKIE["Style"])) $style = $_COOKIE["Style"];
// if($_SESSION['login']==1) $nickname = $_SESSION['chatuser'];


if(!isset($admin_mark)) $admin_mark = '<span class="admin_mark" title="Admin/a">★</span>';
if(!isset($mod_mark)) $mod_mark = '<span class="mod_mark" title="Mod/ine">★</span>';


if (!isset($s)) $s = "";
// if(!isset($profil_mark) || $s==12) $profil_mark = "[P]";
if(!isset($max_length)) $max_length = 500;


// strripos f¸r PHP4: http://www.homepage-forum.de/showthread.php?p=156334
if(!function_exists('strripos')) {
	function strripos($text, $search) {
		$text = strtolower($text); $search = strtolower($search);
		if(strlen($search)==1) return strrpos($text,$search);
		$x = strpos($text, $search);
		do {
			$y = strpos($text, $search, $x+1); $x = ($y) ? $y : $x;
		}
		while ($y);
		return $x;
	}
}

//str_ireplace fuer PHP4: http://de.php.net/manual/de/function.str-ireplace.php
if(!function_exists('str_ireplace')) {
	function str_ireplace($search,$replace,$subject) {
		$search = preg_quote($search, "/");
		return preg_replace("/".$search."/i", $replace, $subject);
	}
}


// Raumliste:
function user_room() {
	global  $anz_rooms,
	$room,
	$standard,
	$roomexists,
	$datum,
	$uhr,
	$sound,
	$nickfarben,
	$lang,
	$nickname,
	$admintrue,
	$refresh,
	$show_user_im_chat,
	$superadmintrue;

	if ($anz_rooms == 0) {
		if (strpos($room,"_pr") !== false) {
			// homelink fuer _pr
			return "<p><a href=\"chat.php?room=$standard\">"._BACKTOSTD." $standard</a></p>";
		}
		exit; 
	}
		

	$wo = trim(substr($room,6));
	$show_dir = 'rooms/';
	$log_dir=opendir($show_dir);


	$user_room = "<ul>";

	$a = 0;
	while (false !== ($raeume = readdir($log_dir))) {
		// $user_room = "<ul>";

		// Fehlermeldungen bei ungueltigen Raumnamen
		if (strpos($raeume,".") === false && strpos($raeume,"htaccess") === false ) {
			if(strpos($raeume," ") !== false) {echo "<p style='color:red'>"._ROOM_NAME1."</p>"; exit;}
			if (!preg_match( '/^[A-Z]+$/' , substr($raeume,0,1) )) {echo "<p style='color:red'>"._ROOM_NAME2."</p>";}
			if (!preg_match( '/^[a-zA-Z0-9_]+$/' , $raeume )) {echo "<p style='color:red'>"._ROOM_NAME3."</p>"; exit;} // nur Buchstaben, Ziffern und Unterstrich
		}


		if ((strpos($raeume,"_p") === false || (isset($_COOKIE["listen"]) && $superadmintrue !== false))
			&& ($raeume != "Offline"  || $admintrue !== false)
				&& preg_match( '/^[a-zA-Z0-9_]+$/' , $raeume ) // nur Buchstaben, Ziffern und Unterstrich
					&& preg_match( '/^[A-Z]+$/' , substr($raeume,0,1)) // nicht einlesen falls doch ein lower case Raum erstellt wird 	
		){
			$files[] = $raeume;
			$a++;
		}
	}
	
	closedir($log_dir);

	if (!isset($files)) {$files[0]="Standard";}
	// sort ($files);
	 
	$sortOrder = array($standard,'Info','INFO','Intern');
	$sorted = array_intersect($sortOrder, $files);
	$remaining = array_diff($files, $sortOrder);
	sort ($remaining);
	$files = array_merge($sorted, $remaining);
	
	 
	// private Raeume ans Ende:
	foreach($files as $oeftl) {
		if (strpos($oeftl,"_pr") === false) $oeffentlich[] = $oeftl;
	}
	foreach($files as $prfile) {
		if (strpos($prfile,"_pr") !== false) $privat[] = $prfile;
	}
	if (isset($privat)) {
		$files = array_merge ($oeffentlich,$privat);
	}


	$countall = 0;
	foreach($files as $file) {

		// das ip file:
		$ip_file = 'user/ip_'.$file.'.txt';

		$c = false;
		 
		// // file ggf erstellen:
		// if (!file_exists($ip_file)) {
		// 	fopen($ip_file, "w");
		// }
		 
		if (file_exists($ip_file)) { 
			$filealter = time()-filemtime($ip_file);
		
			if (false !== ($row=file($ip_file)) && $filealter < 10) { 
				 
				$fp = fopen($ip_file, "r"); 
				if ($fp && flock($fp, LOCK_SH)) { // Sperre für sicheres Lesen setzen
					$c = -1;
					while (!feof($fp)) {
						$zeile = fgets($fp, 150); // Liest 150 Zeichen aus einer Zeile der Datei
						if (strpos($zeile, "ghost") === false) {
							$c++; // Damit Ghosts nicht gezählt werden
						}
					}
					flock($fp, LOCK_UN); // Sperre wieder freigeben
					fclose($fp);
				} else {
					// echo "Datei $ip_file konnte nicht gelesen werden.";
				}
				
				$countall = $countall + $c;
				if ($c==0) {
					$c = "";
				}
			}
		} 

		if ($c >= 1) $c = "<span style=\"color:red;font-weight:bold;\">[$c]</span>";

		// $location = str_replace("_pr"," [pr]",$file); // wozu sollte das sein?
		$location = $file;

		// keine Useranzeige in Räumen
		// $c = "";

		if ($file == $wo) {
			$user_room .= "<li><em><dfn>"._ACTROOM.": </dfn>$location $c</em> </li>\n";
		} elseif ($file == $standard) { // zum Standardraum ohne Raumname verlinken:
			$user_room .= "<li><a href=\"".$_SERVER['PHP_SELF']."\">$location $c</a> </li>\n";
		} else {
			// hier auch die Optionen mitgeben
			$user_room .= "<li><a href=\"".$_SERVER['PHP_SELF']."?room=$file\">$location $c</a> </li>\n";
		}
		 
		 
	}

	$user_room = "$user_room</ul>";

	// die Gesamtzahl anwesender user in ein file schreiben fuer externe Abfrage:
	// nicht aktiv. Wer die Funktion will: die folgenden 4 Zeilen entkommentieren
	// $file4 = 'user_anw.txt';
	// $open4 = fopen($file4, "w");
	// fwrite($open4,$countall);
	// fclose($open4);

	// wenn nur 1 Raum, keine Raumliste zeigen:
	// wenn nur 1 Raum, und der gewaehlte Raum nicht existiert, dennoch Raumliste zeigen:
	if ($a <= 1 && strpos($room,"_pr") === false && $roomexists !== false) $user_room = "";
	if ($a <= 1 && $roomexists !== false && $show_user_im_chat === true && $countall >= 1) $user_room = "<p>User im Chat: $countall</p>";

	return $user_room;
}


// die anwesenden user:
function user_online() {
	global  $room,
	$nickname,
	$admins,
	$mods,
	$s,
	$admins_no_mark,
	$superadmin,
	$superadmintrue,
	$ghostpic,
	$chat_light,
	$standard,
	$admin_mark,
	$mod_mark,
	$support_mark,
	$stop,
	$watch,
	$listen,
	$ignore,
	$admintrue,
	$reg_only_viewprof,
	$in_regdb,
	$prof_array,
	$own_ip,
	$showip,
	$profil_mark,
	$detect,
	$response,
	$verified,
	$ver_user,
	$refresh,
	$chathopper,
	$verified_min,
	$map,
	$support_mark_set, // falls verwendet
	$waermestube_timeout;

	$wo = trim(substr($room,6));
	$file1 = 'user/ip_'.$wo.'.txt';

	// Anzeige-Header wie vorher
	if ($watch !== false && $admintrue === true) echo "<span lang=\"en\" style=\"color:#f30 !important; font-weight:bold;\">…&nbsp;ghost mode on </span><br>";
	if ($stop !== false) echo "<span lang=\"en\" style=\"color:#f30 !important; font-weight:bold;\">…&nbsp;reading&nbsp;mode&nbsp;on </span><br>";

	if (($listen === true && $admintrue === true  && $watch !== true) || ($listen === true && $superadmintrue===true) ) echo "<span lang=\"en\" style=\"color:#f30 !important; font-weight:bold;\">…&nbsp;u're&nbsp;Peeping-Tom! </span><br>";

	if (isset($ignore)) {
		$ign_usr = str_replace("----",", ",$ignore);
		echo "<span style=\"color:red !important; font-weight:bold;\">…&nbsp;ignoring $ign_usr</span><br>";
	}

	$show_online = "";
	$ghost = "";

	if ($chat_light != "no") echo _YOURINROOM." <span style = \"font-weight:bold; \">$wo</span>&nbsp; ";

	$rip = $own_ip;
	$sd = time();
	// $rip_nick = $rip.$nickname;

	// sicherstellen, dass die Datei existiert
	if (!file_exists($file1)) {
		// Versuche zu erzeugen, falls Ordnerrechte es erlauben
		$fh_tmp = @fopen($file1, "c");
		if ($fh_tmp) fclose($fh_tmp);
	}

	// Lock & Retry-Konfiguration
	$maxRetries = 6;
	$retryDelay = 20000; // 20 ms

	$fh = false;
	for ($try = 0; $try < $maxRetries; $try++) {
		$fh = @fopen($file1, "c+"); // create if not exists, read/write
		if ($fh === false) {
			usleep($retryDelay);
			continue;
		}
		// Blockierendes LOCK_EX verwenden, aber mit Retry-Logik oben
		if (flock($fh, LOCK_EX)) break;
		fclose($fh);
		$fh = false;
		usleep($retryDelay);
	}

	if ($fh === false) {
		// Datei nicht zugreifbar – statt fatal: kurz Rückgabe
		return "<span style='color:red' title='user_online: Datei locked or not writable'>⚠</span>";
	}

	// --- Dateiinhalt lesen ---
	rewind($fh);
	$lines = array();
	while (($line = fgets($fh)) !== false) {
		$lines[] = $line;
	}
	// einfache Filterung wie vorher
	$lines = array_filter($lines);

	// Variablen für Verarbeitung
	$array = array();
	$line2 = "";

	// lifetime wie vorher
	$lifetime = 60;

	foreach ($lines as $line) {
		$fp = strpos($line,'****');
		if ($fp === false) continue;

		// $nam1 = substr($line,0,$fp);	// = IP
		// $nam = $nam1;

		$sp = strpos($line,'++++');
		if ($sp === false) continue;
		$val = intval(substr($line,$fp+4,$sp-($fp+4)));	// = timestamp

		$online = trim(substr($line,$sp+4));	// = nick####
		$online2 = explode("####",$online);
		$online3 = $online2[0]; // = nick
		// $nam_online = $nam.$online3;	// = IP.nick

		if (strpos($line,"++++####") === false) { // verhindert Anzeige von mensch.png bei Shoutbox-User
			$array[] = $line;
		}

		$diff = $sd - $val;
		// if ($nam_online != $nickname."#*#*".$rip_nick) {
		if ($online3 !== $nickname) {
			if ($diff < $lifetime) {
				$line2 .= $line;
			}
		}
	}

	// --- Eigenen Eintrag bauen (wie vorher) ---
	$my = $rip."****".$sd."++++".$nickname."####";

	if( $detect->isiOS()){
		$os = "iOS";
	} elseif( $detect->isiPadOS() ){
		$os = "iPadOS";
	} elseif( $detect->isAndroidOS() ){
		$os = "Android";
	} else {
		$os = "";
	}

	if ($admintrue !== true || $watch !== true) {
		if( ($detect->isMobile() && !$detect->isTablet())){
			$my = $my."handy".$os;
		} elseif ( $detect->isTablet() ){
			$my = $my."tablet".$os;
		} else {
			$my = $my."";
		}
	} else {
		if( ($detect->isMobile() && !$detect->isTablet())){
			$my = $my."ghost----handy".$os;
		} elseif ( $detect->isTablet() ){
			$my = $my."ghost----tablet".$os;
		} else {
			$my = $my."ghost";
		}
	}

	if (isset($_COOKIE["afk"]) && $_COOKIE["afk"] == "afk") {
		$my = $my.'afk';
	}

	$my = $nickname."#*#*".$my." \n";

	// --- Hardcap: wer seit > (waermestube_timeout * 1.5) Min. keine echte Nachricht schrieb, ---
	// --- faellt hier aus der Liste. Fuer Auto-Refresher, die pollen, aber nie posten.         ---
	$evicted = false;
	$hardcap = (isset($waermestube_timeout) ? $waermestube_timeout : 30) * 60;	// Sekunden
	$letzte = 0;
	$lm_fh = @fopen("user/lastmsg.txt", "r");
	if ($lm_fh) {
		if (flock($lm_fh, LOCK_SH)) {
			while (($z = fgets($lm_fh)) !== false) {
				$p = explode("\t", trim($z), 2);
				if (isset($p[1]) && $p[0] === $nickname) { $letzte = (int)$p[1]; break; }
			}
			flock($lm_fh, LOCK_UN);
		}
		fclose($lm_fh);
	}
	// arrival = Sitzungsbeginn (Sekunden, PHP time()) ist IMMER der Boden. So schlaegt ein
	// frischer Login einen veralteten lastmsg-Eintrag (Nick war vor Stunden da, korrekt aus).
	$av = isset($_COOKIE['arrival']) ? (int)$_COOKIE['arrival'] : 0;
	if ($av > $letzte) { $letzte = $av; }
	if ($letzte === 0) { $letzte = $sd; }	// weder lastmsg noch arrival -> "jetzt", kein Fehlrauswurf
	if ($sd - $letzte > $hardcap) {
		$my = "";		// eigene Zeile nicht anhaengen -> User faellt aus ip_<wo>.txt
		$evicted = true;
	}

	$line3 = $line2.$my;

	// --- Datei neu schreiben (atomar in derselben handle) ---
	if (strlen($line3) > 0 || $evicted) {
		// Truncate + write
		ftruncate($fh, 0);
		rewind($fh);
		fwrite($fh, $line3);
		fflush($fh); // ensure written
		// keep lock bis zum Ende der Verarbeitung sicher
	}

	// Jetzt können wir das fh freigeben (die Datei wurde geschrieben)
	flock($fh, LOCK_UN);
	fclose($fh);

	// --- Array-Deduplikation und Sortierung wie vorher ---
	if (is_array($array)) {
		$array1 = array_unique($array);
		$array1 = $array;
	} else {
		$array1 = [];
	}


	$array = my_array_unique($array1); // diese Funktion entfernt doppelte User, auch wenn unterschiedliche IP
	// $array = $array1;

	natcasesort($array);

	// Ghost-Zählung (unverändert)
	if (isset($array_ghost)) {
		$arrcount = count($array_ghost) - 1;
		if ($arrcount >= 1) {
			$hidden = $arrcount;
			if ($hidden > 1) {
				// $ghost = "<li>...&nbsp;$hidden"._GUESTSLOGIN."</li>";
			} else {
				// $ghost = "<li>...&nbsp;$hidden"._GUESTLOGIN."</li>";
			}
		}
	}

	// --- Ausgabe erzeugen (wie zuvor, größtenteils unverändert) ---
	foreach ($array as $us) {
		if ($us == "") continue;

		$user = explode('++++',$us);
		$us_ip_part = explode('****',$us);
		$ip_link1 = $us_ip_part[0];
		$ip_link_part = explode('#*#*',$ip_link1);
		$ip_link = isset($ip_link_part[1]) ? $ip_link_part[1] : '';

		$us = isset($user[1]) ? $user[1] : $user[0];

		$us_part = explode('####',$us);
		$us_trim = $us_part[0];

		$us_ip = '<a onclick ="copyurl(\''.$ip_link.'\')" class="us_ip" style="opacity:.2;font-size:10px;" title="'.$ip_link.'">[IP]</a>';

		$part_ip = explode(" (",$us);
		$us1 = $part_ip[0];
		$temp = explode('####',$us);
		$us = $temp[0];
		$us_ghost= isset($temp[1]) ? $temp[1] : '';

		// gebannte / gemaulkorbte / nopv / igno Kennzeichnungen (wie zuvor)
		$bd = "";
		if (file_exists("user/ban.txt") && filesize("user/ban.txt") > 0) {
			$banned = file("user/ban.txt");
			foreach ($banned as $c) {
				$part1 = explode("****",$c);
				$part2 = explode("++++",$part1[1]);
				$nochraw = ($part2[0] - time()) / 60 + 1;
				$nochstunden = floor($nochraw /60);
				$nochminuten = floor(($nochraw - $nochstunden*60)) ;
				if ($nochminuten <= 9) { $nochminuten = '0'.$nochminuten;}
				$noch = '&nbsp;'.$nochstunden.':'.$nochminuten.'&nbsp;h';
				if ($part1[0] == $us && $part2[0] > time()) $bd = ' [ban\'d&nbsp;'.$noch.']';
			}
		}
		if (file_exists("user/maulkorb.txt") && filesize("user/maulkorb.txt") > 0) {
			$banned = file("user/maulkorb.txt");
			foreach ($banned as $c) {
				$part1 = explode("****",$c);
				$part2 = explode("++++",$part1[1]);
				$nochraw = ($part2[0] - time()) / 60 + 1;
				$nochstunden = floor($nochraw /60);
				$nochminuten = floor(($nochraw - $nochstunden*60)) ;
				if ($nochminuten <= 9) { $nochminuten = '0'.$nochminuten;}
				$noch = ' '.$nochstunden.':'.$nochminuten.' h';
				if ($part1[0] == $us && $part2[0] > time()) $bd = ' :-X '.$noch;
			}
		}
		if (file_exists("user/nopv.txt") && filesize("user/nopv.txt") > 0) {
			$banned = file("user/nopv.txt");
			foreach ($banned as $c) {
				$part1 = explode("****",$c);
				$part2 = explode("++++",$part1[1]);
				$nochraw = ($part2[0] - time()) / 60 + 1;
				$nochstunden = floor($nochraw /60);
				$nochminuten = floor(($nochraw - $nochstunden*60)) ;
				if ($nochminuten <= 9) { $nochminuten = '0'.$nochminuten;}
				$noch = ' '.$nochstunden.':'.$nochminuten.' h';
				if ($part1[0] == $us && $part2[0] > time()) $bd = ' <del>/pn</del> '.$noch;
			}
		}
		if (isset($ignore)) {
			if (strpos($ignore,$us_trim) !== false) {
				$bd .= '<span style="opacity:.8;font-size:10px;" > [igno]</span>';
			}
		}

		if (file_exists("profile/$us")) {
			$par=time();
			$profile_content = @file_get_contents("profile/$us");
			if ($profile_content === false) $profile_content = "";
			if( strpos($profile_content,'männlich') !== false) {
				$bd .= '&nbsp;<a href="popprof.php?test='.$par.'&amp;profil='.$us.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$us.' anschauen (Popup)"  ><img src="img/gender_masc.gif" alt="männlich"  height="14" ></a>';
			} elseif (strpos($profile_content,'weiblich') !== false) {
				$bd .= '&nbsp;<a href="popprof.php?test='.$par.'&amp;profil='.$us.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$us.' anschauen (Popup)"  ><img src="img/gender_fem.gif" alt="weiblich"  height="13"  ></a>';
			} else {
				$bd .= '&nbsp;<a href="popprof.php?test='.$par.'&amp;profil='.$us.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$us.' anschauen (Popup)"  ><img src="img/mensch.png" alt="Profil" title="Profil von '.$us.' anschauen (Popup)"  height="13" ></a>';
			}
		}

		// mods/admins/supporter/verified wie gehabt
		if (is_array($mods)) {
			foreach($mods as $key => $val2) {
				if ($us == trim($val2) && $us != ""   && (!isset($admins_no_mark) || in_array($us,$admins_no_mark) === false)) {
					$bd .= "&nbsp;$mod_mark";
				}
			}
		}

		if (in_array($us,$superadmin)) {
					$bd .= "&nbsp;$support_mark";
		}


		if (!in_array($us,$superadmin)) {
			if (is_array($admins)) {
				foreach($admins as $key => $val) {
					if ($us == trim($val) && $us != ""   && (!isset($admins_no_mark) || in_array($us,$admins_no_mark) === false) ) {
						$bd .= "&nbsp;$admin_mark";
					}
				}
			}
		}
		
		if (isset($verified_min) && file_exists("user/user.txt")) {
			$d2 = file("user/user.txt");
			foreach ($d2 as $d) {
				$part1 = explode("****",$d);
				if (isset($part1[4]) && $part1[4] >= $verified_min) {
					$verif = $part1[0];
					if ($verif == $us && file_exists("profile/$us")  
					&& strpos($bd,$mod_mark) === false 
					&& strpos($bd,$admin_mark) === false
					&& (empty($support_mark) || strpos($bd, $support_mark) === false)	
					) {
						// $bd .= "&nbsp;$verified";
						// $bd .= "&nbsp;<img src='".$verified."' height='14' title='".trim($part1[4])." days online'>";
						$bd .= "&nbsp;<img class='tip' src='".$verified."' height='14' title='".trim($part1[4])." days online'>";					}
				}
			}
		}

		// device-icons
		if (strpos($us_ghost,"iPadOS") !== false || (strpos($us_ghost,"iOS") !== false && strpos($us_ghost,"tablet") !== false) ) {
			$bd .= '&nbsp;<img src="img/ipad-solid.png" alt="iPad" title="ist mit einem iPad online"  height="13"  >';
		} elseif (strpos($us_ghost,"iOS") !== false) {
			$bd .= '&nbsp;<img src="img/Apple_logo_hollow.png" alt="iPhone" title="ist mit einem iPhone online"  height="13"  >';
		} elseif (strpos($us_ghost,"Android") !== false) {
			if (strpos($us_ghost,"handy") !== false) {
				$bd .= '&nbsp;<img src="img/handy.png" alt="📱" title="ist mit Handy online"  height="13"  >';
			}
			if (strpos($us_ghost,"tablet") !== false) {
				$bd .= '&nbsp;<img src="img/tablet.png" alt="Tablet" title="ist mit einem Tablet online"  height="13"  >';
			}
		} else {
			if (strpos($us_ghost,"handy") !== false) {
				$bd .= '&nbsp;<img src="img/handy.png" alt="📱" title="ist mit Handy online"  height="13"  >';
			}
			if (strpos($us_ghost,"tablet") !== false) {
				$bd .= '&nbsp;<img src="img/tablet.png" alt="Tablet" title="ist mit einem Tablet online"  height="13"  >';
			}
		}

		if (strpos($us_ghost,"ghost") !== false) {
			if ($superadmintrue !== false) {
				$bd .= $ghostpic;
			} else {
				$us = $bd = "";
			}
		}

		if (strpos($user[1],"ghost") === false || $superadmintrue === true) {
			if (strpos($us_ghost,"afk") !== false) {
				$bd .= ' <span style="opacity:.8;font-size:10px;" title="away from keyboard">[afk]</span>';
			}
			if ($showip === true) {
				$bd .= ' <span class="us_ip" style="opacity:.8;font-size:10px;" >'.$us_ip.'</span> ';
			}
		}

		// den nick anklickbar machen zum Absetzen einer PN:
		if ($us != $nickname) {
			if ($admintrue !== false) {
				if (isset($part_ip[1]) && $part_ip[1] !="") {
					$ip_anzeige = " ($part_ip[1]";
				} else {
					$ip_anzeige = "";
				}
				$bd = $bd.$ip_anzeige;
			}

			$buchstaben = "ABCDEFGHKLMNPQRSTUVWXYZ"; // Nur Großbuchstaben
			$zeichen = "abcdefghikmnopqrstuvwxyzABCDEFGHKLMNPQRSTUVWXYZ123456789"; // Buchstaben + Ziffern
			$stringlaenge = 6;

			$zufall = '';
			$zeichenlaenge = strlen($zeichen);
			$buchstabenlaenge = strlen($buchstaben);

			$zufall .= substr($buchstaben, mt_rand(0, $buchstabenlaenge - 1), 1);
			for ($i = 1; $i < $stringlaenge; $i++) {
				$zufall .= substr($zeichen, mt_rand(0, $zeichenlaenge - 1), 1);
			}

			if (strpos($user[1],"ghost") === false || $superadmintrue === true) {
				$show_online .= " <li> <a href=\"#\"  onclick=\"ads('@".$us." /pn'); return false; \"  oncontextmenu=\"ads('".$zufall."_pr @".$us."'); return false;    \">".$us."</a>".$bd." </li> ";
			}
		} else {
			$show_online .= " <li>▹ ".$us." (Du)".$bd." </li> ";
		}
	}

	// homelink fuer chat-light:
	if ($room != "rooms/$standard" && $chat_light == "yes") {
		$homelink = " [<a href=\"chat.php?room=$standard\">"._BACKTOSTD." $standard</a>]";
	} else {
		$homelink = "";
	}

	$line = "<span class=\"uo_head\" style=\"font-weight:bold\">"._INROOM." ".$wo.": </span> <ul> $show_online$ghost</ul> $homelink";
	if ($evicted) { $line .= "<!--IDLE_EVICTED-->"; }	// Marker: set_user() zeigt Overlay + setzt chatIdle

	return $line;
}


function linker($link) {
	global $room,
	$uhr,
	$datum,
	$links,
	$anonymizer,
	$th_dir,
	$own_ip,
	$sound;
	    
		
	// $link = preg_replace( '#\:\d+#','' , $link );
		   
	$linkx = $link;	// Unterscheiden, ob URL oder PN umgewandelt wird

	// Links, die direkt aus der Bing-Suche kommen nicht mit anderen Links kombinieren.
	if (strpos($link,"bing.net") > 0 || strpos($link,"gifer.com") > 0 ) {
		$pos_blank = strpos(ltrim($link)," ") +2;
		$link = substr($link,0,$pos_blank);
	}

	// Anm.: laut.fm/r-ph etc. werden weiter unten in shortlink2() vom
	// getimagesize()-Aufruf ausgeschlossen (siehe $skip_imagesize_hosts),
	// das frühere str_replace("r-ph","",$link) ist damit überflüssig.


	if (strpos($link,":http://") === false) {   // wegen http://tbn0.google.com/images?q=tbn:Cg5amOzrpIob9M:http://www.cclonline.com/
	$link = str_replace("http"," http",$link); // Leerzeichen vor dem URL erzwingen:
	}

	if (strpos($link,"https://") === false) {
		$link = str_replace("www."," www.",$link);
	$link = str_replace("http:// www.","http://www.",$link);
	}

	$link = str_replace("http://www.","www.",$link);
	$link = str_replace("www.","http://www.",$link);

	$link = str_replace("https://http://","https://",$link);

	if (strpos($link,"?cid") !== false) {
		$link = strtok($link, "?");
	}


	// wegen z.B. http://images.google.de/imgres?imgurl=http://www.enorma...:
	$link = str_replace("= http","=http",$link);
	
	$link = str_replace(".gif",".gif ",$link);
	$link = str_replace(".png",".png ",$link);
	$link = str_replace(".jpg",".jpg ",$link);
	$link = str_replace(".avif",".avif ",$link);
	$link = str_replace(".webp",".webp ",$link);

	// Nach den Spacer-Replacements oben hat eine URL wie
	//   https://example.com/foo.jpg?v=345
	// die Form
	//   https://example.com/foo.jpg ?v=345
	// Der Linker-Regex matcht dann nur bis ".jpg", der Rest "?v=345" bliebe
	// als verwaister Text stehen. Hier den Query-String hinter Medien-Endungen
	// (Bild/Video/Audio) komplett entfernen, bevor der Linker greift.
	$link = preg_replace(
		'#(\.(?:jpe?g|png|gif|webp|avif|svg|bmp|ico|mp4|m4v|mov|webm|ogv|mp3|m4a|wav|ogg|aac|flac))\s+\?[^\s"\'<>]*#i',
		'$1 ',
		$link
	);

	function shortlink2($matches) { 
		global $new_win,
		$nick,
		$admintrue,
		$modtrue,
		$imginclude,
		$th_dir,
		$links,
		$maxwidth,
		$maxheight,
		$show_x,
		$max_y,
		$connection,
		$directory,
		$abs_path,
		$own_ip,
		$is_fp;


		$matches[0] = str_replace("<","&lt;",$matches[0]);
		$matches[0] = str_replace(">","&gt;",$matches[0]);

		$nocache = false;
		if (strpos($matches[0],"profile") !== false) $nocache = true; // damit Profilbilder nicht gecacht werden


		$moresmileys = $matches[0]; // ermoeglicht more smileys auch mit imginclode no

		// abs. Pfad in  relativen Pfad umwandeln, wg. allow_url_fopen - braucht z.B. Lima-city
		// HTTP / HTTPS bestimmen
		if(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!='off' or $_SERVER['SERVER_PORT']==443) {
			$protocol='https';
		} else {
			$protocol='http';
		}

		$abs_path = "$protocol://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF']);
		$abs_path2 = "$protocol://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF']).'/';

		// $matches[0] = str_replace($abs_path2,"",$matches[0]);
		// $matches[0] = str_replace($abs_path,"",$matches[0]);
		$loc_link = str_replace($abs_path2,"",$matches[0]);
		$loc_link = str_replace($abs_path,"",$loc_link);
		// Relativen Pfad in absoluten Dateisystempfad umwandeln,
		// da CWD bei FPM/FastCGI nicht das Chat-Verzeichnis sein muss.
		if ($loc_link !== $matches[0] && strpos($loc_link, 'http') !== 0) {
			$loc_link = dirname($_SERVER['SCRIPT_FILENAME']) . '/' . $loc_link;
		}
				
		
		// damit getimagesize nicht bei externen Links aufgerufen wird (wenn der Server das nicht erlaubt):
		// Streaming-/Radio-URLs ausschließen, weil getimagesize() dort
		// hängen bleibt (HTML-Antwort, kein Bild) und ein PHP-Timeout produziert.
		// Liste bei Bedarf erweitern.
		// Hosts bei denen getimagesize() hängt (Webradio etc.)
		// Wichtig: Prüfung gegen Hostname-Teil der URL, nicht Substring des Pfads,
		// damit z.B. 'flaemingradio.de' nicht wegen 'radio.de' geblockt wird.
		$skip_imagesize_patterns = array(
			'#://(?:[^/]*\.)?laut\.fm(?:/|$)#i',     // laut.fm und subdomains
			'#://[^/]*laut-fm#i',
			'#://(?:[^/]*\.)?shoutcast\.com(?:/|$)#i',
			'#://(?:[^/]*\.)?icecast\.org(?:/|$)#i',
			'#://(?:[^/]*\.)?radio\.de(?:/|$)#i',    // nur radio.de als Domain, nicht flaemingradio.de
			'#[/.]stream[/.]#i',                       // /stream/ im Pfad
		);
		$skip_imagesize = false;
		foreach ($skip_imagesize_patterns as $pattern) {
			if (preg_match($pattern, $matches[0])) {
				$skip_imagesize = true;
				break;
			}
		}

		if (!$skip_imagesize) {

			if ($imginclude == "yes" || $admintrue !== false || $modtrue !== false || strpos($moresmileys,"/smileys") !== false) {

			$old_timeout = ini_get('default_socket_timeout');
			ini_set('default_socket_timeout', 3);
			$size = @getimagesize(trim($loc_link));
			ini_set('default_socket_timeout', $old_timeout);


			// Fallback: getimagesize() liefert nichts, aber URL hat Bild-Endung
			// → Bild optimistisch einbinden; onerror räumt ggf. auf.
			$has_image_ext = (bool) preg_match('#\\.(jpe?g|png|gif|webp|avif|svg|bmp)(?:\\?|\\#|$)#i', $matches[0]);
			if (!$size && $has_image_ext) {
				$href_safe = htmlspecialchars($matches[0], ENT_QUOTES);
				return ' <a class="pop" href="'.$matches[0].'" onclick="document.getElementById(\'line\').focus(); OpenNewWindow(this.href,800,600,\'\');return false;"><img alt="'._USERIMG.'" style="max-width:'.$maxwidth.'px;max-height:'.$maxheight.'px" onerror="this.parentNode.outerHTML=\'<a href=&quot;'.$href_safe.'&quot; target=&quot;_blank&quot; rel=&quot;nofollow noopener&quot;>'.$href_safe.'</a>\'" src="'.$matches[0].'" /></a> ';
			}
			
			// return 'Typ: '.$size[2];
			// return $loc_link;

			if ($size[2] == 1 || $size[2] == 2 || $size[2] == 3 || $size[2] == 18 || $size[2] == 19 ) {
									
				$orgwidth = $size[0];
				$orgheight = $size[1];

				// $size[0]/$size[1] bei AVIF erst ab PHP 8.2 befüllt
				if ((!$orgwidth || !$orgheight) && $size[2] == 19) {
					if (extension_loaded('imagick')) {
						try {
							$image = new Imagick($loc_link);
							$orgwidth = $image->getImageWidth();
							$orgheight = $image->getImageHeight();
						} catch (Exception $e) {
							// Imagick gescheitert → Link-Fallback
						}
					}
				}

				if (!$orgwidth || !$orgheight) {
					return ' <a href="'.$matches[0].'" target="_blank" rel="nofollow noopener">'.$matches[0].'</a> ';
				}
									
				$width = $maxwidth;
				$height = $maxheight;


					$ratio = $orgwidth / $orgheight;
					if ($orgwidth >= $show_x) {$orgwidth = $show_x; $orgheight = $show_x / $ratio;} // Hochformat nicht beruecksichtigt

					// wg. Browser min Popup-width
					if ($orgwidth < 190) {
						$popheight = $orgheight * (190/$orgwidth);
						$popwidth  = $popheight * $ratio +20;
					} else {
						$popheight = $orgheight;
						$popwidth  = $orgwidth +20;
					}

				if (($orgheight / $height) > 1.5) {	// popup nur wenn > 150% von thumb	(nicht _pr)

						if (strpos($matches[0],$own_ip) !== false) {
							$th_dir = str_replace ('upload/','tn_upload/',$matches[0]);
							$th_dir = str_replace ('/upload/','/tn_upload/',$matches[0]);
						} else {
							$th_dir = $matches[0];
						}
						
						
						return ' <a class="pop" href="'.$matches[0].'"  onclick="document.getElementById(\'line\').focus(); OpenNewWindow(this.href,'.$popwidth.','.$popheight.',\'\');return false;" ><img alt="'._USERIMG.'"  onerror="this.style.display=\'none\'" src="'.$th_dir.'"   /></a> ';


					} else {
						$onklick = 'onclick="ads(\''.$matches[0].'\'); return false; "';return ' <img oncontextmenu="max(this);return false;" '.$onklick.' style="cursor:pointer" alt="'._USERIMG.'"  onerror="this.style.display=\'none\'" src="'.$matches[0].'"  /> ';
					}

				}
			}
		}


		if ($new_win == "yes" && strpos($matches[0],'/reg.php') === false) {
			$linktarget = "target=\"_blank\" title=\"Link öffnet in neuem Tab/Fenster\"";
			$ext_hinweis = "<span class=\"dot\">"._LNKNEWWIN.": </span>";
		} else {
			$linktarget = "";
			$ext_hinweis = "";
		}


		if (isset($links) && $links == "no" && $admintrue === false) return _NOLINK;

		// if (strlen($matches[0]) > 37 && strpos($matches[0],'/smileys4') === false ) {
		if (strlen($matches[0]) > 37) {
			return $ext_hinweis.'<a href="'.$matches[0].'" rel="nofollow" '.$linktarget.'>'.substr($matches[0],0,30).' ...</a>';

		} else {
			return $ext_hinweis.'<a href="'.$matches[0].'" rel="nofollow" '.$linktarget.'>'.$matches[0].'</a>';

		}
	}

	$link = preg_replace("/([\S+\.\/]+\@(\[?)[\S+\.]+\.([a-zA-Z0-9]{2,6})(\]?))/i","<a href=\"mailto:$1\" rel=\"nofollow\">$1</a>",$link);

	$link = preg_replace_callback("/([\w]+:\/\/[\S+\.\/\@]+[\w\/])/i","shortlink2", $link);

	
	// Einladung in private Raeume zum Link umwandeln:
	if ($link == $linkx && strpos($link,"/del") === false) {
	
		$link = preg_replace("/(\b\w+_pr\b)/",''."  ▶︎ <a href=\"chat.php?room=$1\" onclick=\"prbox(this.href); return false;\" > "._INVITEPR2."</a>",$link);
	
		// wird immer pn #1609	
		// if (strpos($link,"/pn") === false) {
		// 	$link = preg_replace("/(\b\w+_pr\b)/",_INVITEPR." <a href=\"chat.php?room=$1\" onclick=\"prbox(this.href); return false;\" >$1</a><br>"._INVITEADVISE."", $link);
		// } else {
		//
		// 	$link = preg_replace("/(\b\w+_pr\b)/",''."  ▶︎ <a href=\"chat.php?room=$1\" onclick=\"prbox(this.href); return false;\" > "._INVITEPR2."</a>",$link);
		//
		// }
	}
	return $link;
}

	
function colorify_ip($ip) {
	global $room,$d,$setcolor,$s;

	if ($setcolor != "") {
		$color = $setcolor;
	} else {

		// IPv6 zu IPv4-Format umwandeln:
		if(filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
		//if (strpos($ip,":") !== false) {
			$ipparts = explode(":",$ip);
			$z = count($ipparts);

			$ip = hexdec(substr($ipparts[$z-4],0,2)).'.'.
			hexdec(substr($ipparts[$z-3],0,2)).'.'.
			hexdec(substr($ipparts[$z-2],0,2)).'.'.
			hexdec(substr($ipparts[$z-1],0,2)).'.';
		}


	$parts = explode(".", $ip);

	// Dunkles Grau in Richtung Rot verschieben:
	if ($parts[1] < 10) {$parts[1] = $parts[1]+200;}
	if ($parts[1] < 100) {$parts[1] = $parts[1]+100;}


	$color = sprintf("%02s", dechex($parts[1])) .
			sprintf("%02s", dechex($parts[2])) .
			sprintf("%02s", dechex($parts[3]));

	}

	$color = str_replace("2","3",$color);
	$color = str_replace("1","2",$color);
	$color = str_replace("0","2",$color);

	$color = str_replace("C","b",$color);
	$color = str_replace("c","b",$color);
	$color = str_replace("D","b",$color);
	$color = str_replace("d","b",$color);
	$color = str_replace("E","b",$color);
	$color = str_replace("e","b",$color);
	$color = str_replace("F","b",$color);
	$color = str_replace("f","b",$color);

	$color = str_replace("b","a",$color);


	return $color;
}


function textWrap($text) {
	$new_text = '';
	$text_1 = explode('>',$text);
	$sizeof = sizeof($text_1);
	for ($i=0; $i<$sizeof; ++$i) {
		$text_2 = explode('<',$text_1[$i]);
		if (!empty($text_2[0])) {
			$new_text .= preg_replace('#([^\n\r ]{35})#i', '\\1<wbr>', $text_2[0]);  // auch ..... umbrechen
		}
		if (!empty($text_2[1])) {
			$new_text .= '<' . $text_2[1] . '>';
		}
	}
	return $new_text;
}

function my_array_unique($arr) {
	$found = array();
	foreach ($arr as $key=>$val) {
		// Abfrage, ob Nick bereits mindestens ein Mal gefunden wurde
		$teile = explode("#*#*", $val);
		$val = $teile[0];		

		if (isset($found[$val])) {
			// falls ja wird der Wert aus dem Array entfernt
			unset($arr[$key]);
		}
		
		$found[$val] = true;
	}
	return $arr;
}


function add_line($msg) {
	global $room,
	$roomexists,
	$smileys,
	$admintrue,
	$superadmintrue,
	$modtrue,
	$nickname,
	$flood,
	$closepr,
	$shoutbox,
	$mods,
	$mod_rooms,
	$watch,
	$ignore,
	$maxwidth,
	$time_offset,
	$prof_array,
	$in_regdb,
	$anonymizer,
	$bis_offen,
	$ab_offen,
	$imginclude,
	$ip_write,
	$links,
	$showip,
	$reg_only_viewprof,
	$logfile,
	$topic_scroll,
	$own_ip,
	$abs_path,
	$gema,
	$usercolor,
	$setcolor,
	$vidallow,
	$interne,
	$smiley_dirs,
	$user_whisperroom,
	$max_length;

	$Gueltigkeit = time()+86400*360;	// cookie gilt 360 Tage


	if (strpos($msg,"&shy;Chatbot") !== false) {
		$nickname = "Chatbot";
		$msg = str_replace("&shy;Chatbot:",'',$msg);		
	}


	$wo = trim(substr($room,6));
	if (strlen($msg)> 3000) {exit;} // weil maxlength ueberlistet werden kann.


	if ($wo == "Intern") {
		if (!in_array($nickname,$interne) && $admintrue === false ) {
			exit();
		}
	}

	if ($wo == "Modis" || $wo == "Mods") {
		if ($modtrue === false && $admintrue === false ) {
			exit();
		}
	}


	// Chat nicht zeigen, wenn offline: ACHTUNG! Ausnahmen auch in function refresh()
	if ($admintrue !== true) {
		if ((file_exists("rooms/Offline")&& (strpos($room,"_pr") === false) || (strpos($room,"_pr") !== false && $closepr != "no"))) {
			exit();
		}
	}

	
	// Admin und Mod darf loeschen, und jedermann in privaten Raeumen:
	if (strpos($msg," /clear") !== false) {
		if ($admintrue !== false || $modtrue !== false || strpos($wo,"_pr") !== false) {
			// Inhalt vor dem clearen archivieren:
			if (isset($logfile) && $logfile == "on" ) {
				
				$handle = fopen ($room, "r");
				$contents = fread ($handle, filesize ($room));
				fclose ($handle);
				$lines = explode("\n",$contents);

				foreach($lines as $oeftl) {
					$tolog[] = $oeftl;
				}

				$contents = implode("\n",$tolog);

				// jetzt rel. img Pfade fuers Archiv anpassen:
				$contents = preg_replace('/smileys\d{1,2}\//', '../$0', $contents);
				$contents = str_replace("profile/","../profile/",$contents);
				$contents = str_replace("img/","../img/",$contents);
				// $contents = str_replace("chat/../upload/","chat/upload/",$contents);
				// $contents = str_replace("tn_../upload/","../tn_upload/",$contents);

				$contents = str_replace("popprof.php","../popprof.php",$contents);
				  
				// IPv4:
				$contents = preg_replace('~(\d+)\.(\d+)\.(\d+)\.(\d+)~', "$1.$2.$3.x", $contents);

				// IPv6 (alle Formen):
				if (strpos($contents,"::") !== false) {
					$contents = preg_replace('~([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*)~', "$1:$2:$3:$4:$5:x:x", $contents);
				} else {
					$contents = preg_replace('~([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*):([\dA-Fa-f]*)~', "$1:$2:$3:$4:$5:$6:x:x", $contents);
				}

				$fprot = fopen("logs/".$wo."_log", "a");
				flock($fprot,LOCK_EX);
				fwrite($fprot, $contents);
				fflush($fprot);
				flock($fprot,LOCK_UN);
				fclose($fprot);
			}
		
			$fd = fopen("$room", "w+");
			fclose($fd);
		}
	}


	//	if (file_exists("ban_inc.php")) include("ban_inc.php");
	if (file_exists("user/ban.txt")) {
		$banned = file("user/ban.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);
			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $own_ip;

				if ($part1[0] == $nickname
					|| (trim($rip) == trim($part2[1]) && !isset($nickname))
				)  {
					exit();
				}
			}
		}
	}

	if (file_exists("user/maulkorb.txt")) {
		$banned = file("user/maulkorb.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);

			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $own_ip;

				if ($part1[0] == $nickname
					|| (trim($rip) == trim($part2[1]) && !isset($nickname))
				)  {
					exit;
				}
			}
		}
	}

	if (file_exists("user/nopv.txt")) {
		$banned = file("user/nopv.txt");
		foreach ($banned as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);

			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $own_ip;

				if ($part1[0] == $nickname
					|| (trim($rip) == trim($part2[1]) && !isset($nickname))
				)  {
					
					if (strpos($msg,"/pn") !== false) {
						$msg = str_replace("/pn","",$msg);
						$msg .=  "(Du darfst leider nicht füstern!)";
					}
					if (strpos($msg,"_pr") !== false) {
						$msg = str_replace("_pr","",$msg);
						$msg .= " (Du kannst auch keinen Privatraum erstellen!)";
					}
				}
			}
		}
	}


	// --- Zeitstempel "letzte echte Nachricht" (Server-Gegenstueck zum last-Cookie). ---
	// --- Basis fuer den Hardcap in user_online(): nur wer postet, bleibt gelistet.    ---
	if (isset($nickname) && $nickname !== "") {
		$lm_fh = @fopen("user/lastmsg.txt", "c+");
		if ($lm_fh && flock($lm_fh, LOCK_EX)) {
			$lm_now  = time();
			$lm_keep = array();
			rewind($lm_fh);
			while (($z = fgets($lm_fh)) !== false) {
				$p = explode("\t", trim($z), 2);
				if (!isset($p[1]))                continue;
				if ($p[0] === $nickname)          continue;	// alten Eintrag ersetzen
				if ($lm_now - (int)$p[1] > 86400) continue;	// > 24 h: aufraeumen
				$lm_keep[] = $p[0]."\t".$p[1];
			}
			$lm_keep[] = $nickname."\t".$lm_now;
			ftruncate($lm_fh, 0);
			rewind($lm_fh);
			fwrite($lm_fh, implode("\n", $lm_keep)."\n");
			fflush($lm_fh);
			flock($lm_fh, LOCK_UN);
		}
		if ($lm_fh) fclose($lm_fh);
	}

	// nur Admin darf Raeume loeschen:
	if (strpos($msg,"/del ") && $admintrue !== false) {
		
		if (strpos($msg,"offline")) {$msg = str_replace("offline","Offline",$msg);}
		$del_file = explode("/del ",$msg);

		if(file_exists("rooms/$del_file[1]")) {
			unlink("rooms/$del_file[1]");
		}
		$msg = $msg." /pn";	// /del wird immer /pn, und damit nur fuer den Admin sichtbar
	}

	if (strpos($msg,"/alarm ") && $admintrue !== false) {
		$msg = $msg." /pn";	// /alarm wird immer /pn
	}


	$msg = $msg." ";       // damit die Abfragen nach ganzen Woertern funktionieren


	// hier wird bei Bedarf die Systemzeit geaendert
	$time_off = 0;
	if(isset($time_offset)) $time_off = $time_offset * 3600;


	$dt0 = date("d.m.", time() + $time_off);
	$dt = "<span class=\"dt\">$dt0</span>";
	
        
	$uhr0 = date("H:i:s", time() + $time_off);
	$uhr = "<span class=\"uz\">$uhr0</span>";


	$msg = str_replace("<","&lt;",$msg);
	$msg = str_replace(">","&gt;",$msg);
	$msg = strip_tags(stripslashes($msg));


	$msg = str_replace("("._MESSAGE.")","",$msg); // falls das stehen bleibt, z.B. bei drag & drop
	$msg = str_replace(_MESSAGE,"",$msg); // falls das stehen bleibt, z.B. bei drag & drop


	$msg_explode = explode(":",$msg,2);

	$msg_explode[0] = $nickname;


	// Profile:
	if (strpos($msg_explode[1],"/profil ") || strpos($msg_explode[1],"/profile ")) {
	

		if ($in_regdb !== true && $reg_only_viewprof === true ) {
			$msg_explode[1] = _SHOW_PROFIL.' /pn';
		} else {
			if (strpos($msg_explode[1],"/profile")) $msg_explode[1] = str_replace("/profile","/profil",$msg_explode[1]);

			$profile_file = trim(str_replace("/profil ","",$msg_explode[1]));

			// Text hinter /profil wegmachen
			$temp = explode(" ",$profile_file,2);
			$profile_file = $temp[0];


			if(file_exists("profile/$profile_file")) {
				$lines = file("profile/$profile_file");

				$profiletime = filemtime("profile/$profile_file");
				$dt7 = date("(d.m.y H:i \U\h\\r) ", $profiletime);

				for($i=1;$i<count($lines);$i++) {
					// leere nicht anzeigen
					if (trim($lines[$i]) != "Hobbys:&nbsp;"
					&& trim($lines[$i]) != "kein Bild &nbsp;"
					&& trim($lines[$i]) != "&nbsp;"
					&& trim($lines[$i]) != ""
					&& trim($lines[$i]) != "Geschlecht:&nbsp;"
					&& trim($lines[$i]) != "Alter:&nbsp;"
					&& trim($lines[$i]) != "Wohnort:&nbsp;"
					&& trim($lines[$i]) != "Sternzeichen:&nbsp;"
					&& trim($lines[$i]) != "E-Mail:&nbsp;"
					&& trim($lines[$i]) != "Bemerkung:&nbsp;"
					&& trim($lines[$i]) != "wei&szlig; nicht"
					) {
						$zeile = $zeile."<br>".trim($lines[$i]);
					}
					$zeile = str_replace("E-Mail:&nbsp;","E-Mail: ",$zeile); // das ist noetig wg. auto-E-Mail
					$zeile = str_replace("@","(at)",$zeile); // weil sonst die Profilanzeige gefluester wird
				}

				if ($zeile == "") {
					$msg_explode[1] = str_replace("/profil ","",$msg_explode[1]);

					$msg_explode[1] = $msg_explode[1]." hat kein Profil angelegt. /pn";

					if(file_exists("profile/$profile_file")) {
						unlink("profile/$profile_file");
					}

				} else {
					$msg_explode[1] = ':br:<b>Profil von '.$profile_file.':</b> '.$dt7.$zeile.' /pn'; // /profile wird immer /pn, und damit nur fuer den Absender sichtbar
				}

			} else {
				$msg_explode[1] = str_replace("/profil ","",$msg_explode[1]);
				$msg_explode[1] = $msg_explode[1]." hat kein Profil angelegt. /pn";
			}
		}
	}


	// alle Profile auflisten (nur Admin):
	if (strpos($msg_explode[1],"/showprofil") && $admintrue !== false) {
		$zeile = "<b> Alle User mit Profil:</b>:br:";

		natcasesort($prof_array);
		$prof_array = array_values($prof_array);

		// jpg und gif nicht zeigen:
		for($i=0;$i<count($prof_array);$i++) {
			$filename = $prof_array[$i];

				// Dateien, die mit '.' beginnen, überspringen
				if (isset($filename[0]) && $filename[0] === '.') {
					continue;
				}
							
			if (strpos($prof_array[$i],"jpg") === false && strpos($prof_array[$i],"gif") === false) {

				$prof_link = "<a href=\"#\" onclick=\"ads('/profil ".$prof_array[$i]."'); return false; \">".$prof_array[$i]."</a><br>  ";
				$all_prof = $all_prof.$prof_link;
			}
		}

		$msg_explode[1] = $zeile.$all_prof.' /pn';
	}

	// alle Videos auflisten (nur Admin):
	if (strpos($msg_explode[1],"/showvideo") && ($admintrue !== false || $vidallow = "alle")) {
		  
		$vid_array[] = "";
		$dir6 = 'upload/';
		if ($handle = opendir($dir6)) {
			// $profil_kz = '';
			// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
			while (false !== ($file = readdir($handle))) {

				if($file != "."
					&& $file != ".."
						&& $file != ".htaccess"
				){
					$vid_array[] = $file;
				}
			}
		}


		$zeile = "<b> Alle Videos:</b><br>";

		for($i=0;$i<count($vid_array);$i++) {
			if (strpos($vid_array[$i],"mp4") !== false || strpos($vid_array[$i],"m4v") !== false  || strpos($vid_array[$i],"webm") !== false || strpos($vid_array[$i],"mov") !== false || strpos($vid_array[$i],"MOV") !== false) { $vid_link .= "<a href=\"upload\/$vid_array[$i]\" onclick=\"ads('upload\/".$vid_array[$i]."'); return false; \">".$vid_array[$i]."</a><br>  ";}
		}
		$msg_explode[1] = $zeile.$vid_link.' /pn';
	}


	// smileys löschen:
	// nur Admin darf das:
	// alle Smileys in dir löschen:
	for($i = 0; $i <= count($smiley_dirs); $i++){
		if (strpos($msg_explode[1],"/del_all_smileys_in_box") !== false && strpos($msg_explode[1],"$i ")  !== false  && $admintrue !== false) {
			if (file_exists("smileys$i")) {
				$dir = "smileys$i/";
				mkdir("savsmileys$i", 0775);
				
				foreach(glob($dir.'*.*') as $v){
					copy($v, 'sav'.$v); // zuerst alle files sichern.
					unlink($v);
				}
				$msg_explode[1] = "Alle Smileys in der Box $i wurden gelöscht. /pn";
			} 
		}
	}


	// einzelne Smileys löschen:
	if (strpos($msg_explode[1],"/del_smiley ") !== false  && $admintrue !== false) {
			
		// for($i=1; $i <= 12; $i++) {
		for($i = 0; $i <= count($smiley_dirs); $i++){
			// if ($i < 10 && file_exists('smileys11')) {
			// 	$n = '0'.$i;
			// } else {
				$n = $i;
			// }

			if (file_exists("smileys$i")) {
				$bilder = array();
								
				$verz = "smileys$i";

				$dir1=opendir($verz);

				while (false !== ($file = readdir($dir1))) {
					if(strpos($file,".gif") !== false || strpos($file,".png") !== false || strpos($file,".mp4") !== false) {
						$bilder[] = $file;
					}
				}
				sort($bilder);

				$alphabet = '0abcdefghijklmnopqrstuvwxyz';
				$alf = substr($alphabet,$n, 1);


				$k = 1;
				foreach($bilder as $wert) {
					$link = str_replace($wert,':'.$alf.$k.':',$wert);
					$shortcut[] = $link;

					if (strpos($wert,".gif") !== false || strpos($wert,".png") !== false || strpos($wert,".mp4") !== false) {
						$long[] = $verz.'/'.$wert;
						$k++;
					} else {
						// $long[] = $wert;
					}

				}
			}
		}


		$msg_explode[1] = str_replace($shortcut, $long, $msg_explode[1]);
	
	// if (strpos($msg_explode[1],"/del_smiley ") && (strpos($msg_explode[1],".gif ") || strpos($msg_explode[1],".png ") || strpos($msg_explode[1],".mp3 ") || strpos($msg_explode[1],".mp4 ")) && strpos($msg_explode[1],"/smiley") && $admintrue !== false) {

		$url = str_replace("/del_smiley "," ",$msg_explode[1]);
		

		$path = pathinfo($url);
		$datei = $path['basename'];
		$verz = explode('/', $path['dirname']);
		$verz = end($verz);
		$smil_datei = $verz.'/'.$datei;
		$smil_datei = trim($smil_datei);

		$nr = str_replace("smileys","",$verz);

		if (file_exists($smil_datei) === true) {
			if (unlink($smil_datei) === true ) {
				if (strpos($smil_datei,'.mp4') !== false ) {
					$msg_explode[1] = " Das Video wurde aus Box $nr gelöscht. /pn";
				} elseif (strpos($smil_datei,'.mp3') !== false ) {
						$msg_explode[1] = " Das Audio wurde aus Box $nr gelöscht. /pn";
				} else {
					$msg_explode[1] = " Das Smiley  <img src='$smil_datei' > wurde aus Box $nr gelöscht. /pn";
				}
			} else {
				$msg_explode[1] = ' Das Smiley '.$smil_datei.'  konnte nicht gelöscht werden! /pn';
			}
		} else {
			$msg_explode[1] = ' Das Smiley '.$smil_datei.' ist nicht vorhanden! /pn';
		}

	}

	// function add_smiley($a,$b) {

	if (file_exists('add_inc.php')) {include('add_inc.php');}

	// Einladung in _pr immer /pn
	if (strpos($msg_explode[1],"_pr") !== false ) {
		$msg_explode[1] .= " /pn";
	}


	if (trim($msg_explode[1]) == "" && $admintrue === false) exit();  // verhindert den Nickwechsel ohne Meldung


	// Die Zeilenloeschfunktion fuer den Admin - Achtung! sehr maechtig:
	if (strpos($msg_explode[1],"/erase ") !== false && ($admintrue !== false || $modtrue !== false)) {
		$del_line = explode("/erase ",$msg_explode[1]);
		$weg = trim($del_line[1]);
		$weg = str_replace('@','',$weg);
		if (strlen($weg) >= 2) { // einen Buchstaben nicht zulassen
			$zu_aendernder_array = file($room);
			$geaenderter = array();

			foreach($zu_aendernder_array as $zeile) {
				// der User sieht die Loeschung seiner Nachricht fuer die Dauer einer /pn
				//$pos3 = false;
				$pos3 = strpos($zeile,'<span class="ip">');

				$pos4 = strpos($zeile,'<span class="hello">');	// Mods können Hello nicht löschen, nur Admins	
				if ($pos4 !== false && $modtrue !== false) {
					$msg_del = $zeile;
				} elseif ($pos3 !== false) {
					$zeile2 = substr($zeile,0,$pos3)."</p>\n";
					$zeile2 = str_replace('</span>  </p>','</span></p>', $zeile2);							
					$zeile2 = str_replace('</span> </p>','</span></p>', $zeile2);							
					$msg_del = str_replace ('</span></p>',' <span style="display:none"> /pn </span><span style="color:red !important"> [message deleted]</span></span></p>', $zeile2 );
				} else {
					$zeile = str_replace('</span>  </p>','</span></p>', $zeile);							
					$zeile = str_replace('</span> </p>','</span></p>', $zeile);							
					$msg_del = str_replace ('</span></p>',' <span style="display:none"> /pn </span><span style="color:red !important"> [message deleted]</span></span></p>', $zeile );
				}
	
				if (strpos($zeile,$weg) === false) {
					array_push($geaenderter,$zeile);
				} else {
					array_push($geaenderter,$msg_del);	
				}
			}

			$datei_handle = fopen($room,'w');
			$fertisch = implode("",$geaenderter);
			flock($datei_handle,LOCK_EX);
			fwrite($datei_handle,$fertisch);
			fflush($datei_handle);
			flock($datei_handle,LOCK_UN);
			fclose($datei_handle);
		}
	}


	// msg anpinnen fuer Admin und Mod:
	if (strpos($msg_explode[1],"/stick ") !== false && ($admintrue !== false || $modtrue !== false)) {
		$msg_explode[1] = '/pn '.$msg_explode[1]; 
		$del_line = explode("/stick ",$msg_explode[1]);
		$weg = trim($del_line[1]);
		
		if (strlen($weg) >= 2) { // einen Buchstaben nicht zulassen
			$zu_aendernder_array = file($room);
			$geaenderter = array();

			foreach($zu_aendernder_array as $zeile) {
	
				if (strpos($zeile,$weg) === false) {
					array_push($geaenderter,$zeile);
				} else {
					// $msg_pin = str_replace (' class="bg"','', $zeile );
					$msg_pin = str_replace ('<p>','<p class="pin">', $zeile );
					$msg_pin = str_replace ('"bg"','"pin"', $msg_pin );
					$msg_pin = str_replace ('"bm"','"pin"', $msg_pin );
					array_push($geaenderter,$msg_pin);	
				}
			}

			$datei_handle = fopen($room,'w');
			$fertisch = implode("",$geaenderter);
			flock($datei_handle,LOCK_EX);
			fwrite($datei_handle,$fertisch);
			fflush($datei_handle);
			flock($datei_handle,LOCK_UN);
			fclose($datei_handle);
		}
	}


	// immer nur ein mp3 anzeigen - Ausnahme smileys-Ordner
	if (isset($gema) && $gema === true) {
		if (strpos($msg_explode[1],".mp3 ") && strpos($msg_explode[1],"/upload/")) {
			$zu_aendernder_array = file($room);
			$geaenderter = array();

			foreach($zu_aendernder_array as $zeile) {
				if (strpos($zeile,"playmp3") === false || strpos($zeile,"smileys/")) {
					array_push($geaenderter,$zeile);
				}
			}

			$datei_handle = fopen($room,'w');
			$fertisch = implode("",$geaenderter);
			flock($datei_handle,LOCK_EX);
			fwrite($datei_handle,$fertisch);
			fflush($datei_handle);
			flock($datei_handle,LOCK_UN);
			fclose($datei_handle);
		}
	}


	// Mod approve:
	if (file_exists("mod_approve.php")) {
		include("mod_approve.php");
	}


	// Topic setzen:
	if(strpos($msg_explode[1],"/topic") !== false && $admintrue !== false) {
		if (strpos(strtolower($wo),"_pr") !== false) {
			$msg_explode[1] = '/pn '._NOTOPIC;
		} else {

			$topicfile = 'topics/'.$wo.'_topic.txt';
			$topic = str_replace("/topicscroll","",$msg_explode[1]);
			$topic = str_replace("/topic","",$topic);
			// $topic = trim(nl2br($topic));
			

			$topic = str_replace("topicscroll","",$topic);
			$topic = trim(str_replace("scroll","",$topic));
			// if (trim($topic) != "") {
			// 	$topic = ' +++ '.$topic.' +++ '.$topic.' +++ '.$topic.' +++ '.$topic.' +++ '.$topic.' +++ '.$topic.' +++ '.$topic.' +++ '.$topic;
			// }
			
			// $msg_explode[1] = str_replace("/topic","/pn Topic gesetzt: ",$msg_explode[1]);
			$msg_explode[1] = "/pn Topic gesetzt - bitte lade die Seite neu.";
		 	
			$t = fopen($topicfile, "w");
			fwrite($t, $topic);
			fclose($t);
		}
	}


	// Chat offline schalten:
	if (strpos($msg_explode[1],"/offline ") && $admintrue !== false) {
		$open3 = fopen("rooms/Offline", "w");
		fwrite($open3,"");
		fclose($open3);
	}

	// // Fotos verpixeln:
	// if (strpos($msg_explode[1],"/pixelon ") && $admintrue !== false) {
	// 	if (is_file("_jmstv.php") === true && is_file("jmstv.php") !== true) {
	// 		rename("_jmstv.php","jmstv.php");
	// 	}
	// 	if (is_file("upload/_htaccess") === true && is_file("upload/.htaccess") !== true) {
	// 		rename("upload/_htaccess","upload/.htaccess");
	// 	}
	// 	if (is_file("tn_upload/_htaccess") === true && is_file("tn_upload/.htaccess") !== true) {
	// 		rename("tn_upload/_htaccess","tn_upload/.htaccess");
	// 	}
	// }
	//
	// // Fotos unverpixeln:
	// if (strpos($msg_explode[1],"/pixeloff ") && $admintrue !== false) {
	// 	if (is_file("jmstv.php") === true && is_file("_jmstv.php") !== true) {
	// 		rename("jmstv.php","_jmstv.php");
	// 	}
	// 	if (is_file("upload/.htaccess") === true && is_file("upload/_htaccess") !== true) {
	// 		rename("upload/.htaccess","upload/_htaccess");
	// 	}
	// 	if (is_file("tn_upload/.htaccess") === true && is_file("tn_upload/_htaccess") !== true) {
	// 		rename("tn_upload/.htaccess","tn_upload/_htaccess");
	// 	}
	// }
	//


	$msg_explode[0] = str_replace("*","",$msg_explode[0]); // weil sonst ban etc. nicht geht


	if (file_exists("bannen_inc.php")) include("bannen_inc.php");


	// ban etc. immer fluestern:
	if (strpos($msg_explode[1],"/ban ") !== false
		|| strpos($msg_explode[1],"/igno ") !== false
		|| strpos($msg_explode[1],"/ignor ") !== false
		|| strpos($msg_explode[1],"/ignore ") !== false
		|| strpos($msg_explode[1],"/show ") !== false
		|| strpos($msg_explode[1],"/maulkorb ") !== false
		|| strpos($msg_explode[1],"/offline ") !== false
		// || strpos($msg_explode[1],"/pixelon ") !== false
		// || strpos($msg_explode[1],"/pixeloff ") !== false
	) {
		$msg_explode[1] = str_replace("@","",$msg_explode[1]); // wg Eingabe per Mausklick
		$msg_explode[1] = $msg_explode[1]." /pn";
	}


	// /ghost aufheben, sobald der Admin was schreibt:
	if ($watch !== false && $admintrue !== false
		&& strpos(strtolower($msg_explode[1]),"/pn") === false
		&& strpos(strtolower($msg_explode[1]),"/approve") === false
		&& strpos(strtolower($msg_explode[1]),"/stop") === false
		&& strpos(strtolower($msg_explode[1]),"/go") === false
		&& strpos(strtolower($msg_explode[1]),"/peep") === false
		&& strpos(strtolower($msg_explode[1]),"/nopeep") === false
		&& strpos(strtolower($msg_explode[1]),"/ip") === false
		&& strpos(strtolower($msg_explode[1]),"/noip") === false
		&& strpos(strtolower($msg_explode[1]),"/erase") === false
		&& strpos(strtolower($msg_explode[1]),"/stick") === false
		&& strpos(strtolower($msg_explode[1]),"/profil") === false
		&& strpos(strtolower($msg_explode[1]),"/showprofil") === false
		&& strpos(strtolower($msg_explode[1]),"/clear") === false
		// && strpos(strtolower($msg_explode[1]),"/color") === false
	) {
		setcookie("watch", "");
	}

	if (strpos(strtolower($msg_explode[1]),"/pn") === false) {
		setcookie("afk", "");
	}


	//  /go nicht anzeigen:
	if (strpos($msg_explode[1],'/go ') !== false) {
		$msg_explode[1] = '';
	}


	// cookie setzen fuer /afk:	
	if (((stripos($msg_explode[1],'afk')  !== false || stripos($msg_explode[1],'a f k')  !== false ) && stripos($msg_explode[1],' sind ' ) === false && stripos($msg_explode[1],'ist ' ) === false && stripos($msg_explode[1],' war ' ) === false && stripos($msg_explode[1],' steht ' ) === false) || strpos($msg_explode[1],':tel') !== false || strpos($msg_explode[1],'☎️') !== false || strpos($msg_explode[1],':afk')  !== false) {
		setcookie("afk", "afk");
	}
	
	// weitere smileys to afk:
	if (file_exists("afk_inc.php")) include("afk_inc.php");

	// cookie setzen fuer /ghost:
	if (stripos($msg_explode[1],'/ghost') !== false && $admintrue !== false) {
		setcookie("watch", "on", $Gueltigkeit);
		$msg_explode[1] = preg_replace('/\/ghost/i','', $msg_explode[1]);
	}

	// cookie setzen fuer /peep:
	if (stripos($msg_explode[1],'/peep') !== false && $admintrue !== false) {
		if ($superadmintrue !== false) {
			setcookie("listen", "on",$Gueltigkeit);			
		} else {
			setcookie("listen", "on");			
		}
		$msg_explode[1] = preg_replace('/\/peep/i','', $msg_explode[1]);
	}

	// cookie /peep loeschen:
	if (stripos($msg_explode[1],'/nopeep') !== false) {
		setcookie("listen", "");
		$msg_explode[1] = preg_replace('/\/nopeep/i','', $msg_explode[1]);
	}

	// cookie setzen fuer /ip:
	if (strpos($msg_explode[1],'/ip') !== false && $admintrue !== false) {
		$msg_explode[1] = preg_replace('/\/ip/','', $msg_explode[1]);
	}

	// cookie /ip loeschen:
	if (strpos($msg_explode[1],'/noip') !== false) {
		$msg_explode[1] = preg_replace('/\/noip/','', $msg_explode[1]);
	}

	// /alarm nicht anzeigen:
	if (strpos(strtolower($msg_explode[1]),"/alarm ") !== false ) {
		$msg_explode[1] = str_replace("/alarm ","<span style='display:none'>/alarm</span> "._WAKEUP." ",$msg_explode[1]);
	}

	// /browser -> info:
	if (strpos(strtolower($msg_explode[1]),"/browser ") !== false ) {
		$msg_explode[1] = str_replace("/browser",$_SERVER["HTTP_USER_AGENT"],$msg_explode[1]);
	}

	// /approve nicht anzeigen:
	if (strpos(strtolower($msg_explode[1]),"/approve") !== false && $admintrue !== false) {  // Besucher sieht Fehlermeldung
		$msg_explode[1] = "";
	}
	// /stick nicht anzeigen:
	if (strpos(strtolower($msg_explode[1]),"/stick") !== false && ($admintrue !== false || $modtrue !== false)) {  // Besucher sieht Fehlermeldung
		$msg_explode[1] = "";
	}
	// /erase nicht anzeigen:
	if (strpos(strtolower($msg_explode[1]),"/erase") !== false

	// das folgende darf nicht sein, weil sonst wiederholtes /kick und /maul nicht geht
	&& strpos(strtolower($msg_explode[1]),"/ban") === false
		&& strpos(strtolower($msg_explode[1]),"/maulkorb") === false
	&& ($admintrue !== false || $modtrue !== false)) {  // Besucher sieht Fehlermeldung
		$msg_explode[1] = "";
	}


	// cookie setzen fuer /ignore:
	if (strpos($msg_explode[1],'/igno') !== false) {

		$d = $msg_explode[1];
		$d = str_replace("/ignore","",$d);
		$d = str_replace("/ignor","",$d);
		$d = str_replace("/igno","",$d);
		$d = str_replace("/pn","",$d);
		$d = trim($d);
		
			
		// if ((!in_array($d, $admins) && !in_array($d, $mods) && $nickname != $d) || $admintrue !== false ) {
		if (!in_array($d, $admins) && !in_array($d, $mods) && $nickname != $d) {
			
			$teile = explode(' ', $d, 2);
			$d = $teile[0];

			if (isset($ignore) && substr_count($ignore, '----') < 2 ) {
				$d = $ignore."----".$d;
				setcookie("ignore", $d, $Gueltigkeit);
			} else {
				setcookie("ignore", $d, $Gueltigkeit);
			}
		}

		$msg_explode[1] = '';

	}


	// /ignore wird aufgehoben durch /show (Loeschen des cookie):
	if (strpos($msg_explode[1],'/show') !== false) {
		setcookie("ignore", "", time() - 3600);
		$msg_explode[1] = '';
	}


	// Fluestern formatieren:
	if (strpos(strtolower($msg_explode[1]),'/pm') !== false) {
		$msg_explode[1] = str_replace('/pm','/pn', $msg_explode[1]);
	}

	// in moderierten Raeumen darf nur der Admin fluestern: -> besser waere evtl.: $user_whisper
	if ($admintrue !== true && in_array($wo, $mod_rooms) !== false && strpos(strtolower($msg_explode[1]),'/pn') !== false) {
		$msg_explode[1] = str_replace('/pn','', $msg_explode[1]);
	}

	foreach (['(flüstert mit Chatbot)', '(Frage an Chatbot)'] as $phrase) {
		$msg_explode[1] = str_ireplace(
			$phrase,
			'<span style="font-style:italic;">' . $phrase . '</span>',
			$msg_explode[1]
		);
		// $msg_explode[1] = str_replace('/pn','', $msg_explode[1]); dann löschen sich /pn nicht mehr
	}

	// Hinweis: Der frühere Zusatzfilter "&& strpos(...,'youtu') === false" wurde
	// entfernt. Er stammte aus der Zeit der yt_error-Restriktion, als YouTube-
	// Postings keinen Begleittext enthalten durften und /pn dort folglich nie
	// auftauchen konnte. Da Begleittext jetzt erlaubt ist, soll /pn auch in
	// YouTube-Postings als Flüstern-Trigger wirken.
	if (strpos(strtolower($msg_explode[1]),'/pn') !== false) {

		$msg_explode[1] = str_replace('/pn',' <span style="display:none">/pn</span>', $msg_explode[1]);
		$msg_explode[1] = str_replace('/PN',' <span style="display:none">/pn</span>', $msg_explode[1]);

		$suchmuster = '/ @\S+ /';
		preg_match($suchmuster, $msg_explode[1], $treffer);
		$an = rtrim(str_replace("@",_TO,$treffer[0]));

		$msg_explode[1] = " <span style=\"font-style:italic;\">("._WHISPER."$an)</span>".$msg_explode[1];
		$msg_explode[1] = preg_replace('/( @\S+ )/',' <span style="display:none">$1</span>', $msg_explode[1]);
	}


	$remote = $own_ip;
	// // generate unique-ish color for IP
	// if (!isset($usercolor)) {$usercolor = "auto";}
	// if ($usercolor=="auto") {
	// 	$color = colorify_ip($remote);
	// } else {
	// 	if (isset($setcolor)) {$color = $setcolor;}
	// }

	// default-Userfarbe:
	if (isset($setcolor)) {
		$color = $setcolor;
				
		// $d = $setcolor;
		//
		// // weisser Adler auf weissem Grund vermeiden:
		// $d = str_replace("D","C",$d);
		// $d = str_replace("d","c",$d);
		// $d = str_replace("E","C",$d);
		// $d = str_replace("e","c",$d);
		// $d = str_replace("F","C",$d);
		// $d = str_replace("f","c",$d);
		//
		// // Negerboxkampf im Tunnel vermeiden:
		// $d = str_replace("2","3",$d);
		// $d = str_replace("1","3",$d);
		// $d = str_replace("0","3",$d);
		//
		// setcookie("color", $d, $Gueltigkeit);
		// $color = $d;
		
	} elseif (isset($usercolor)) {
		$color = $usercolor;
	} else {
		// $color = "777777";
		$color = colorify_ip($remote);
	}


	// eigene Farbe fuer nick waehlen und in cookie speichern:
	// if (strpos($msg_explode[1],'/color #') !== false) {
	// 	// das letzte Vorkommen von /color waehlen: nur ab PHP5!
	// 	// deshalb eigene function: http://www.homepage-forum.de/showthread.php?p=156334
	// 	$lastpos = strripos($msg_explode[1],'/color #');
	// 	$last = substr($msg_explode[1],$lastpos);
	// 	$d = explode('/color #',$last,2);
	// 	$d = substr($d[1],0,6);
	//
	// 	// weisser Adler auf weissem Grund vermeiden:
	// 	$d = str_replace("D","C",$d);
	// 	$d = str_replace("d","c",$d);
	// 	$d = str_replace("E","C",$d);
	// 	$d = str_replace("e","c",$d);
	// 	$d = str_replace("F","C",$d);
	// 	$d = str_replace("f","c",$d);
	//
	// 	// Negerboxkampf im Tunnel vermeiden:
	// 	$d = str_replace("2","3",$d);
	// 	$d = str_replace("1","3",$d);
	// 	$d = str_replace("0","3",$d);
	//
	// 	setcookie("color", $d, $Gueltigkeit);
	// 	$color = $d;
	// }

	if ($color=="333333") {$color="666666";} // wg. dunkle Skins

	// // Farbwechsel verstecken:
	// if (strpos($msg_explode[1],'/color') !== false) {
	// 	$msg_explode[1] = preg_replace('/\/color #\S+\s/','', $msg_explode[1]);
	// }

	// leeren nick und leere msg nicht zulassen:
	if(trim($msg_explode[0])=="" || trim($msg_explode[1])=="" ) exit();


	// ########### Youtube ###########:
	$youtube="";

	// Falls der /pn-Block oben schon gelaufen ist, hat $msg_explode[1] einen
	// Whisper-Vorspann ("<span style=\"font-style:italic;\">(flüstert mit ...)</span>")
	// und versteckte Spans für /pn und @User. Mehrere nachfolgende Blöcke
	// (YouTube, MP4, WebM, MP3, :afk:-Smileys) überschreiben $msg_explode[1]
	// komplett – dabei ginge der Whisper-Vorspann verloren.
	// Lösung: Vorspann hier rausziehen, am Ende des Multimedia-Blocks wieder
	// voranstellen. Bei einem reinen Text- oder Bild-Posting (linker-Pfad) lässt
	// dieser Block den Vorspann unangetastet und das spätere Voranstellen wird
	// per "schon drin?"-Check übersprungen.
	$pn_prefix = '';
	if (strpos($msg_explode[1], '<span style="font-style:italic;">(') !== false
		|| strpos($msg_explode[1], '<span style="display:none">') !== false) {

		// Führenden Whisper-Hinweis abtrennen (steht am Anfang, mit Leerzeichen davor):
		if (preg_match('# <span style="font-style:italic;">\([^<]*\)</span>#', $msg_explode[1], $m)) {
			$pn_prefix .= $m[0];
			$msg_explode[1] = str_replace($m[0], '', $msg_explode[1]);
		}
		// Versteckte /pn- und @User-Spans rausziehen:
		if (preg_match_all('#<span style="display:none">[^<]*</span>#', $msg_explode[1], $mm)) {
			foreach ($mm[0] as $hidden) {
				$pn_prefix .= ' '.$hidden;
				$msg_explode[1] = str_replace($hidden, '', $msg_explode[1]);
			}
		}
		$msg_explode[1] = trim($msg_explode[1]);
	}


	// Link vom bereits geposteten (im Popup) gültig machen:
	if (strpos($msg_explode[1],'www.youtube-nocookie.com/embed') !== false) {
		$msg_explode[1] = trim(str_replace('www.youtube-nocookie.com/embed','youtu.be', $msg_explode[1]));
	}

	// YouTube1:
	if (strpos($msg_explode[1],'/youtube ') !== false) {
		$msg_explode[1] = htmlentities($msg_explode[1]); // MUSS hier stehen!
		$youtube = trim(str_replace('/youtube ','', $msg_explode[1]));
	}

	// YouTube2:
	elseif (strpos($msg_explode[1],'https://youtu.be/') !== false) {
		$msg_explode[1] = htmlentities($msg_explode[1]);
		// Regex extrahiert ID+Parameter direkt aus der URL, unabhängig von vorangehendem Text
		if (preg_match('#https://youtu\.be/([^\s&"<>]+)#', $msg_explode[1], $_ytm)) {
			$youtube = $_ytm[1];
		} else {
			$youtube = trim(str_replace('https://youtu.be/','',$msg_explode[1]));
		}
		// Begleittext: alles außer der URL selbst
		$_yt_url_pattern = '#https://youtu\.be/[^\s"<>]+#';
		$youtube_text = trim(preg_replace($_yt_url_pattern, '', html_entity_decode($msg_explode[1])));
		if ($youtube_text !== '') { $youtube_text = ' '.$youtube_text; }
	}

	// YouTube6:
	elseif (strpos($msg_explode[1],'https://www.youtube.com/') !== false && strpos($msg_explode[1],'v=') !== false) {
		$msg_explode[1] = htmlentities($msg_explode[1]);
		if (preg_match('#[?&]v=([^&\s"<>]+)#', $msg_explode[1], $_ytm)) {
			$youtube = $_ytm[1];
			// Begleittext: URL wegschneiden
			$youtube_text = trim(preg_replace('#https://www\.youtube\.com/[^\s"<>]+#', '', html_entity_decode($msg_explode[1])));
			if ($youtube_text !== '') { $youtube_text = ' '.$youtube_text; }
		} else {
			$youtube = $msg_explode[1];
		}
	}

	// YouTube7:
	elseif (strpos($msg_explode[1],'https://m.youtube.com/') !== false && strpos($msg_explode[1],'v=') !== false) {
		$msg_explode[1] = htmlentities($msg_explode[1]);
		if (preg_match('#[?&]v=([^&\s"<>]+)#', $msg_explode[1], $_ytm)) {
			$youtube = $_ytm[1];
			$youtube_text = trim(preg_replace('#https://m\.youtube\.com/[^\s"<>]+#', '', html_entity_decode($msg_explode[1])));
			if ($youtube_text !== '') { $youtube_text = ' '.$youtube_text; }
		} else {
			$youtube = $msg_explode[1];
		}
	}


	if (strpos($msg_explode[1],'youtube') !== false || strpos($msg_explode[1],'https://youtu.be/') !== false) {
		$msg_explode[1] = htmlentities($msg_explode[1]);

		if (strpos($youtube,'v=') !== false) {
			$ytstart = strpos($youtube,'v=') +2;
		} else {
			$ytstart = 0;
		}
		$youtube = trim(substr($youtube,$ytstart));		


		if (strpos($youtube,'&') !== false) {
			$ytende = strpos($youtube,'&');
			$youtube = substr($youtube,0,$ytende);
		} 


	}


	// Begleittext nach dem YouTube-Link erhalten:
	// Frühere Versionen blockierten Postings mit zusätzlichem Text per yt_error.
	// Stattdessen wird der Text jetzt abgetrennt, $youtube auf die ID/Param-Sequenz
	// gekürzt und der Begleittext nach dem Embed wieder ausgegeben.
	// Hinweis: $youtube_text kann für YouTube2/6/7 bereits oben gesetzt worden sein.
	if (!isset($youtube_text)) { $youtube_text = ''; }
	if ($youtube != '' && preg_match('/\s/', $youtube)) {
		$ytparts = preg_split('/\s+/', $youtube, 2);
		$youtube = $ytparts[0];
		if ($youtube_text === '' && isset($ytparts[1])) {
			$youtube_text = ' '.trim($ytparts[1]);
		}
	}


	$youtube = htmlentities($youtube);
	

	// Wenn Link mit Startzeit übergeben wird :
	if (strpos($youtube,'?') !== false) {
		$msg_explode[1] = htmlentities($msg_explode[1]);
		$ytende = strpos($youtube,'?');
		$youtube_pv = substr($youtube,0,$ytende);
	} elseif (strpos($youtube,'&t=') !== false) {
		$msg_explode[1] = htmlentities($msg_explode[1]);
		$ytende = strpos($youtube,'&t=');
		$youtube_pv = substr($youtube,0,$ytende);
	} else {
		$youtube_pv = $youtube;
	}

	$youtube_embed = $youtube;
	$youtube_watch = $youtube;
	if (strpos($youtube,'?t=') !== false) {
		$youtube_watch = str_replace('?t=','&amp;t=',$youtube);

		$parts = explode ('?t=',$youtube);

		if (strpos($youtube,'m') !== false) {
			$timeparts = explode ('m',$parts[1]);

			$sec = $timeparts[1];
			$secdec = substr($sec,0,-1);

			$min_to_sec = $timeparts[0] * 60 + $secdec;

			$youtube_embed = $parts[0].'?start='.$min_to_sec;

		} else {
			$youtube_embed = str_replace('?t=','?start=',$youtube);
			$youtube_embed = substr($youtube_embed, 0, -1);			
		}	

	}


	if ($youtube != '') {
		$msg_explode[1] = htmlentities($msg_explode[1]);
		if ($links!="yes" && strpos($room,"_pr") === false && $admintrue !== true ) {
			$msg_explode[1] = ' YouTube Links nicht erlaubt';
		} else {
			// Smiley-Codes im Begleittext verarbeiten, bevor er ins HTML eingebettet wird:
			if ($youtube_text !== '' && file_exists("smil_replace3.php")) {
				$_yt_msg_backup = $msg_explode[1];
				$msg_explode[1] = $youtube_text;
				include("smil_replace3.php");
				$youtube_text = $msg_explode[1];
				$msg_explode[1] = $_yt_msg_backup;
				unset($_yt_msg_backup);
			}
			$msg_explode[1] = $pn_prefix.'<a style ="text-decoration:none; color:red;" href="https://www.youtube-nocookie.com/embed/'.$youtube_embed.'" onclick="YTPop(this.href); return false"> <img class="ytpreview" src="https://i1.ytimg.com/vi/'.$youtube_pv.'/mqdefault.jpg" alt="YouTube Video extern" title="YouTube Video im Popup oeffnen" /></a><a id="yt_dt" style ="text-decoration:none;" href="https://www.youtube-nocookie.com/embed/'.$youtube_embed.'" target="_blank" title="YouTube Video öffnet in neuem Tab/Fenster">&nbsp;<span class="yta">You</span><span class="ytb">Tube</span></a><a id="yt_mob" style ="text-decoration:none;white-space:nowrap;"  onclick="loadytiframe(\'https://www.youtube-nocookie.com/embed/'.$youtube_embed.'?autoplay=1 \')" > <img class="ytpreview_mob" src="https://i1.ytimg.com/vi/'.$youtube_pv.'/mqdefault.jpg" alt="YouTube Video extern" />&nbsp;<span class="yta">You</span><span class="ytb">Tube</span></a>'.$youtube_text;
		}
	}


	elseif (strpos($msg_explode[1],':afk1:') !== false) {
		$msg_explode[1] = '<img src="smileys1/'.$afk_smiley1.' " onclick="ads(\':afk1:\'); return false;" oncontextmenu="max(this);return false;" style="cursor:pointer" alt="Grafik" />';
	}
	elseif (strpos($msg_explode[1],':afk2:') !== false) {
		$msg_explode[1] = '<img src="smileys1/'.$afk_smiley2.' " onclick="ads(\':afk2:\'); return false;" oncontextmenu="max(this);return false;" style="cursor:pointer" alt="Grafik" />';
	}

	// mp3s (eleganter waer das im linker):
	elseif (strpos($msg_explode[1],'.mp3') !== false && strpos($msg_explode[1],'http') !== false) {

		// if (file_exists("smil_replace3.php")) include("smil_replace3.php");

		$msg_explode[1] = str_replace(".mp3",".mp3 ",$msg_explode[1]);

		if (strpos($msg_explode[1],'http://') !== false) {
			$start = strpos($msg_explode[1],"http://");
		} elseif (strpos($msg_explode[1],'https://') !== false) {
			$start = strpos($msg_explode[1],"https://");
		} 
		$teil = substr($msg_explode[1],$start);
		$laenge = strpos($teil,"mp3 ")+3;
		$multimedia = trim(substr($teil,0,$laenge));

		$multimedia_title = str_replace('http',' http',$multimedia);

		$multimedia_title = str_replace('.mp3','',$multimedia);
		$multimedia_title = str_replace('_',' ',$multimedia_title);
		$multimedia_title = str_replace('.','',$multimedia_title);
		$multimedia_title = str_replace(';stream','Radiostream',$multimedia_title);

		$rest = str_replace($multimedia,"",$msg_explode[1]);
    
		// abs. Pfad in  relativen Pfadeumwandeln, wg. allow_url_fopen
		// $abs_path = "http://".$_SERVER['SERVER_NAME'].dirname($_SERVER['PHP_SELF'])."/";
		$multimedia = str_replace($abs_path,"",$multimedia);
	
	
		if ( isset($show_player) && $show_player === true) {
			// so wird das Linkziel im Browser nicht angezeigt:
			if (strpos($room,'_pr') !== false) { // in _pr keine mp3-Logs schreiben
				$msg_explode[1] = ' <dfn>Play: </dfn><a class="mp3" href="" onclick="playmp3olog_mit_http(\''.$multimedia.'\');return false;" oncontextmenu="return false;" >'.basename($multimedia_title).'</a> ';
			} else {
				$msg_explode[1] = ' <dfn>Play: </dfn><a class="mp3" href="" onclick="playmp3_mit_http(\''.$multimedia.'\');return false;" oncontextmenu="return false;" >'.basename($multimedia_title).'</a> ';
		
			}					
		}
		// <a class="stop" href=" " onclick="playmp3leer();return false;">Close&nbsp;Player</a>


	} else {
		// automatisch Links erzeugen:
		if (file_exists("smil_replace3.php")) include("smil_replace3.php");
		$msg_explode[1] = linker($msg_explode[1]);
	}


	/* ein bisschen bbcode */
	if(strpos($msg_explode[1],"[b]") !== false && strpos($msg_explode[1],"[/b]") !== false){  
		$msg_explode[1] = str_replace('[b]','<b>',$msg_explode[1]);
		$msg_explode[1] = str_replace('[/b]','</b>',$msg_explode[1]);
	}


	// if(strpos($msg_explode[1],"[scroll]") !== false && strpos($msg_explode[1],"[/scroll]") !== false){
	// 	$msg_explode[1] = str_replace('[scroll]','<span class="marquee" ><span style="animation-duration: 10s;">',$msg_explode[1]);
	// 	$msg_explode[1] = str_replace('[/scroll]','</span></span>',$msg_explode[1]);
	// }


	if(strpos($msg_explode[1],"[i]") !== false && strpos($msg_explode[1],"[/i]") !== false){  
		$msg_explode[1] = str_replace('[i]','<i>',$msg_explode[1]);
		$msg_explode[1] = str_replace('[/i]','</i>',$msg_explode[1]);
	}

	if(strpos($msg_explode[1],"[blink]") !== false && strpos($msg_explode[1],"[/blink]") !== false){  
		$msg_explode[1] = str_replace('[blink]','<span class="blink">',$msg_explode[1]);
		$msg_explode[1] = str_replace('[/blink]','</span>',$msg_explode[1]);
	}

	// if(strpos($msg_explode[1],"[color=") !== false && strpos($msg_explode[1],"[/color]") !== false){
	// 	$msg_explode[1] = str_replace('[color=','<span style="color:',$msg_explode[1]);
	// 	$msg_explode[1] = str_replace('[/color]','</span>',$msg_explode[1]);
	// 	$msg_explode[1] = str_replace(']','">',$msg_explode[1]);
	// }


	// Videos einbinden	


	if(stristr($msg_explode[1], '.mp4') !== false || stristr($msg_explode[1], '.m4v') !== false || stristr($msg_explode[1], '.MOV') !== false) {

		if (file_exists("smil_replace3.php")) include("smil_replace3.php");

		$msg_explode[1] = str_replace(".mp4",".mp4 ",$msg_explode[1]);
		$msg_explode[1] = str_replace("http"," http",$msg_explode[1]);

		if(strpos($msg_explode[1], 'upload/') !== false) {
			$pos2 = strrpos($msg_explode[1],'upload/');
			$temp2 = substr($msg_explode[1],$pos2);
			// Begleittext extrahieren: alles, was nach dem schließenden </a>-Tag steht.
			// Der Anker hat die Form  upload/foo.mp4" rel="...">https://...mp4</a> Begleittext
			$mp4_text = '';
			$pos_close_a = stripos($temp2, '</a>');
			if ($pos_close_a !== false) {
				$mp4_text = trim(substr($temp2, $pos_close_a + 4));
				if ($mp4_text !== '') { $mp4_text = ' '.$mp4_text; }
			}
			$temp3 = str_replace('</a> ','',$temp2);
			$teile1 = explode('" rel=', $temp3);
			$temp4 = $teile1[0];
			$msg_explode[1] = ' <video src="'.$temp4.'" type="video/mp4" playsinline  controls="true" ></video>'.$mp4_text;


		} elseif (strpos($msg_explode[1], 'smileys') !== false ){
			$pos2 = strrpos($msg_explode[1],'smileys');
			$temp2 = substr($msg_explode[1],$pos2);
			$temp3 = str_replace('</a> ','',$temp2);
			
			if (strpos($temp3, '\/add') === false && strpos($temp3, '\/del_smiley') === false ){
				$teile1 = explode(' ', $temp3);
				$temp4 = $teile1[0];
				// Begleittext nach dem Smiley-Dateinamen (ab dem ersten Leerzeichen
				// im $temp3) zusammen mit dem, was vor 'smileys' stand:
				$mp4_text_pre = rtrim(substr($msg_explode[1], 0, $pos2));
				$mp4_text_post = isset($teile1[1]) ? trim(implode(' ', array_slice($teile1, 1))) : '';
				$mp4_text = trim($mp4_text_pre.' '.$mp4_text_post);
				if ($mp4_text !== '') { $mp4_text = ' '.$mp4_text; }
			} else {
				$temp4 = $temp3;
				$mp4_text = '';
			}
			$msg_explode[1] = ' <video src="'.$temp4.'" type="video/mp4" autoplay loop muted playsinline onmouseover="this.setAttribute(\'controls\', true)"   onfocus="this.setAttribute(\'controls\', true)" ></video>'.$mp4_text;

		// $msg_explode[1] = ' <video src="'.$temp4.'" type="video/mp4" autoplay loop muted playsinline onmouseover="this.setAttribute(\'controls\', true)"   onfocus="this.setAttribute(\'controls\', true)" ></video>';

			
		} elseif ( preg_match("(http[^ ]+)", $msg_explode[1], $match) ) { // einen URL extrahieren
			// Begleittext = alles außer der URL. str_replace entfernt sie nur
			// einmal (beim ersten Vorkommen).
			$mp4_text = trim(str_replace($match[0], '', $msg_explode[1]));
			if ($mp4_text !== '') { $mp4_text = ' '.$mp4_text; }
			$msg_explode[1] = ' <video src="'.$match[0].'" type="video/mp4"  playsinline  controls="true"></video>'.$mp4_text;
		}
		
	}

	if(stristr($msg_explode[1], '.webm') !== false) {

		if (file_exists("smil_replace3.php")) include("smil_replace3.php");

		$msg_explode[1] = str_replace(".webm",".webm ",$msg_explode[1]);
		$msg_explode[1] = str_replace("http"," http",$msg_explode[1]);

		if(strpos($msg_explode[1], 'upload/') !== false) { 
			$pos2 = strrpos($msg_explode[1],'upload/');
			$temp2 = substr($msg_explode[1],$pos2);
			// Begleittext: alles nach dem schließenden </a>-Tag
			$webm_text = '';
			$pos_close_a = stripos($temp2, '</a>');
			if ($pos_close_a !== false) {
				$webm_text = trim(substr($temp2, $pos_close_a + 4));
				if ($webm_text !== '') { $webm_text = ' '.$webm_text; }
			}
			$temp3 = str_replace('</a> ','',$temp2);
			$teile1 = explode('" rel=', $temp3);
			$temp4 = $teile1[0];
	
			// $msg_explode[1] = ' <video src="'.$temp4.'" type="video/webm" autoplay loop muted playsinline onmouseover="this.setAttribute(\'controls\', true)"   onfocus="this.setAttribute(\'controls\', true)" ></video>';
			$msg_explode[1] = ' <video src="'.$temp4.'" type="video/webm" playsinline controls="true" ></video>'.$webm_text;
			
		} elseif ( preg_match("(http[^ ]+)", $msg_explode[1], $match) ) { // einen URL extrahieren
			$webm_text = trim(str_replace($match[0], '', $msg_explode[1]));
			if ($webm_text !== '') { $webm_text = ' '.$webm_text; }
			// $msg_explode[1] = ' <video src="'.$match[0].'" type="video/webm" autoplay loop muted playsinline onmouseover="this.setAttribute(\'controls\', true)"  onfocus="this.setAttribute(\'controls\', true)"></video>';
			$msg_explode[1] = ' <video src="'.$match[0].'" type="video/webm"  playsinline  controls="true"></video>'.$webm_text;

		}
	}


	if(strpos($msg_explode[1],"<video") !== false && (strpos($msg_explode[1],"gif") !== false || strpos($msg_explode[1],"png") !== false) ){
		$msg_explode[1] = _MP4ERROR;
	}


	// Whisper-Vorspann ggf. wieder voranstellen.
	// Wird hier hinter den letzten Multimedia-Block gesetzt, weil mehrere
	// Branches (YouTube, MP3, :afk:, MP4, WebM, _MP4ERROR) $msg_explode[1]
	// komplett überschreiben und den im /pn-Block gesetzten Whisper-Vorspann
	// dabei verlieren würden. Der Check verhindert Doppelungen, falls der
	// Vorspann bereits im Output steht (YouTube hängt ihn explizit dran,
	// linker-Pfad lässt ihn intakt – allerdings haben wir ihn vor dem Block
	// rausgezogen, deshalb ist er beim linker-Pfad ebenfalls hier zu setzen).
	if ($pn_prefix !== '' && strpos($msg_explode[1], '<span style="font-style:italic;">(') === false) {
		$msg_explode[1] = $pn_prefix.' '.$msg_explode[1];
	}


	// nur ein Joke: (schoener: http://rw47.eu/umdreher/)

	if(strpos($msg_explode[1],"/rev ") !== false){
		$msg_explode[1] = " ".implode('', array_reverse(mb_str_split(str_replace("/rev ","",$msg_explode[1]))));
	}

	if (file_exists("smiley_create.php")) include("smiley_create.php");

	// so liesse sich ein Anonymizer aufrufen:
	// darf nicht fuer Bilder aktiv sein, weil sonst thumbs nicht tut.
	if(isset($anonymizer) ) {

		$meinString = $msg_explode[1];
		$findMich   = '.jpg';
		$findMich2   = '.gif';
		$findMich3   = '.png';

		$pos = strpos($meinString, $findMich);
		$pos2 = strpos($meinString, $findMich2);
		$pos3 = strpos($meinString, $findMich3);

		if ($pos === false && $pos2 === false && $pos3 === false) {
			$msg_explode[1] = str_replace('http://','http://'.$anonymizer.'http://',$msg_explode[1]);
			$msg_explode[1] = str_replace('>http://'.$anonymizer.'','>',$msg_explode[1]);
		}
	}


	// und jetzt noch die Zeile des Admin farbig hinterlegen:
	$highlight="";
	// if(($admintrue !== false || $modtrue !== false) && $superadmintrue !== true) {
	if($admintrue !== false && $superadmintrue !== true) {
		$highlight = " class = \"bg\" ";
		// wenn du die Farbe fuer den Admin unabhaengig von cookies festschreiben willst
		// dann folgende Zeile entkommentieren und Hexcode waehlen:
		// $color ="FF0000";
	}

	// und jetzt noch die Zeile des Mod:
	if($modtrue !== false) {
		$highlight = " class = \"bm\" ";
	}
	
	// erst wenn Farbe gewaehlt und cookie gesetzt, msg einfaerben
	$msg_explode[1] = "<span style=\"color:#$color\">$msg_explode[1]</span>";


	if ($admintrue === false && $modtrue === false ) {
		if (strpos(strtolower($msg_explode[1]),"/erase ") !== false) {
			$msg_explode[1] = ' <span style="display:none">/pn @'.$nickname.' </span>'._ERASE;
		}
	}
		
		
	if ($admintrue === false ) {
		if (strpos(strtolower($msg_explode[1]),"/approve ") !== false) {
			$msg_explode[1] = ' <span style="display:none">/pn @'.$nickname.' </span>'._SORRY._APPROVE;
		}
	}


	if (isset($shoutbox) && $shoutbox !== false) {      // von der shoutbox geschickte msg kennzeichnen:
		$msg_explode[1] = $msg_explode[1].'<span style = "font-size:75%">(sb)</span></span>';
	}


	// Moderation on: 
	if ($mod == "all" || in_array($wo, $mod_rooms) !== false) {

		if ($admintrue === false ) {
			$msg_explode[1] = str_replace ('/me','',$msg_explode[1]);
			$msg_explode[1] = $msg_explode[1].' <span onclick="ads(\'/approve '.$uhr0.'\'); return false;"  style="color:red !important; cursor:pointer">(await mod)</span>';
		}
	}


	if (isset($ip_write) && $ip_write === true && $admintrue !== true) {
		if (file_exists('ip_inc.php')) {
			include ('ip_inc.php');
		} else {
			$msg_explode[1] .= ' <span class="ip">'.$own_ip.'</span>';
		}
	}


	// @nickname nur, wenn nickname schon bekannt:
	// Anm.: Leerschritt vor pointer wg. ARIA i.V.m. (await mod)
	if ($nickname != "") {

		$nickname2 = "<span class=\"nk\" oncontextmenu=\"ads('/erase ".$uhr0."'); return false;\"   onclick=\"ads('\u0040".$nickname."'); return false; \"  title =\"$dt0 $uhr0\" style=\"color:#$color; cursor: pointer\">".implode(":</span>",$msg_explode);


		/* Avatar einbinden */
		if (!isset($av_height)) {$av_height = 32;}
		
		if(file_exists('profile/'.$nickname.'.gif')) {
			$msg = ' <span class="av_link"><a href="popprof.php?profil='.$nickname.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$nickname.' anschauen (Popup)"  > <img class="av" src="profile/'.$nickname.'.gif" onError="this.onerror=null;this.src=\'img/no_prof_img.png\';" alt="Profilbild" height="'.$av_height.'"></a></span> '.$nickname2;
			
		} elseif(file_exists('profile/'.$nickname.'.jpg')) {
			$msg = ' <span class="av_link"><a href="popprof.php?profil='.$nickname.'" onclick="ProfilOeffnen(this.href); return false;" title="Profil von '.$nickname.' anschauen (Popup)"  > <img class="av" src="profile/'.$nickname.'.jpg" onError="this.onerror=null;this.src=\'img/no_prof_img.png\';" alt="Profilbild" height="'.$av_height.'"></a></span> '.$nickname2;
			
		} else {
			$msg = $nickname2;
		}		   

	} else {
		$msg = "<span class=\"nk\" oncontextmenu=\"ads('/erase ".$uhr0."'); return false;\"   title =\"$dt0 $uhr0\" style=\"color:#$color; cursor: pointer\">".implode(":</span>",$msg_explode);
	}


	// folgende Zeile anstelle der oberen legt Fluestern statt Loeschen auf die rechte Maustaste:
	// zusaetzlich noch die if-Abfrage nach $nickname einbauen
	//        $msg = "<span class=\"nk\" oncontextmenu=\"ads('\u002fpn \u0040".$nickname."'); return false;\"   onclick=\"ads('\u0040".$nickname."'); return false; \"  title =\"$dt0 $uhr0\" style=\"color:#$color; cursor: pointer\">".implode(":</span>",$msg_explode);


	if (file_exists("badwords.txt") && $admintrue !== true) {
		$badwords = file("badwords.txt");
		foreach ($badwords as $b) {
			if (strpos($msg,"http://") !== false && strpos($msg,trim($b)) !== false) {
				$msg = str_ireplace(rtrim($b), "".substr($b,0,0)."example.com", $msg);
				$msg = $msg.'<span  style="display:none">/pn @'.$nickname.' </span>';
			}
			$b = " ".$b;
			$msg = str_ireplace(rtrim($b), " ".substr($b,1,1)."***", $msg);
		}
	}


	// Eine einfache flooding Sperre:
	
	
	if ($flood > 0 && $admintrue === false) {         // $flood = 0; in der config schaltet die Sperre aus.

		$fl = "user/flood.txt";
		$vgl = file_get_contents($fl);
		$teil = explode("+++", $vgl);
		$pruef = $msg_explode[0].'+++'.trim($msg_explode[1]).'+++'.time();

		// // away nur alle 120 Sek. schreiben
		// if(($teil[0] == $msg_explode[0] && (time()-$teil[2]) < 120)
		// 	&& strpos($teil[1],'ist jetzt mal <abbr title =" away from keyboard"') !== false
		// && strpos($msg,'ist jetzt mal') !== false) {
		// 	exit();
		// }

		if(($teil[0] == $msg_explode[0] && (time()-$teil[2]) < ($flood / 4))
			|| ($teil[0] == $msg_explode[0] && $teil[1] == trim($msg_explode[1]) && (time()-$teil[2]) < $flood)
		) {

			$ff = fopen($fl, "w+");
			fwrite($ff, $pruef);
			fclose($ff);

			$nickban = $nickname;

			// if (!isset($bantime)) {$bantime=3;}
			// $bantime = time() + 60*$bantime;
			// nur noch 10 sec für flooding
			$bantime = time() + 15;

			// $roomid = str_replace("rooms/","_",$room);
			$ipfile = 'user/ip_'.$wo.'.txt';

			$lines = file($ipfile);
			$ipparts = "";
			foreach ($lines as $line_num => $line) {
				if (strpos($line,$nickban) !== false) {
					$ipparts = explode("****", $line);
					$banip = $ipparts[0];
				}
			}

			$banstrg = $nickban."****".$bantime."++++".$banip."\n";

			$banned = "user/maulkorb.txt";
			$fb = fopen($banned, "a+");
			fwrite($fb, $banstrg);
			fclose($fb);

			$msg = '<span style="display:none">/pn @'.$nickname.' vom Chatbot: </span>'._HELLO.$nickname._FLOOD.'</span>';
		}

		$ff = fopen($fl, "w+");
		fwrite($ff, $pruef);
		fclose($ff);
	}


	// Hinweis: Die yt_error-Restriktion wurde entfernt – YouTube-Links dürfen
	// jetzt zusätzlichen Begleittext enthalten. Diese Zeile fängt nur noch
	// eventuelle Altbestand-Postings im History-Cache ab und bleibt deshalb aktiv.
	if (strpos($msg,"yt_error") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._YTERROR.'</span>';

	if (strpos($msg," /nick") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._NICKIRC.'</span>';
	if (strpos($msg," /name") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._NICKIRC.'</span>';
	if (strpos($msg," /who") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._WHOIRC.'</span>';
	if (strpos($msg," /msg") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._MSGIRC.'</span>';
	if (strpos($msg," [scroll]") !== false) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._NOSCROLL.'</span>';

	if ((strpos($msg," /help") !== false) && ($admintrue !== false)) $msg = _HELPIRC.'</span>';
	if ((strpos($msg," /help") !== false) && ($admintrue === false)) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._HELPIRC.'</span>';

	if ((strpos($msg," /hilfe") !== false) && ($admintrue !== false)) $msg = _HELPIRC.'</span>';
	if ((strpos($msg," /hilfe") !== false) && ($admintrue === false)) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._HELPIRC.'</span>';


	// if ((strpos($msg," /xprofil") !== false) ) $msg = '<span style="display:none">/pn</span> @'.$nickname.' '._XPROFIL.'</span>';


	if (strpos($msg," /list") !== false) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._LISTIRC.'</span>';
	if (strpos(strtolower($msg),"[img]") !== false) $msg = '<span style="display:none">/pn @'.$nickname.' </span>'._FORMIMG.'</span>';


	if(strpos($msg,"/me ") !== false  && strpos($msg,"/pn") === false) {
		$msg = str_replace(":</span","</span",$msg);
		$msg = str_replace("/me","",$msg);
	} elseif (strpos($msg,"/me ") !== false) {
		$msg = str_replace("/me","",$msg);
	} 


	if(strpos($msg,"/clear") !== false) {
		$msg = str_replace(":</span","</span",$msg);
		$msg = str_replace("/clear",_CLEAR,$msg);
	}


	// msg anpinnen fuer Admin und Mod:
	if (strpos($msg,"/pin ") !== false && ($admintrue !== false || $modtrue !== false)) {
		$highlight = " class = \"pin\" ";
		
//		$msg = str_replace("<p>","<p class='pin'>",$msg);
		$msg = str_replace("/pin",'',$msg);
	}


	$msg = str_replace("\n","<br>",$msg);
	
	
	// Chat zeitabhaengig offline: (auch #2670)
	if ( isset($ab_offen) && isset($bis_offen) && $wo != "Intern"  && $superadmintrue !== true) {
		$uhrzeit = date("H:i");

		if ($ab_offen < $bis_offen) {
			if ($uhrzeit < $ab_offen || $uhrzeit >= $bis_offen) {
				$msg = _CLOSED." $ab_offen - $bis_offen Uhr";
				exit;
			}
		} else {
			if ($uhrzeit < $ab_offen && $uhrzeit >= $bis_offen) {
				$msg = _CLOSED." $ab_offen - $bis_offen Uhr";
				exit;
			}
		}
	}
	
	
	if(isset($user_whisperroom) && $user_whisperroom == "admin") {
		// nur Admin darf oeffentliche und private Raeume anlegen:
		// if ($roomexists == "1" || $admintrue !== false) {

			$f = fopen($room, "a+");
			flock($f,LOCK_EX);
			fwrite($f, "<p$highlight>$dt $uhr<span class=\"tr\"> | </span>$msg</p>\n");
			fflush($f);
			flock($f,LOCK_UN);
			fclose($f);
		// }
	} else {
		// nur Admin darf oeffentliche Raeume anlegen:
		if ($roomexists == "1" || strpos($room,"_pr") !== false || $admintrue !== false) {

			$f = fopen($room, "a+");
			flock($f,LOCK_EX);
			fwrite($f, "<p$highlight>$dt $uhr<span class=\"tr\"> | </span>$msg</p>\n");
			fflush($f);
			flock($f,LOCK_UN);
			fclose($f);
		}
	}
		
}


function refresh() {
	global  $room,
	$roomexists,
	$anz_msg,
	$nickname,
	$admintrue,
	$superadmintrue,
	$modtrue,
	$watch,
	$pnlivetime,
	$enter_livetime,
	$shoutbox,
	$new_lines,
	$guestread,
	$mod,
	$mod_rooms,
	$listen,
	$blankroom,
	$blankrooms,
	$sav_msg,
	$ignore,
	$closepr,
	$bis_offen,
	$ab_offen,
	//		$ip_write,
	$showip,
	$time_offset,
	$style,
	$own_ip,
	$wo,
	$interne,
	// $kicked,
	$detect,
	$display_reverse,
	$s;

	
	$ignore0 = $ignore1 = $ignore2 = "&nbsp;";

	$wo = trim(substr($room,6));
	// $arrival = "";

	// arrival cookie beim ersten Betreten eines Raums setzen:
	// $woarrival = $wo.'arrival';
	// if (isset($_COOKIE[$woarrival])) $arrival = $_COOKIE[$woarrival];
	if (isset($_COOKIE['arrival'])) $arrival = $_COOKIE['arrival'];


	if (file_exists($room)) {
		$size = filesize($room);
		$maxsize = $sav_msg * 400; // hier etwas Sicherheitsabstand, damit das nicht zu frueh greift
		if ($size > $maxsize)    include("cleanup.php");
	}

	
	if (file_exists("user/ban.txt")) {
		$zeilen = file("user/ban.txt", FILE_IGNORE_NEW_LINES);
		// $zeilen = file("user/ban.txt");
		
		// ban.txt ggf. um ip ergänzen:
		foreach ($zeilen as $index => $zeile) {
			if (strpos($zeile,'#*#*') === false && strpos($zeile,$nickname) !== false ) {
				$zeilen[$index] = $zeile."#*#*".$own_ip;
				// break; // wenn nur die erste passende Zeile ersetzt werden soll
				file_put_contents("user/ban.txt", implode(PHP_EOL, $zeilen));
			}
		}
		
				
		foreach ($zeilen as $c) {
			$part1 = explode("****",$c);
			$part2 = explode("++++",$part1[1]);

			// Rest Banzeit:
			$nochraw = ($part2[0] - time()) / 60 + 1; 
			$nochstunden = floor($nochraw /60);
			$nochminuten = floor(($nochraw - $nochstunden*60)) ;
			if ($nochminuten <= 9) { $nochminuten = '0'.$nochminuten;}
			$noch = ' '.$nochstunden.':'.$nochminuten.'&nbsp;h';

			if (strlen($c) > 1 && $part2[0] > time()) {
				$rip = $own_ip;

				if ($part1[0] == $nickname
					|| (trim($rip) == trim($part2[1]) && !isset($nickname))
				)  { 
					$new_lines = "<p>"._SORRY." ".$nickname._MUZZLED.$noch;
					return $new_lines;
					exit;
				}					
			}
		}
	}

	// Chat offline:
	if ($admintrue !== true && $room != "rooms/Intern") {
		if ((file_exists("rooms/Offline")
			// && $room != "rooms/Info"
				// && $room != "rooms/Intern"
					//        && $admintrue === false
		)
			&& (strpos($room,"_pr") === false
				|| (strpos($room,"_pr") !== false && $closepr != "no"))
					)
		{
			if (filesize("rooms/Offline") > 0) {
				$offline_content = file("rooms/Offline");
				$resultat = array_values($offline_content);
				foreach ($resultat as $element) {
					if (strpos($element,"deleted") === false) {
						$new_lines .= $element;
					}
				}

			} else {
				$new_lines = "<p><br>"._OFFLINE;
			}
			return $new_lines;
			exit();
		}
	}

	if ($wo == "Intern") {
		if (!in_array($nickname,$interne) && $admintrue === false) {
			$new_lines = "<p>"._INTERN;
			return $new_lines;
			exit();
		}
	}
	if ($wo == "Modis" || $wo == "Mods") {
		if ($modtrue === false && $admintrue === false) {
			$new_lines = "<p>"._INTERN;
			return $new_lines;
			exit();
		}
	}


	// Chat zeitabhaengig offline: (auch #2505)	
	if ( isset($ab_offen) && isset($bis_offen) && $wo != "Intern" && $superadmintrue !== true) {
		
		
		$uhrzeit = date("H:i");

		if ($ab_offen < $bis_offen) {
			if ($uhrzeit < $ab_offen || $uhrzeit >= $bis_offen) {
				echo "<p> "._CLOSED." $ab_offen - $bis_offen Uhr</p>";

				exit();
			}
		} else {
			if ($uhrzeit < $ab_offen && $uhrzeit >= $bis_offen) {
				echo "<p> "._CLOSED." $ab_offen - $bis_offen Uhr</p>";

				exit();
			}
		}
	}


	// if($roomexists === false) exit();


	// die letzten ... Eintraege:
	if (file_exists($room)) {

		$lines = file($room);
		$lines = array_slice($lines, -$anz_msg);

		if ((isset($display_reverse) && $display_reverse === true) || $style=="12") {$lines = array_reverse($lines);}
		$anz = count($lines);


		// /await mod nicht zeigen:
		if ($mod == "all" || in_array($wo, $mod_rooms) !== false) {

			$sender = "nickname";
			$sender_neu = "nickname";

			if (isset($nickname)) $sender_neu = $nickname.'":';
			if (isset($nickname)) $sender = $nickname.':';

			for($i = 0; $i < $anz; $i++){
				if (strpos(strtolower($lines[$i]),"(await mod)") !== false) {
					if ($admintrue !== false
						|| strpos($lines[$i],$sender) !== false  // Sender sieht eigene msg
							|| strpos($lines[$i],$sender_neu) !== false  // neuer Sender sieht eigene msg
					) {
						$new_lines2[$i] = $lines[$i]."\n";
					}
				} else {
					$new_lines2[$i] = $lines[$i]."\n";
				}
			}
		}
		if (isset($new_lines2)) {
			$lines = $new_lines2;
		}


		$privat = $nickname;

		$privat1 = "@".$privat." ";	// damit's der Empfaenger sieht
		$privat2 = ">".$privat.":"; 	// damit's der Sender sieht
		$privat3 = $privat.'":'; 	// damit's neu reingekommener Sender sieht

		$lines = @array_slice($lines, -$anz_msg);
		$anz2 = count($lines);

		for($i = 0; $i < $anz2; $i++){


			// Zeitstempel der msg ermitteln fuer $blankroom und fluestern:
			$lines1[$i] = str_replace(' class = "bg" ','',$lines[$i]);
			$lines1[$i] = str_replace(' class = "bm" ','',$lines1[$i]);
			$year = date("Y");
			$month = substr($lines1[$i],23,2);
			$day = substr($lines1[$i],20,2);
			$hour = substr($lines1[$i],51,8);

			// damit beim Jahreswechsel blankroom auch funktioniert:
			$yearblank = $year;
			if ($month > date("n") || $day > date("d") ) {
				$yearblank = $year - 1;
			}

			$pntime = $year.'-'.$month.'-'.$day.' '.$hour;
			$pntimeblank = $yearblank.'-'.$month.'-'.$day.' '.$hour;


			$msgtime = strtotime($pntime)-($time_offset*3600);
			$msgtimeblank = strtotime($pntimeblank)-($time_offset*3600);


			if (strpos($lines[$i],'class="ip"') !== false && $admintrue === false || $showip !== true) {
				$ip_pos = strpos($lines[$i],'class="ip">') -9;
				$lines[$i] = substr($lines[$i],0,$ip_pos).'</p>';
			}


			// Kein Popup fuer YouTube wenn mobile:
			// if(file_exists("check_mobile.php")) {
			// 	require_once('check_mobile.php');
			// 	if(check_mobile()) {
				if( ($detect->isMobile() && !$detect->isTablet()) || $s == 7 ){								
					if (strpos($lines[$i],'watch_popup') !== false) {
						$lines[$i] = str_replace('watch_popup','watch',$lines[$i]);
					}
				}
			// }

			// Hello usw. zeitgesteuert ausblenden:
			if(strpos($lines[$i],'class="hello"') !== false) {
				// $jetzt = strtotime("now");
				$jetzt = time();
			
				// if ($admintrue === true || $modtrue === true) {
					if (!isset($enter_livetime)) {$enter_livetime = 60 * 5;}
				// } else {
				// 	$enter_livetime = 60 * 60 * 2; // so wird hello angezeigt.
				// }
			
				if (($jetzt - $msgtime) < $enter_livetime && $jetzt - $msgtime >= 0 && strpos($lines[$i],"deleted") === false) // zweites gegen den Jahreswechselbug		
				{
					$new_lines[$i] = $lines[$i]."\n";
				}
			}

			elseif(strpos(strtolower($lines[$i]),"/pn") !== false
				|| (strpos($lines[$i],'cursor:pointer">(await mod') !== false && $admintrue!==true) /* Admin sieht await immer */
					|| strpos($lines[$i],"Achtung! diese Einladung") !== false
						|| strpos($lines[$i],"Warning! This invitation") !== false
							|| strpos($lines[$i],_DBLUSER) !== false
			) {


				$jetzt = strtotime("now");

				// Admin sieht auch pn:
				if ((strpos($lines[$i],$privat1) !== false
					|| strpos($lines[$i],$privat2) !== false
						|| strpos($lines[$i],$privat3) !== false
							|| ($listen === true && $admintrue===true && $watch !== true)
								|| ($listen === true && $superadmintrue===true)
								)
								&& $jetzt - $msgtime < $pnlivetime && $jetzt - $msgtime >= 0 // letzteres gegen den Jahreswechselbug
				) {
					// damit auch der Admin Gefluester ignoren kann: das funkt alles nicht
					if (isset($ignore)) {
						$noshow = explode("----",$ignore);

						// max. 3 nicks koennen ignored werden:
						$ignore0 = $noshow[0];
						if (isset($noshow[1])) $ignore1 = $noshow[1];
						if (isset($noshow[2])) $ignore2 = $noshow[2];

						if(strpos($lines[$i],$ignore0) === false
							&& strpos($lines[$i],$ignore1) === false
								&& strpos($lines[$i],$ignore2) === false
						) {
							$new_lines[$i] = $lines[$i]."\n";
						}
					} else {
						$new_lines[$i] = $lines[$i]."\n";
					}
					
					$new_lines[$i] = $lines[$i]."\n";
				}

				//  Anzeige doppelter user nur von Zeit abhaengig machen, nicht vom user, geht auch ohne cookies
				elseif(strpos($lines[$i],_DBLUSER) !== false && $jetzt - $msgtime < $pnlivetime && $jetzt - $msgtime > 0){
					$new_lines[$i] = $lines[$i]."\n";
				}

			} else {	// wenn nicht /pn
				// wenn ignore cookie gesetzt:
				if (isset($ignore) && strpos($lines[$i],"loadytiframe") === false ) {

					$noshow = explode("----",$ignore);
					// max. 3 nicks koennen ignored werden:
					// $ignore0 = $noshow[0].":";
					// if (isset($noshow[1])) $ignore1 = $noshow[1].":";
					// if (isset($noshow[2])) $ignore2 = $noshow[2].":";

					// ignore auch alle msg, die ignored enthalten:
					// max. 3 nicks koennen ignored werden:
					$ignore0 = $noshow[0];
					if (isset($noshow[1])) $ignore1 = $noshow[1];
					if (isset($noshow[2])) $ignore2 = $noshow[2];


					if(strpos($lines[$i],$ignore0) === false
						&& strpos($lines[$i],$ignore1) === false
							&& strpos($lines[$i],$ignore2) === false
					) {
		
						
						// wenn chat bei Ankunft leer sein soll:
						if ((isset ($blankrooms) && $blankrooms == "yes"  && $admintrue === false && $modtrue === false) || (isset($blankroom) && in_array($wo, $blankroom) !== false) && $admintrue === false && $modtrue === false) {
							if ($msgtimeblank > $arrival) {
								$new_lines[$i] = $lines[$i]."\n";
							}
						} else {
							$new_lines[$i] = $lines[$i]."\n";
						}
					}
				} else {
					// wenn chat bei Ankunft leer sein soll:
				
					// echo "$msgtimeblank <br> $arrival"; exit;
				
					if ((isset ($blankrooms) && $blankrooms == "yes"  && $admintrue === false && $modtrue === false) || (isset($blankroom) && in_array($wo, $blankroom) !== false) && $admintrue === false && $modtrue === false) {
						if ($msgtimeblank > $arrival) {
							$new_lines[$i] = $lines[$i]."\n";
						}
					} else {
						$new_lines[$i] = $lines[$i]."\n";
					}
					
					// $new_lines[$i] = $msgtimeblank.$arrival;
					
					
				}
			} 

		}


		if (isset($new_lines)) {
		

			// (fluestert) ohne Adressaten generell nicht zeigen:
			$new_lines = str_replace ("(fl&uuml;stert)","",$new_lines);
			$new_lines = str_replace ("(flüstert)","",$new_lines);
			if ($nickname) {
				// mit @nickname Angesprochene sehen die Ansprache gehighlighted:
				//                      $new_lines = str_ireplace(trim($privat1),'<span style="font-weight:bold; color: #444; background-color: #ff6"> '.trim($privat1).'</span>',$new_lines);
				$new_lines = str_ireplace(trim($privat1),'<span class="at"> '.trim($privat1).'</span>',$new_lines);

				// Angefluesterte sehen die Ansprache gehighlighted:
				//                      $privat3 = str_replace("@",_TO,trim($privat1)).')'; // diese Ersetzung bereits in Zeile 1414
				$privat3 = str_replace("@"," ",trim($privat1)).')';
				//                      $new_lines = str_ireplace($privat3,'<span style="font-weight:bold; color: #444; background-color: #ff6"> '.trim($privat3).'</span>',$new_lines);
				$new_lines = str_ireplace($privat3,'<span class="whisper"> '.trim($privat3).'</span>',$new_lines);
			}

			return join("\n", $new_lines);
		}
	}
}


// // filesize abfragen vor dem AJAX refresh des Inhalts:
// function file_changed() {
// 	global  $room;
// 	if (file_exists($room)) {
// 		$size = filesize($room);
// 		return $size;
// 	}
// }

// function file_changed() {
// 	$lockFile = sys_get_temp_dir() . '/file_changed.lock';
//
// 	// Letzten Aufruf aus der Datei lesen
// 	if (file_exists($lockFile)) {
// 		$lastRun = (float) file_get_contents($lockFile);
// 		if (microtime(true) - $lastRun < .5) {
	// wenn return wegkommentiert, dann greift Sperre nicht.
	// mit return evtl. too many requests
// 			return; // Zu früh aufgerufen, also ignorieren
// 		}
// 	}
//
// 	// Neuen Zeitstempel speichern
// 	file_put_contents($lockFile, microtime(true));
//
// 	// Hier die eigentliche Logik von file_changed
// 	global  $room;
// 	if (file_exists($room)) {
// 		$size = filesize($room);
// 		return $size;
// 	}
// }


// Lockfile bleibt wie bisher (für Timing).
// Zusätzliche Cache-Datei, um die letzte Antwort zu speichern.
// Schnelle Response, selbst bei zu häufigem Aufruf.	
function file_changed() {
	global $room;

	// Eindeutiger Key pro Room (falls absoluter Pfad → hashen)
	$key = md5($room);

	$lockFile  = sys_get_temp_dir() . "/file_changed_{$key}.lock";
	$cacheFile = sys_get_temp_dir() . "/file_changed_{$key}.cache";

	// Lock prüfen
	if (file_exists($lockFile)) {
		$lastRun = (float) file_get_contents($lockFile);

		if (microtime(true) - $lastRun < 0.5 && file_exists($cacheFile)) {
			return file_get_contents($cacheFile);
		}
	}

	// Eigentliche Verarbeitung
	$result = 0;
	if (file_exists($room)) {
		$result = filesize($room);
	}

	// Zeitstempel + Cache aktualisieren
	file_put_contents($lockFile, microtime(true));
	file_put_contents($cacheFile, $result);

	return $result;
}


function presence_confirm() {
	global $nickname;
	if (!isset($nickname) || $nickname === "") { return "no"; }
	// Praesenz bestaetigt ("Ich bin da") -> Hardcap-Boden neu setzen. Kein Chat-Post.
	$lm_fh = @fopen("user/lastmsg.txt", "c+");
	if ($lm_fh && flock($lm_fh, LOCK_EX)) {
		$lm_now  = time();
		$lm_keep = array();
		rewind($lm_fh);
		while (($z = fgets($lm_fh)) !== false) {
			$p = explode("\t", trim($z), 2);
			if (!isset($p[1]))                continue;
			if ($p[0] === $nickname)          continue;
			if ($lm_now - (int)$p[1] > 86400) continue;
			$lm_keep[] = $p[0]."\t".$p[1];
		}
		$lm_keep[] = $nickname."\t".$lm_now;
		ftruncate($lm_fh, 0);
		rewind($lm_fh);
		fwrite($lm_fh, implode("\n", $lm_keep)."\n");
		fflush($lm_fh);
		flock($lm_fh, LOCK_UN);
	}
	if ($lm_fh) fclose($lm_fh);
	return "ok";
}

$sajax_request_type = "POST";
sajax_init();
sajax_export("add_line", "refresh", "user_online", "user_room", "file_changed", "presence_confirm");
sajax_handle_client_request();

?>