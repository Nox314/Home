<?php
session_start();

if (isset($_SESSION['chatuser'])) {
	$nickname = $_SESSION['chatuser'];
} 


header('Content-Type: application/javascript');

@include("chat_config.php");


$closepop = "no";
if(isset($self_close)) $closepop = "on";


$registered = 0;
if(isset($_SESSION['login']) && $_SESSION['login']==1 || isset($nickname)) $registered = 1;

$eigener = "";
if(isset($nickname)) $eigener = $nickname;


// Sprache abfragen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = $languages[0];
}
$lang = (isset($languages) && is_array($languages) && in_array($lang, $languages)) ? $lang : "de";


// Cookie reverse Anzeige abfragen
if (isset($_COOKIE["rev"])) {
	if ($_COOKIE["rev"]=="1") {
		$display_reverse=true;
	}
}
// bf_linear abfragen für reverse
if (isset($_COOKIE["bf_linear"])) {
	if ($_COOKIE["bf_linear"]=="1") {
		$display_reverse=true;
	}
}

// img_size abfragen
if (isset($_COOKIE["img_size"])) {
	$img_size = $_COOKIE["img_size"];
} else {
	$img_size = 120;
}


$s = "";
if (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
}	

if (!isset($no_pn)) {
	$no_pn = "sounds/eingang.mp3";   // Eingang Meldung von Dritten
}
if (!isset($pn_mich)) {
	$pn_mich = "sounds/sound11.mp3";   // Eingang /pn @mich
}
if (!isset($at_mich)) {
	$at_mich = "sounds/sound21.mp3";   // Eingang @mich
}

$lang_file = 'lang'.strtoupper($lang).'_inc.php';

if (file_exists($lang_file)) {
	include ($lang_file);
}


if (!isset($flood_test)) {$flood_test = 4;} 

?>


// Aktualisierungen abhängig von Anzahl User:
let time1 = 1000;
let userfile = "read_ip.php?standard=<?php echo urlencode($standard); ?>";
let lineCount = 1;	// Variable für alle Funktionen

function updateLineCount() {
	fetch(userfile)
		.then(response => response.text())
		.then(text => {
			// Jetzt liefert PHP direkt die Zahl, also einfach parsen
			lineCount = parseInt(text.trim(), 10) || 1;
		})
		.catch(() => {
			lineCount = 1;
		});
}

// Alle 10 Sekunden erneut abrufen
// setInterval(updateLineCount, 10000);


var width = window.innerWidth
|| document.documentElement.clientWidth
|| document.body.clientWidth;


if (holeCookie) {holeCookie("Style");}
style=cookieWert;


if (holeCookie) {holeCookie("rev");}
// if (cookieWert == "1") {reverse = 'reverse';} else {reverse = 'normal';}

if (style == 12 || cookieWert == "1" ) {
	reverse = 'reverse';
} else {
	reverse = 'normal';
}


/* ///////// audio-sprite: ////////////// */
/* /////// end audio-sprite ///////////////// */

var flood_test ="<?php echo $flood_test ?>";


away_msg = '';
function away() {
	away_msg = 'weg';
	add();
	alert('<?php echo _AWAY; ?>');
	
	away_msg = 're';
	add();
	away_msg = '';
}


// https://stackoverflow.com/questions/19020830/autoclose-alert
function tempAlert(msg, duration) {
	const el = document.createElement("div");

	el.style.position = "relative";
	el.style.top = "-60px";
	el.style.left = "0";
	el.style.fontSize = ".9em";
	el.style.backgroundColor = "white";
	el.style.padding = "6px";

	el.textContent = msg;

	const container = document.getElementById('uo');
	container.appendChild(el);

	setTimeout(() => {
		el.remove(); // moderner & sicherer
	}, duration);
}


function copyurl(text) {
	if (!navigator.clipboard) {
		console.error("Clipboard API nicht verfügbar");
		return;
	}
	// auf max. 15 Zeichen kürzen
	text_short = text.substring(0, 15);
		
	navigator.clipboard.writeText(text).then(() => {
		tempAlert('IP ' + text_short + ' copied to clipboard', 2000);
	}).catch(err => {
		console.error('Copy fehlgeschlagen:', err);
	});
}


// Enter schickt die Eingabe ab anstelle einer Zeilenschaltung in textarea
if (document.getElementById('line')) {
	document.f.line.onkeypress = function(e){
		e = e || event;
		if (e.keyCode == 13 && !e.shiftKey) { 
			add(); return false;
		}
		return true;
	}
}


// var Opera = (navigator.userAgent.match(/Opera|OPR\//) ? true : false);
var iOS = !!navigator.platform.match(/iPhone|iPod|iPad/); 
if (iOS ===true) {
	if (document.getElementById("soundwahl")) {
		document.getElementById("soundwahl").style.display = "none";
	} 
}


var show_user;

var sb = 0;
if (location.href.indexOf("shoutbox") != -1) sb = 1;

var check_n = 0;
var old_data = "--";
var old_result = 1;


var anz_opt = "<?php echo _OPT; ?>";

var light;
light = "<?php echo $chat_light ?>";

var nick;
nick = "<?php echo $eigener ?>";


function strpos (haystack, needle, offset) {
	// Finds position of first occurrence of a string within another  
	// discuss at: http://phpjs.org/functions/strpos    // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
	// *     example 1: strpos('Kevin van Zonneveld', 'e', 5);    // *     returns 1: 14
	var i = (haystack+'').indexOf(needle, (offset || 0));
	return i === -1 ? false : i;
}


function klapp(beitrag) {
	const el = document.getElementById(beitrag);
	const btn = document.getElementById('einaus_' + beitrag);

	if (!el) return;

	// prüfen, ob geöffnet oder geschlossen
	const isClosed = el.clientHeight === 0;

	if (isClosed) {
		// öffnen: Höhe auf scrollHeight setzen
		el.style.height = el.scrollHeight + 'px';
		btn.innerHTML = '△ ' + anz_opt;
		
		// nach Transition Höhe auf auto setzen, damit Inhalt flexibel bleibt
		el.addEventListener('transitionend', function setAuto() {
			// nur setzen, wenn noch geöffnet
			if (el.clientHeight !== 0) el.style.height = 'auto';
			el.removeEventListener('transitionend', setAuto);
		});
	} else {
		// schließen: auf aktuelle Höhe fixieren und dann auf 0 animieren
		el.style.height = el.scrollHeight + 'px';
		setTimeout(() => el.style.height = '0', 10);
		btn.innerHTML = '▽ ' + anz_opt;
	}
}

// #ae per Tastatur-Fokus auf-, beim Fokus-Verlassen wieder zuklappen
(function () {
	function initAe() {
		const ae     = document.getElementById('ae');
		const einaus = document.getElementById('einaus_ae');
		if (!ae || !einaus) return;
		const toggle = einaus.closest('a');		// der <a> im <h2>
		if (!toggle) return;

		// Inline-onfocus neutralisieren: wir steuern den Fokus jetzt selbst, sonst
		// klappt ein Maus-Klick durch onfocus(öffnen)+onclick(schließen) doppelt um ("Zucken").
		toggle.removeAttribute('onfocus');

		// Aufklappen nur bei Tastatur-Fokus – bei Maus/Touch erledigt das der onclick
		let zeiger = false;
		toggle.addEventListener('pointerdown', function () { zeiger = true; });
		toggle.addEventListener('pointerup',   function () { zeiger = false; });
		toggle.addEventListener('focus', function () {
			if (zeiger) { zeiger = false; return; }		// Maus/Touch → Klick übernimmt
			if (ae.clientHeight === 0) klapp('ae');		// Tastatur → nur öffnen, nie schließen
		});

		// Zuklappen, sobald der Fokus den Bereich (inkl. Umschalter) wirklich verlässt
		function imBereich(el) {
			return !!el && (ae.contains(el) || toggle === el || toggle.contains(el));
		}
		function vielleichtZuklappen(ev) {
			if (imBereich(ev.relatedTarget)) return;	// Fokus bleibt im Bereich → offen lassen
			if (ae.clientHeight !== 0) klapp('ae');		// nur schließen, wenn gerade offen
		}
		// focusout blubbert → fängt auch Wechsel zwischen den inneren Bedienelementen ab
		ae.addEventListener('focusout', vielleichtZuklappen);
		toggle.addEventListener('focusout', vielleichtZuklappen);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initAe);
	} else {
		initAe();
	}
})();

function kp(e){
	
	const el = document.getElementById('ae');
	// prüfen, ob geöffnet oder geschlossen
	const isOpen = el.clientHeight != 0;

	if (!e) e=event;
	// if (e.ctrlKey && e.keyCode==49) {klapp('ae'); document.getElementById("reverse").focus(); return false;} /* strg + 1 */
	if (e.keyCode==27  && isOpen){klapp('ae'); document.getElementById("line").focus();}
}
document.onkeydown=kp;


function FensterOeffnen (url) {
	var width  = screen.width * <?php echo (isset($more_smiley_width) ? $more_smiley_width : 0.67); ?>;
	var height = screen.height * <?php echo (isset($more_smiley_height) ? $more_smiley_height : 0.67); ?>;
	var left   = (screen.width  - width)/1.1;
	var top    = (screen.height - height)/3;
	var params = 'width='+width+', height='+height;
	params += ', top='+top+', left='+left;
	params += ', location=no';
	params += ', menubar=no';
	params += ', resizable=yes';
	params += ', scrollbars=yes';
	params += ', status=no';
	params += ', toolbar=no';
	params += ', dependent=yes';
	newwin=window.open(url,'usr_smileys', params);
	if (window.focus) {newwin.focus()}
	return false;
}


var self_close = "no";
var self_close = "<?php echo $closepop; ?>";

function closepopup() {
	if(typeof(newwin) == "object" && false == newwin.closed && self_close != "on") {
		newwin.close ();
		document.body.style.cursor = 'auto';
	} else {
		// do nothing;
	}
}


function YTPop (Adresse) {
	MeinFenster2 = window.open(Adresse,'youtube','width=800, height=450, left=0, top=0, toolbar=no, location=no, menubar=no, scrollbars=yes, status=no, resizable=yes, dependent=yes').focus();
}

function loadytiframe(newsrc){
	var newloc = newsrc;
	document.getElementById('mob_yt').style.height = "53vmin";
	document.getElementById('mob_yt').setAttribute('src', newloc);
}


function CookieSetz(Bezeichner,Wert,Dauer) {
	jetzt=new Date();
	Auszeit=new Date(jetzt.getTime()+Dauer*86400000);
	document.cookie=Bezeichner+"="+Wert+";expires="+Auszeit.toGMTString()+";";
}


var cookieWert;
function holeCookie(keksname) {
	var alleCookies, i;
	alleCookies=document.cookie;
	cookieArr=alleCookies.split(";");
	for(var i=0;i < cookieArr.length;i++) {
		if(cookieArr[i].split("=")[0].replace(/\s+/,"") == keksname) {
			cookieWert=cookieArr[i].split("=");
			cookieWert=decodeURIComponent(cookieWert[1].replace(/\+/g," "));
			return true;
		}
	}
	return false;
}


// Abfrage, ob Admin:
<?php
$admincheck = 0;
if (isset($nickname)) {
	if (file_exists("admin/admins.txt") && file_exists("admin/admin_add_admins.php")) {
		$admins2 = file("admin/admins.txt"); 
		$admins2 = array_map('trim',$admins2);
		$admins = array_merge($admins, $admins2);
	}
	foreach($admins as $key => $val) {
		if ($nickname == trim($val)) {$admincheck = 1;}
	}
}

$modcheck = 0;
if (isset($nickname)) {
	if (file_exists("admin/mods.txt") && file_exists("admin/admin_mods.php")) {
		$mods = file("admin/mods.txt"); 
	}
	foreach($mods as $key => $val) {
		if ($nickname == trim($val)) {$modcheck = 1;}
	}
}

?>

var isadmin = "<?php echo $admincheck ?>";
var ismod = "<?php echo $modcheck ?>";

if(isadmin==1 && ismod==1) {alert ("Achtung! Du bist gleichzeitig Admin und Moderator!")};

allow_url_fopen = <?php if(ini_get('allow_url_fopen') == 1) {echo 1;}else{echo 0;} ?>;


<?php

// http://www.myhpi.de/~dtibbe/php/php2js.php
function php2js($php = array(), $name = 'foo', $useVar = TRUE) {
	if (!is_array($php)) {
		trigger_error('The first parameter has to be an array', E_USER_ERROR);
		die();
	}

	static $first = TRUE;
	if ($first) {
		if ($useVar) { echo 'var '; }
		echo $name.' = '; $first = FALSE;
	}

	echo "new Array();\n";
	foreach ($php as $key => $value) {
		$OName = $name.'[';
		if (is_numeric($key)) {
			$OName .= $key;
		} else {
			$OName .= '"'.$key.'"';
		}
		$OName .= ']';

		echo $OName.' = ';

		if (is_array($value)) {
			php2js($value, $OName, FALSE);
		} else {
			if (is_numeric($value)) {
				echo $value;
			} else {
				echo '"'.$value.'"';
			}
			echo ";\n";
		}

	}
}
  

if (isset($user_whisper) && $user_whisper == "admin") {
	echo  php2js($admins, 'all_admins');
}

?>


// unerlaubte Raumnamen zurueckweisen:
function room_name() {
	if (document.forms[2].room.value.match(/\W/)) {

		alert ("<?php echo _ROOMNOTALLOWED; ?>");
		return false;
	}
}


// AJAX http://board.gulli.com/thread/801675-php-script-aus-einem-javascript-aufrufen/
function get(url, callback_function, return_xml){
	var http_request = false;

	if (window.XMLHttpRequest) {
		http_request = new XMLHttpRequest();
		if (http_request.overrideMimeType) {
			http_request.overrideMimeType('text/xml; charset= iso-8859-1');
		}
	}else if(window.ActiveXObject) {
		try {
			http_request = new ActiveXObject("Msxml2.XMLHTTP");
		}catch (e) {
			try {
				http_request = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {}
		}
	}
	if (!http_request) {
		alert('Leider unterstuetz Ihr Browser diese Funktion nicht.');
		return false;
	}
	http_request.onreadystatechange = function() {
		if (http_request.readyState == 4) {
			if (http_request.status == 200) {
				if (return_xml) {
					// eval(callback_function + '(http_request.responseXML)');
					window[callback_function](http_request.responseXML);
				} 
			} else {
				alert('Problem: ' + http_request.status + ')');
			}
		}
	}
	http_request.open('GET', url, true);
	http_request.send(null);
}


function playmp3_mit_http(typ) {
	document.getElementById("mp3").style.display="inline-block";
	document.getElementById("mp3").innerHTML = '<audio autoplay="autoplay" controls="controls" onended="hide_player()" controlslist="nodownload noplaybackrate"><source src="'+typ+'"  ></audio>';
	//document.getElementById("line").focus();
	
	
	if (holeCookie) {holeCookie("counted");}
	if (cookieWert != typ) { // bei wiederholten Klicks des selben Titels nur einmal zaehlen
		get("mp3log.php?file="+typ,""); // Aufruf der Funktion zum Schreiben des Logfiles
		
		// erst nach 2 Min. wird der selbe Titel erneut gezaehlt
		var ablauf = new Date();
		var Minuten = ablauf.getTime() + ( 120 * 1000); 
		ablauf.setTime(Minuten);
		document.cookie="counted="+typ+"; expires=" + ablauf.toGMTString();
	}
}


function playmp3olog_mit_http(typ) {	
	document.getElementById("mp3").style.display="inline-block";
	document.getElementById("mp3").innerHTML = '<audio src="'+typ+'" autoplay controls onended="hide_player()"  controlslist="nodownload noplaybackrate" oncontextmenu="return false;"><p> <a href="'+typ+'">Play</a></p></audio>';
	//document.getElementById("line").focus();
	
	
}

function hide_player() {
	document.getElementById("mp3").style.display="none";
}


function jump(form) { 
	order = form.menu1.selectedIndex; 
	if (form.menu1.options[order].value != 0) { 
		ads(form.menu1.options[order].value);
	} 
} 

function jump_color(form) {
	window.__chatLoggingOut = true;   // interner Reload, keine "Seite verlassen?"-Rückfrage
	let input = form.querySelector('input');
	let nc = input.value.replace('#', '');

	// Helle Farben abdunkeln (d,e,f → c)
	nc = nc.replace(/[def]/g, 'c').replace(/[DEF]/g, 'C');

	// Zu dunkle Zahlen vermeiden (0,1,2 → 3)
	nc = nc.replace(/[012]/g, '3');

	// speichern
	localStorage.setItem('color', nc);
	setTimeout(() => location.reload(), 50);
	// document.getElementById('line').focus();
}
// Farbe persistent, auch wenn Cookies gelöscht werden
window.addEventListener('DOMContentLoaded', () => {
	let savedColor = localStorage.getItem("color");
	if(savedColor) {
		// Prüfen, ob Cookie existiert oder anders ist
		let cookies = document.cookie.split(';').map(c => c.trim());
		let colorCookie = cookies.find(c => c.startsWith("color="));
		if(!colorCookie || colorCookie.split('=')[1] !== savedColor) {
			// Cookie richtig setzen
			document.cookie = "color=" + savedColor + ";  max-age=" + (60*60*24*365);
			// Kleines Delay, damit der Cookie im Browser registriert wird, dann Reload
			window.__chatLoggingOut = true;   // interner Reload, keine "Seite verlassen?"-Rückfrage
			setTimeout(() => location.reload(), 50);
		}
	}
});

var ablauf2 = new Date();
var Minuten2 = ablauf2.getTime() + (360 * 24 * 60 * 60 * 1000);
ablauf2.setTime(Minuten2);
function jump2(form) {
	order = form.menu2.selectedIndex;
	if (form.menu2.options[order].value != 0) {
		var style = form.menu2.options[order].value;
		document.cookie="Style="+style+"; expires=" + ablauf2.toGMTString();
		window.__chatLoggingOut = true;   // interner Reload, keine "Seite verlassen?"-Rückfrage
		window.location.reload();
	}
}

function setlang(lg) {
	document.cookie="lang="+lg+"; expires=" + ablauf2.toGMTString();
}

function playsound(typ) { // die standardkonforme Loesung fuer alle Browser
	if (document.getElementById('ton') && iOS !==true) {
		document.getElementById("ton").innerHTML = '<audio src="'+typ+'" autoplay controlslist="nodownload"></audio>';
	}
}

function scrollToBottomReliable(elem) {
	// Videos ergänzt
	const media = [
		...Array.from(elem.querySelectorAll('img')),
		...Array.from(elem.querySelectorAll('video'))
	];

	function doScroll() {
		requestAnimationFrame(() => {
			requestAnimationFrame(() => {
				elem.scrollTo({ top: elem.scrollHeight, behavior: 'auto' });
			});
		});
	}

	if (media.length === 0) {
		doScroll();
		return;
	}

	let done = 0;
	function check() {
		if (++done === media.length) doScroll();
	}

	media.forEach(el => {
		if (el.tagName === 'IMG') {
			// naturalWidth > 0 ergänzt – complete allein reicht bei Fehler-Bildern nicht
			if (el.complete && el.naturalWidth > 0) {
				check();
			} else {
				el.addEventListener('load',  check, { once: true });
				el.addEventListener('error', check, { once: true });
			}
		} else {
			// Video: Dimensionen bekannt ab HAVE_METADATA
			if (el.readyState >= HTMLMediaElement.HAVE_METADATA) {
				check();
			} else {
				el.addEventListener('loadedmetadata', check, { once: true });
				el.addEventListener('error',          check, { once: true });
			}
		}
	});
}

if (!(/iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1))) {
	let resizeTimer;
	window.addEventListener('resize', () => {
		clearTimeout(resizeTimer);
		resizeTimer = setTimeout(() => {
			const el = document.getElementById('wall');
			scrollToBottomReliable(el);
		}, 100);

	});
}


function doARIA(new_data) {
	if (!document.getElementById("jaws")) return;
	<?php	
	if (isset($display_reverse) && $display_reverse === true || $s == "12") {
	echo'		
		msg_pos = new_data.indexOf(": pointer");
		msg_pos1 = new_data.indexOf("</p>");
		last_msg = new_data.substr(msg_pos + 11,msg_pos1);
	';
	} else {
	echo'		
		msg_pos = new_data.lastIndexOf(": pointer");
		last_msg = new_data.substr(msg_pos + 11);
	';	
	}
	?>

	if (last_msg.indexOf("<img") != -1 && last_msg.indexOf("alt") != -1) {
		holeCookie("pic");
		start_img = strpos(last_msg, '<img', 0);
		sub0_aria = last_msg.substring(0,start_img);
		start_alt = strpos(last_msg, 'alt=', 0);
		sub1_aria = last_msg.substring(start_alt +5);
		end_alt = strpos(sub1_aria, '"',0);
		sub2_aria = sub1_aria.substring(0,end_alt);
		if (cookieWert == 0) {
			sub2_aria = "";
		}
		rest = strpos(sub1_aria,'>',0);
		sub3_aria = sub1_aria.substring(rest + 1);
		last_msg = sub0_aria + sub2_aria + sub3_aria;
	}

	<?php	if (isset($display_reverse) && $display_reverse === true || $s == "12") {
	echo'		
		msg_pos1 = last_msg.indexOf("</p>");
		last_msg = last_msg.substr(0,msg_pos1);
	';
	}
	?>
	
	document.getElementById("jaws").innerHTML = '<p>' + last_msg + '</p>';
}


function refresh_cb(new_data) {

	last_msg="";
	msg_pos = 0;
	teil_msg = "";
	if (typeof old_data == "undefined" || old_data == "--") {
		if (playsound) playsound('<?php echo $sound1 ?>'); // Sound bei reload
	} else {
		if (typeof handle != "string") {
			holeCookie("nick");

			msg_pos = new_data.lastIndexOf("color:");
			last_msg = new_data.substr(msg_pos);
				 
	
			if (old_msg != last_msg && last_msg.indexOf(nick) != -1 && last_msg.indexOf('@') != -1 && last_msg.indexOf('(flüstert') == -1  ) {
				playsound('<?php echo $at_mich ?>'); // Sound bei @mich
				// if (style!= '12' && style !='11') {popup(new_data);}
			}				 
			else if (old_msg != last_msg && last_msg.indexOf(nick) != -1 && last_msg.indexOf('(flüstert') != -1 ) {
				playsound('<?php echo $pn_mich ?>'); // Sound bei /pn @mich
				// if (style!= '12' && style !='11') {popup(new_data);}
			}
			else if (old_msg != last_msg && last_msg.indexOf("/pn") == -1) {
				playsound('<?php echo $no_pn ?>'); // Sound bei Nachrichten von Dritten, kein /pn
				// if (style!= '12' && style !='11') {popup(new_data);}
			}
				 

			function alertMsg() {
				alert("Hallo! Aufwachen!\nHello! Wake Up!");
			}
                 
			// der Alarmruf:
			if (last_msg.indexOf("/alarm") != -1 && last_msg.indexOf(nick) != -1) {
				playsound('<?php echo $sound6 ?>');
				setTimeout(alertMsg,3000);
			}

			// User betritt den Chat:
			// if (last_msg.indexOf("hat den Chat betreten") != -1 && last_msg.indexOf("/pn") == -1) {
			if (last_msg.indexOf("hat den Chat betreten") != -1) {
				playsound('<?php echo $sound2 ?>');
			}

			// User verlässt den Chat:
			// if (last_msg.indexOf("hat sich ausgeloggt") != -1 && last_msg.indexOf("/pn") == -1) {
			if (last_msg.indexOf("hat sich ausgeloggt") != -1) {
				playsound('<?php echo $sound5 ?>');
			}

//			// echter /kick:
//			if (last_msg.indexOf("you've been kicked") != -1 && last_msg.indexOf(nick) != -1) {
//				window.location.href = 'kick.php?nick='+nick;
//			}

		}
	}

	old_msg = "";
	if (typeof last_msg == "string") old_msg = last_msg;
	handle = 1;

	if (new_data === old_data) {
		old_data = new_data;
		return; // vermeidet Leerscroll wenn geflüstert wird
	}
holeCookie("freeze");
	if (cookieWert == "0") {
		// GIFs/WebP vorab laden und einfrieren, dann erst innerHTML setzen
		var srcRegex = /src=["']\s*([^"'\s]+\.(?:gif|webp|avif))\s*["']/gi;
		var urls = [];
		var match;
		while ((match = srcRegex.exec(new_data)) !== null) {
			if (urls.indexOf(match[1]) === -1) urls.push(match[1]);
		}

		if (urls.length === 0) {
			if (document.getElementById("wall")) {document.getElementById("wall").innerHTML = new_data;}
			doARIA(new_data);
			scrollToBottomReliable(document.getElementById('wall'));
		} else {
			var dataMap = {};
			var loaded = 0;
			urls.forEach(function(url) {
				var img = new Image();
				img.crossOrigin = "anonymous";
				img.onload = function() {
					var c = document.createElement('canvas');
					c.width = img.naturalWidth;
					c.height = img.naturalHeight;
					c.getContext('2d').drawImage(img, 0, 0);
					dataMap[url] = c.toDataURL(url.match(/\.webp/i) ? "image/webp" : url.match(/\.avif/i) ? "image/avif" : "image/gif");
					if (++loaded === urls.length) {
						var frozen_data = new_data.replace(/src=["']\s*([^"'\s]+\.(?:gif|webp|avif))\s*["']/gi, function(full, u) {
							return dataMap[u] ? 'src="' + dataMap[u] + '"' : full;
						});
						if (document.getElementById("wall")) {document.getElementById("wall").innerHTML = frozen_data;}
						doARIA(new_data);
						scrollToBottomReliable(document.getElementById('wall'));
					}
				};
				img.onerror = function() {
					dataMap[url] = url;
					if (++loaded === urls.length) {
						if (document.getElementById("wall")) {document.getElementById("wall").innerHTML = new_data;}
						doARIA(new_data);
						scrollToBottomReliable(document.getElementById('wall'));
					}
				};
				img.src = url;
			});
		}
	} else {
		if (document.getElementById("wall")) {document.getElementById("wall").innerHTML = new_data;}
		doARIA(new_data);
		scrollToBottomReliable(document.getElementById('wall'));
	}
	old_data = new_data;
}

// bei klick auf den down-arrow:
function scroll_click() {
	elem = document.getElementById('wall');
	if (reverse !== "reverse") {			
		elem.scrollTop=elem.scrollHeight;
	}
}


var old_size;
function set_file_changed(new_size) {
	if (chatIdle) { return; }

	elem = document.getElementById('wall');
	

	// optional: Pfeil-/Background-Logik bleibt nur zur Anzeige
	if (elem.scrollHeight - elem.scrollTop - elem.clientHeight > 25 && reverse != "reverse") {
		elem.style.backgroundImage = "url('img/arrow_dwn.png')";
		elem.style.backgroundRepeat = "no-repeat";
		const phone = window.matchMedia("(max-width: 600px)").matches;
		elem.style.backgroundPosition = phone
			? "right -2px bottom 6px"
			: "right 12px bottom 6px";
		
		elem.style.backgroundSize = "22px";
		if (document.getElementById('clickable')) {
			document.getElementById('clickable').style.visibility = "visible";
		}
	} else {
		elem.style.background = "none";
		if (document.getElementById('clickable')) {
			document.getElementById('clickable').style.visibility = "hidden";
		}
	}

	if (elem.scrollHeight - elem.scrollTop - elem.clientHeight <= 25 || (reverse == "reverse" && elem.scrollTop < 25 )) {

		// Chat-Refresh nur, wenn sich Größe geändert hat
		if (typeof old_size === "undefined" || new_size != old_size) {
			old_size = new_size;
			x_refresh(refresh_cb);
		}

	}
	

	// setTimeout für Chat-Refresh nur, wenn Tab aktiv
	if (!document.hidden) {
		time2 = (+time1) + (lineCount * 100);
		// console.log(time2);
		setTimeout(() => x_file_changed(set_file_changed), time2);
	}

}


function add_cb() {
	// we don't care..
}


var handle; // Var global wg. Klick on send

let conversation = []; // Chatbot-Verlauf

async function add() {
	
line = document.getElementById("line").value;

if (/[@\/](Bot|Chatbot)\b/i.test(line)) {

	line2 = line.replace(/[@\/](bot|chatbot)/gi, '').trim();

	// Verlauf aktualisieren (User-Eingabe)
	conversation.push({ role: "user", content: line2 });

	// Zeige Frage im Chat
	if (line.includes('/pn')) {
		x_add_line(handle + ": (flüstert mit Chatbot) " + line2 + "/pn", add_cb);
	} else {
		x_add_line(handle + ": @Chatbot " + line2, add_cb);
	}

	// GPT-Aufruf
	fetch("gpt_bot.php", {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ messages: conversation })
	})
	.then(response => response.text())
	.then(reply => {
		document.getElementById("line").value = '';

		reply = reply
			.replace(/\r\n/g, '\n')
			.replace(/[ \t]*\n[ \t]*/g, '\n')
			.replace(/\n{2,}/g, '\n')
			.trim();
			
		// Antwort um @user ergänzen
		reply = '@' + nick + ' ' + reply;
		
		// Antwort im Verlauf speichern
		conversation.push({ role: "assistant", content: reply });

		// Zeige Antwort
		if (line.includes('/pn')) {
			x_add_line(handle + ":&shy;Chatbot: " + reply + "/pn", add_cb);
		} else {
			x_add_line(handle + ":&shy;Chatbot: " + reply, add_cb);
		}
	})
	.catch(error => {
		document.getElementById("line").value = ' Fehler bei der Antwort.';
	});

} else {
	
	away_msg == "";
	
	holeCookie("watch");
	
	if (location.search.indexOf('room=Info') == -1) {
		if (away_msg == "weg"  && (isadmin < 1 || cookieWert != "on")) {line = "[hello2][<?php echo _AWAY_MSG; ?>][/hello2] ";}
		if (away_msg == "warm" && (isadmin < 1 || cookieWert != "on")) {line = "[hello2][<?php echo _WARM_MSG; ?>][/hello2] ";}
		if (away_msg == "re"   && (isadmin < 1 || cookieWert != "on")) {line = "[hello][<?php echo _RE_MSG; ?>][/hello] "; window.__chatLoggingOut = true; document.location.reload(false);}
	}

	if (cookieWert == "on" && line.indexOf("afk") != -1 ) {
		alert ("Away from keyboard (afk) nicht verwenden, wenn ghost-mode on.");
		document.getElementById("line").value = "";
		return;
	}


	handle = document.getElementById("handle").value;

	// Fluestern nur erlauben, wenn ein Admin beteiligt ist
	var user_whisper = "<?php if(isset($user_whisper)) echo $user_whisper; ?>";
	if (user_whisper == "admin") {
		if (line.indexOf("/pn") != -1) {
			if (isadmin != 1 ) { // der Admin darf alle anfluestern
				// suchen, ob einer der Admins angesprochen wird
				var at_admin = 0;
				for (var i = 0; i < all_admins.length; i++) {
					if (line.indexOf('@'+all_admins[i]+' ') != -1) {
						var at_admin = 1;
					}
				}
				if (at_admin != 1) {
					alert("<?php echo _WHISPERNOTALLOWED ?>");
					return;
				}
			}
		}
	}


	// nicht an mehrere Empfänger flüstern
	// und auch /pn @user1 @user2 bla bla unterbinden
	var count2 = (line.match(/@/g) || []).length;
	if (line.indexOf("/pn") != -1 && count2 >= 2) {
		alert ("Achtung! Du versuchst, mit mehr als einem User gleichzeitig zu flüstern! Das ist hier nicht erlaubt.");
		line = "";
	}

	// nicht an sich selbst schreiben:
	holeCookie("nick");
	if (line.indexOf("@" + cookieWert + " ") != -1 ) {
		alert ("Willst du wirklich an dich selbst schreiben?");
		return;
	}	


	// keine leere Nachricht zulassen:
	if (line == "" || line == "(<?php echo _MESSAGE; ?>)" ) {
		return;
	}
	
	if (line.indexOf("file://") != -1) {
		alert ("<?php echo _CHARNOTALLOWEDMSG; ?>");
		if (document.getElementById("line")) document.getElementById("line").value = "";

		return;
	}


	if (isadmin != 1) {
		if (line.indexOf("/add") != -1) { //muss hier bereits abgefangen werden wg. folgendem if
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
	}

	if (line.indexOf("/add ") != -1 && isadmin == 1 && allow_url_fopen != 1) {
		alert ("Dein Server erlaubt das leider nicht (allow_url_fopen=off)");
		if (document.getElementById("line")) document.getElementById("line").value = "";
		return;
	}


	// die Versionsanzeige
	fetch('chtver.txt?nocache=' + Date.now())
	.then(response => response.text())
	.then(data => {
		if (line.indexOf("/version") != -1) {
			alert ("Chat by webdesign.weisshart.de \nVersion: " + data);
		}
	})
	if (line.indexOf("/version") != -1) {
		document.getElementById("line").value = "";
		return;
	}


	if (line.indexOf("/usr_smileys.php#") != -1 || line.indexOf("#a") != -1 ) {
		alert ("Drag & Drop von Smileys geht nur aus dem Nachrichtenfenster, \naber nicht von der Smiley-Leiste oder dem More Smileys Fenster.");
		document.getElementById("line").value = "";
		return;
	}


	var user_whisperroom = "<?php if(isset($user_whisperroom)) echo $user_whisperroom; ?>";
	if (user_whisperroom == "admin") {
		if (line.indexOf("_pr") != -1 && isadmin != 1) {
			alert ("<?php echo _WHISPERROOMSNOTALLOWED; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";
			return;
		}
	}

	var guest_write = "<?php if(isset($guest_write)) echo $guest_write; ?>";
	if (guest_write == "no" ) {
		var nickname = "<?php if(isset($nickname)) echo $nickname ?>";
		if (nickname.indexOf("Gast") !== -1) {
			alert ("<?php echo _READONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
	}


	Check = "true";
	if (isadmin == 1  && line.indexOf("/del ") != -1) {
		Check = confirm("<?php echo _DELROOM; ?>");
		if (Check == false) {
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
	}


	//alle Smileys in dir löschen

	function doesFileExist(urlToFile) {
		var xhr = new XMLHttpRequest();
		xhr.open('HEAD', urlToFile, false);
		xhr.send();

		if (xhr.status == "404") {
			// console.log("File doesn't exist");
			return false;
		} else {
			// console.log("File exists");
			return true;
		}
	}

	Check2 = "true";
	if (isadmin == 1  && line.indexOf("/del_all_smileys_in_box") != -1) {
		
		numb = line.match(/\d/g);
		if (numb) {numb = numb.join("");}
		// console.log(numb);
		
		if (doesFileExist("smileys" + numb)) {
			// alert('OK');

			Check2 = confirm("Box " +numb+ ": <?php echo _DELALLSMILEYS; ?>");
			if (Check2 == false) {
				if (document.getElementById("line")) document.getElementById("line").value = "";
				return;
			}

		} else {
			alert (numb+': Diese Smileybox gibt es nicht.');
			if (document.getElementById("line")) document.getElementById("line").value = "";
			return;
		}
		
	}


	// mehr als 4 mal das gleiche Zeichen oder die gleiche Zeichenfolge (z.B. smileys) zurueckweisen und umwandeln
	if (isadmin != 1 && ismod != 1) {
		var re = new RegExp("(\.+)\\1{"+flood_test+",}"); 
		if (line.search(re) != -1 && line.indexOf("#") == -1 && line.indexOf("000") == -1  && line.indexOf("youtube") == -1 && line.indexOf("https") == -1) {
			alert("<?php echo _CHARREP; ?>");
			return;
		}
	}


	// mehr als 4 mal Leerraum oder Zeilenschaltung zurueckweisen und umwandeln
	if (isadmin != 1 && ismod != 1) {
		var re = new RegExp("(\\n+)\\1{"+flood_test+",}"); 
		if (line.search(re) != -1) {
			alert("<?php echo _CHARREP; ?>");
			return;
		}
	}


	// Schreien (nur Grossbuchstaben) zurueckweisen:
	if (isadmin != 1 && line.indexOf(")") == -1 && line.indexOf("(") == -1) {

		// Entferne Emojis, Ziffern und Sonderzeichen
		let only_letters = line.replace(/[\p{Emoji_Presentation}\p{Emoji}\p{Punctuation}\p{Number}\s\d]/gu, '');

		// Prüfe, ob alle Buchstaben groß sind
		if (only_letters && only_letters === only_letters.toUpperCase() && line.length > flood_test) {
			alert("<?php echo _UPPERCASE; ?>");	
		}
		  
	}


	// Mehrfacheingabe von Upload oder sonstiger Links unterbinden
	if (line.lastIndexOf("http:") - line.indexOf("http:") > 0 && line.indexOf("smileys")  == -1  ) {
		alert("<?php echo _MULTURL; ?>");
		return;
	}


	// if (line.indexOf("/away") != -1 ) { away();return false }

//	if (line.toUpperCase().indexOf(" AFK") !== -1 || line.toUpperCase().indexOf(" A F K") !== -1 && line.indexOf(" ist ") == -1 && line.indexOf(" is ") == -1 && line.indexOf(" iss ") == -1 || line.toUpperCase() == "AFK " || line.toUpperCase() == "A F K" ) { away(); return false}


	if (line.indexOf("/ip") != -1 && isadmin == 1) {
		document.cookie="showip=on; expires=" + ablauf2.toGMTString();
		window.__chatLoggingOut = true;   // interner Reload, keine "Seite verlassen?"-Rückfrage
		document.location.reload(false); 
	}

	if (line.indexOf("/noip") != -1 && isadmin == 1) {
		document.cookie="showip=off; expires=" + ablauf2.toGMTString();
		window.__chatLoggingOut = true;   // interner Reload, keine "Seite verlassen?"-Rückfrage
		document.location.reload(false); 
	}

	if (line.indexOf("/go") != -1) {
		window.__chatLoggingOut = true;   // interner Reload, keine "Seite verlassen?"-Rückfrage
		document.location.reload(true);
	}


	// bestimmte Befehle zurueckweisen, wenn nicht Admin oder Mod:
	if (isadmin != 1 && ismod !=1) {
		if (line.indexOf("/ban ") != -1
		|| line.indexOf("/maul ") != -1
		|| line.indexOf("/nopv ") != -1
		) {
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
		
		p_room = "<?php if(isset($_SERVER['HTTP_REFERER'])) echo $_SERVER['HTTP_REFERER'] ?>";
		if (line.indexOf("/clear") != -1 && p_room.indexOf("_pr") == -1) {
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
		
	}
		
	// bestimmte Befehle zurueckweisen, wenn nicht Admin:
	if (isadmin != 1) {
		if (line.indexOf("/ghost") != -1
		|| line.indexOf("/peep") != -1
		|| line.indexOf("/nopeep") != -1
		|| line.indexOf("/ip") != -1
		|| line.indexOf("/noip") != -1
		|| line.indexOf("/approve") != -1
		|| line.indexOf("/offline") != -1
		|| line.indexOf("/del") != -1
		|| line.indexOf("/del_smiley") != -1
		|| line.indexOf("/topic") != -1
		|| line.indexOf("/pixel") != -1
		|| line.indexOf("/alarm") != -1
		|| line.indexOf("/showprofil") != -1				
		|| line.indexOf("/profil") != -1				
		) {
			alert("<?php echo _JSADMINONLY; ?>");
			if (document.getElementById("line")) document.getElementById("line").value = "";

			return;
		}
		
		
		if (line.indexOf("img ") != -1
		|| line.indexOf(" src") != -1
		) {
			alert("<?php echo _NOHTML; ?>");
			return;
		} 

			
	}

	if (isadmin != 1 && ismod !=1) {
		if (line.indexOf("/erase") != -1 || line.indexOf("/pin") != -1 || line.indexOf("/stick") != -1 ) {
			alert("<?php echo _JSADMINONLY; ?>");
			return;
		}
	}


	const verbotsBefehle = ['/ban ', '/igno ', '/show', '/maul ', '/nopv '];

	// Prüfen, ob einer der verbotenen Befehle enthalten ist
	const hatVerbot = verbotsBefehle.some(cmd => line.includes(cmd));

	if (hatVerbot) {
		// ggf /pn entfernen
		line = line.replace(/\s*\/pn\b/g, '');
		const andereSlashes = line.match(/\/\w+/g);
	
		// Wenn mehr als ein unerlaubter Slash (zusätzlich zum ersten) vorhanden ist
		if (andereSlashes && andereSlashes.length > 1) {
			alert ("Bitte nicht mehrere Befehle in einer Zeile."); 
			return;
		} 
	}

	if (line.trim() == '/ban' 
		|| line.trim() == '/maul' 
		|| line.trim() == '/maulkorb' 
		|| line.trim() == '/nopv' 
	)  {
		alert ("Bitte noch den Nick eingeben (mit oder ohne @) den du blocken willst."); 
		return;
	}
	if (line.trim() == '/igno' 
		|| line.trim() == '/ignore' 
	)  {
		alert ("Bitte noch den Nick eingeben (mit oder ohne @) den du ignorieren willst."); 
		return;
	}
		
	// kein zusätzlicher Text in _pr-Einladung
	if (line.indexOf("_pr ") !== -1 && line.indexOf(" @") !== -1 ) {
		const re = /^.*?_pr @[^\s/]+\s*$/;

		if (!re.test(line)) {
			alert("Bei Einladung in Privatraum (Rechtsklick) bitte keinen zusätzlichen Text eingeben. Wenn du nur Flüstern willst: Linksklick.");
			return;
		}
	}
		
	x_add_line(handle + ": " + line, add_cb);

	if (document.getElementById("line")) document.getElementById("line").value = "";

	scrollToBottomReliable(document.getElementById('wall'));

}	
}


// http://hendi.name/2006/04/08/str_replace-fur-javascript/
// wird fuer die folgende function set_user benoetigt
function str_replace(search, replace, subject) {
	return subject.split(search).join(replace);
}

var letzteUserliste = '';
var chatIdle = false;

// Barrierefreier, iOS-tauglicher Hinweis, wenn der Server uns wegen Inaktivitaet
// aus der Liste genommen hat. Quittieren = "Ich sitze davor" -> reaktivieren.
function zeigeIdleHinweis() {
	if (document.getElementById('idle_overlay')) { return; }

	var line = document.getElementById('line');
	if (line) { line.blur(); }		// iOS: Soft-Tastatur schliessen

	var ov = document.createElement('div');
	ov.id = 'idle_overlay';
	ov.setAttribute('role', 'dialog');
	ov.setAttribute('aria-modal', 'true');
	ov.setAttribute('aria-labelledby', 'idle_titel');
	ov.tabIndex = -1;
	ov.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:1em;background:rgba(0,0,0,.85);-webkit-tap-highlight-color:transparent;';

	var box = document.createElement('div');
	box.style.cssText = 'max-width:22em;background:#fff;color:#000;border-radius:10px;padding:1.25em;text-align:center;font-family:sans-serif;line-height:1.4;';

	var h = document.createElement('p');
	h.id = 'idle_titel';
	h.style.cssText = 'margin:0 0 .75em;font-weight:bold;';
	h.textContent = 'Bist du noch da, ' + nick + '?';

	var t = document.createElement('p');
	t.style.cssText = 'margin:0 0 1.25em;';
	t.textContent = 'Wegen Inaktivitaet wurdest du aus der Userliste genommen. Du bist noch eingeloggt.';

	var btn = document.createElement('button');
	btn.type = 'button';
	btn.textContent = 'Wieder mitmachen';
	btn.style.cssText = 'font-size:1em;padding:.6em 1.2em;border:0;border-radius:8px;background:#06c;color:#fff;cursor:pointer;';

	function reaktivieren() {
		document.removeEventListener('keydown', onKey, true);
		btn.disabled = true;
		// Praesenz serverseitig bestaetigen (Hardcap-Boden neu), dann frisch laden.
		x_presence_confirm(function () {
			window.__chatLoggingOut = true;		// interner Reload, keine "Seite verlassen?"-Rueckfrage
			location.reload();
		});
	}

	function onKey(e) {
		if (e.key === 'Escape' || e.keyCode === 27) { reaktivieren(); }
	}

	btn.addEventListener('click', reaktivieren);
	document.addEventListener('keydown', onKey, true);

	box.appendChild(h);
	box.appendChild(t);
	box.appendChild(btn);
	ov.appendChild(box);
	document.body.appendChild(ov);
	ov.focus();
}


function set_user(result) {
	var uo = document.getElementById('uo');
	if (!uo) return;
	
	// Server signalisiert Streichung wegen Inaktivitaet -> Overlay statt Listen-Update.
	if (result.indexOf('IDLE_EVICTED') !== -1) {
		chatIdle = true;		// Polls stoppen -> kein Datenverkehr mehr
		zeigeIdleHinweis();
		return;
	}
	
	
	// Bei jedem Poll wechselnde Tokens nur fuer den Vergleich ausblenden,
	// damit eine inhaltlich unveraenderte Userliste als unveraendert gilt:
	//  - Zufalls-Token der _pr-Raeume (oncontextmenu)
	//  - Zeitstempel test=… in den Profil-Links (popprof.php)
	var normalisiert = result
		.replace(/(ads\(')[^']*?(_pr )/g, '$1$2')
		.replace(/test=\d+/g, 'test=');
	
	if (normalisiert === letzteUserliste) {
		return; // nichts geaendert -> DOM nicht zerstoeren, Fokus/VO-Cursor bleibt
	}
	letzteUserliste = normalisiert;
	
	uo.innerHTML = result;
}

show_active_users_only = <?php if (isset($show_active_users_only)) {echo $show_active_users_only;} else {echo 1;} ?>;
// console.log(show_active_users_only); 

if (show_active_users_only == 0) {
	console.log('0: Alle User zeigen, bei denen der Chat in irgendeinem, auch inaktivem, Browserfenster läuft');
} 
if (show_active_users_only == 1) {
	console.log('1: Nur User zeigen, bei denen der Chat im aktiven Browserfenster läuft');
}


function u_online() {
	if (chatIdle) { return; }
	
	time3 = ((+time1) + (lineCount * 100)) * 2;
	
	if (light != "yes") {
		// Aktualisierung pausieren, solange der Tastaturfokus in der Userliste liegt,
		// damit der Fokus beim innerHTML-Austausch nicht verloren geht.
		var uo   = document.getElementById('uo');
		var ubox = document.getElementById('user');
		var fokusInListe =
			(uo   && uo.contains(document.activeElement)) ||
			(ubox && ubox.contains(document.activeElement));
		
		if (!fokusInListe) {
			x_user_online(set_user);
		}
		
		if (show_active_users_only == 1) {
			if (!document.hidden ) {	
				setTimeout("u_online()", time3);
			}
		} else {
			setTimeout("u_online()", time3);	
		}
	}
}

function set_user_room(result1) {
	if (document.getElementById('user_pro_room')) document.getElementById('user_pro_room').innerHTML = result1;
}


// zeigt User in anderen Rooms:
function u_online_room() {
	if (chatIdle) { return; }

	time4 = ((+time1) + (lineCount * 100)) * 2;
	
	if (!document.hidden) {	
		if (!document.getElementById('user_pro_room').contains(document.activeElement)) {
			x_user_room(set_user_room);
		} 	
		setTimeout("u_online_room()", time4);
	} else {
		return;
	}
}


function ads(smiley) {
	document.getElementById('line').focus();
	document.getElementById('line').value = document.getElementById('line').value + ' ' + smiley + ' ';
}


function kalender () {
	if (localStorage) {
		var w = localStorage.getItem("pop3_width") || 650;
		var h = localStorage.getItem("pop3_height") || 320;
		var l = localStorage.getItem("pop3_left") || 10;
		var t = localStorage.getItem("pop3_top") || 30;
		window.open("kalender.php", "kalender", "top=" + t + ", left=" + l + ", width=" + w + ", height=" + h +"");
	} else {
		window.open("kalender.php", "kalender", " width=650, height=320");
	}
}	

function pinnwand1 () {
	if (localStorage) {
		var w = localStorage.getItem("pop1_width") || 520;
		var h = localStorage.getItem("pop1_height") || 700;
		var l = localStorage.getItem("pop1_left") || 10;
		var t = localStorage.getItem("pop1_top") || 30;
		window.open("pinns/pinnwand1.php", "pinnwand1", "top=" + t + ", left=" + l + ", width=" + w + ", height=" + h +"");
	} else {
		window.open("pinns/pinnwand1.php", "pinnwand1", " width=520, height=700");
	}
}	

function pinnwand2 () {		
	if (localStorage) {
		var w = localStorage.getItem("pop2_width") || 520;
		var h = localStorage.getItem("pop2_height") || 700;
		var l = localStorage.getItem("pop2_left") || 10;
		var t = localStorage.getItem("pop2_top") || 30;
		window.open("pinns/pinnwand2.php", "pinnwand2", "top=" + t + ", left=" + l + ", width=" + w + ", height=" + h +"");
	} else {
		window.open("pinns/pinnwand2.php", "pinnwand", " width=520, height=700");
	}
}	


// Sinnvolle Größe für die Box auch bei Zoom
var zL = window.devicePixelRatio || 1;
if (zL >= 2) {zL = zL / 2;} 
// console.log("Zoom Level: " + zL);


function smileybox(a) {
	var url = (a && a.getAttribute("href")) || "usr_smileys1.php";
	var isIOS = /iP(hone|ad|od)/.test(navigator.platform)
		|| (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

	if (isIOS) {
		// iOS holt eine wiederverwendete, benannte Hintergrund-Tab nicht nach vorne.
		// Daher jedes Mal eine frische _blank-Tab oeffnen (kommt im Vordergrund).
		window.open(url, "_blank");
		return false;			// unterdrueckt die zusaetzliche target="smileybox"-Navigation
	}

	var w = 340, h = 600, l = screen.width * .7, t = screen.height * .2;
	if (window.localStorage) {
		w = localStorage.getItem("box_width") * zL || 340;
		if (w < 325) { w = 325; }
		h = localStorage.getItem("box_height") || 600;
		if (h < (screen.height * .6)) { h = screen.height * .6; }
		l = localStorage.getItem("box_left") || screen.width * .7;
		t = localStorage.getItem("box_top") || screen.height * .2;
	}
	var win = window.open(url, "smileybox", "top=" + t + ", left=" + l + ", width=" + w + ", height=" + h);
	if (win) { win.focus(); }
	return false;
}

function prbox(e) {
	
	if (iOS !==true) { // do not use chat_pr on mobile, use skin7 instead
		e = e.replace("chat.php", "chat_pr.php");
	}
	
	if (localStorage) {
		var pw = localStorage.getItem("prbox_width") || 400;
		var ph = localStorage.getItem("prbox_height") || 650;
		var pl = localStorage.getItem("prbox_left") || screen.width * .7;
		var pt = localStorage.getItem("prbox_top") || screen.height * .2;
		window.open(e, "prbox", "top=" + pt + ", left=" + pl + ", width=" + pw + ", height=" + ph +"");
	} else {
		window.open(e, "prbox", " width=400, height=650");
	}
	
}


function load() {

	if (document.getElementById('jaws')) {
		//document.getElementById('jaws').setAttribute('aria-relevant', 'all');
		document.getElementById('jaws').setAttribute('aria-live', 'assertive');
	}
	var show_user;
	show_user = "<?php echo $show_user ?>";

	var show_rooms;
	show_rooms = "<?php echo $show_rooms ?>";

	var raum;
	if (window.location.search.indexOf("_pr") !== -1) raum = "pr";


	setTimeout("x_file_changed(set_file_changed)",500);

	// klapp('ae');


	var u_on_room = 1;
	if (sb == 1) u_on_room = 0;
	if (light == "yes") u_on_room = 0;
	if (show_rooms == "no") u_on_room = 0;
	if (raum == "pr" && show_rooms == "no" && isadmin != 1 ) u_on_room = 0;
	if (u_on_room == 1) u_online_room();

	// beim Betreten eig. Nick sofort anzeigen
	x_user_online(set_user);
	setTimeout("u_online()", 1000);

	// disabled den Zurück-Button von Android, aber erst, nachdem etwas geposted wurde
	history.pushState(null, null, window.top.location.pathname + window.top.location.search);
	window.addEventListener('popstate', (e) => {
		e.preventDefault();
		history.pushState(null, null, window.top.location.pathname + window.top.location.search);
	});


}


function ProfilOeffnen (Adresse) {
	var seconds = new Date().getTime() / 1000;
	MeinFenster = window.open(Adresse+"&test="+seconds, "Zweitfenster", "width=500,height=20,left=100,top=100");
	MeinFenster.focus();
}

function toggle_vid(e) {
	if (e.paused) {
		e.play();
	} else {
		e.pause();
		e.removeAttribute('playsinline');
	}
}


function fadeout() {
	document.body.style.backgroundColor = 'white';
	document.body.style.background = 'none';

	document.getElementsByTagName('body')[0].style.opacity = 0;
	document.getElementsByTagName('body')[0].style.WebkitTransition = 'opacity 500ms';
	document.getElementsByTagName('body')[0].style.Transition = 'opacity 500ms';
}


holeCookie("arrival");
if (cookieWert != "") {
	window.onload=load;
	  
} else {
	document.write('<p style="font-weight:bold; color:red"><br><br><?php echo _NOCOOKIE; ?><br></p>');
}

if (document.getElementById("topicscroll")) {
	var laufschrift = document.getElementById("topicscroll");
	len = laufschrift.innerHTML.length;
	room = document.getElementById("wrapper").clientWidth; 		
}


// clear input - on escape 
document.addEventListener('keydown', escape, true);
function escape(e) {
	if(document.getElementById("line") && document.getElementById("line").value.length > 0) {
		if (e.keyCode == 27 && !e.shiftKey && !e.ctrlKey && !e.altKey) {
			document.getElementById("line").value = '';
		}
	}
}

// Leertaste fuer den als role="button" ausgezeichneten Smiley-Link (Enter geht beim <a> nativ)
document.addEventListener('keydown', function(e) {
	if (e.key === ' ' && e.target.closest('a.more_smileys[role="button"]')) {
		e.preventDefault();		// verhindert das Scrollen beim Druecken
	}
});
document.addEventListener('keyup', function(e) {
	var el = e.target.closest('a.more_smileys[role="button"]');
	if (e.key === ' ' && el) {
		e.preventDefault();
		el.click();			// loest onclick="smileybox()" + href/target-Navigation aus
	}
});

// damit bei Raumwechsel eig. nick sofort in der Liste
document.addEventListener('visibilitychange', function (event) {
	if (chatIdle) { return; }
	if (!document.hidden) {
		setTimeout("u_online_room()", 100);
		setTimeout("u_online()", 200);
		setTimeout("x_file_changed(set_file_changed)",300);
	}
});

function dlcount(e) {
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.open("GET", "dlcounter/dlcounter.php?sendValue=" + e, true);
	xmlhttp.send();
}


	newWindow="";
	function OpenNewWindow(Picture,Breit,Hoch,Alttext) {
	xsize = Breit+1;
	ysize = Hoch+25;

	ScreenWidth = screen.width;
	ScreenHeight = screen.height;

	xpos = (ScreenWidth/2)-(xsize/2);
	ypos = (ScreenHeight/2)-((ysize+50)/2);

	if (!newWindow.closed && newWindow.location) {newWindow.close();}

	if (style == 4 || style == 5 || style == 15) {
		bgcol = '#000';
	} else if (style == 11 || style == 12 ) {
		bgcol = '#004';
	} else if (style == 61 ) {
		bgcol = '#fff4e7';
	} else {
		bgcol = '#fff';
	}

var supportsTouch = 'ontouchstart' in window || navigator.msMaxTouchPoints;

	if (supportsTouch === true) {
		OpenImageOverlay(Picture, Alttext);
		return false;
	}

	{


	html = ('<!DOCTYPE html><html onclick="self.close()"><head><title> '+Alttext+'</title><style>html, body, p, a {margin:0; padding:0; border: 0; font-family: Verdana,Geneva,Arial,sans-serif;} html { background:' + bgcol + ' url('+Picture+') no-repeat center center fixed;  -webkit-background-size: contain;-moz-background-size: contain;-o-background-size: cover; background-size: cover; cursor:zoom-out;max-width: 100%;} </style><script type="text/javascript">function kp(e){if (!e) e=window.event;if (e.keyCode==27){self.close();}}window.onkeypress=kp;</script></head><body onkeydown="kp()"><p style="position:fixed; bottom: 8px;right:16px"><a style="color:#444;text-decoration:none;	text-shadow:.6px  .6px .6px white,.6px -.6px .6px white,-.6px  .6px .6px white,-.6px -.6px .6px white;font-size:max(10vw, 2em); opacity:1" href="javascript:self.close()">X</a></p></body></html>');

}

	newWindow=window.open("","Picture","height="+ysize+",width="+xsize+", resizable=yes");

	newWindow.document.open("text/html", "replace")
	newWindow.document.write(html)
	newWindow.document.close()

	return false;
}

	// Touch/iOS: Bild als Overlay in der Seite zeigen, statt einen neuen Tab zu oeffnen.
	// Der neue Tab laedt das Bild in einem frischen Kontext neu -> auf iOS ~2s Verzoegerung.
	// Das Overlay nutzt das bereits geladene/dekodierte Bild und ist sofort da.
	function OpenImageOverlay(Picture, Alttext) {

		var old = document.getElementById('img_overlay');
		if (old) { old.remove(); }

		// Soft-Tastatur schliessen, die das inline focus() auf #line gerade ausgeloest hat
		var line = document.getElementById('line');
		if (line) { line.blur(); }

		var ov = document.createElement('div');
		ov.id = 'img_overlay';
		ov.setAttribute('role', 'dialog');
		ov.setAttribute('aria-modal', 'true');
		ov.setAttribute('aria-label', Alttext || 'Bild');
		ov.tabIndex = -1;
		ov.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.85);cursor:zoom-out;-webkit-tap-highlight-color:transparent;';

		var img = document.createElement('img');
		img.src = Picture;
		img.alt = Alttext || 'Grafik';
		img.style.cssText = 'max-width:100%;max-height:100%;object-fit:contain;';

		var btn = document.createElement('button');
		btn.type = 'button';
		btn.setAttribute('aria-label', 'Schliessen');
		btn.textContent = '\u00D7';
		btn.style.cssText = 'position:fixed;top:8px;right:16px;width:1.4em;height:1.4em;line-height:1;font-size:max(10vw,2em);color:#fff;background:none;border:0;cursor:pointer;text-shadow:0 0 4px #000;';

		function close() {
			document.removeEventListener('keydown', onKey);
			ov.remove();
		}

		function onKey(e) {
			if (e.key === 'Escape' || e.keyCode === 27) { close(); }
		}

		ov.addEventListener('click', close);
		btn.addEventListener('click', function (e) { e.stopPropagation(); close(); });
		document.addEventListener('keydown', onKey);

		ov.appendChild(img);
		ov.appendChild(btn);
		document.body.appendChild(ov);
		ov.focus();
	}
 
if ('ontouchstart' in window) {

	document.addEventListener('touchstart', function(e) {

		let el = e.target.closest('.tip');
		if (!el) return;

		let txt = el.getAttribute('title');
		if (!txt) return;

		let tip = document.createElement('div');
		tip.textContent = txt;
		tip.style = "position:fixed;background:#fff;color:#222;padding:4px 8px;border:1px solid; border-radius:6px;font-size:.8em;z-index:9999";

		document.body.appendChild(tip);

		let r = el.getBoundingClientRect();
		tip.style.left = (r.left + r.width/2 - tip.offsetWidth/2) + "px";
		tip.style.top  = (r.top - 28) + "px";

		setTimeout(()=>tip.remove(),1500);
	});
}