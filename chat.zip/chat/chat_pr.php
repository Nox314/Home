<?php
header('Content-type: text/html; charset=utf-8');

// http://mobiledetect.net/
if (file_exists("Mobile_Detect.php")) {	
	require_once "Mobile_Detect.php";
	$detect = new Mobile_Detect;
}

session_start();


if (phpversion() < '7.4.0') {
	echo "<p>Dieses Script erfordert PHP Version 7.4.0 oder h&ouml;her!<br />";
	echo "auf Deinem Server l&auml;uft aber PHP Version ".phpversion().".</p>";
	exit();
}

include("chat_config.php");
if (file_exists("personal_config_inc.php")) {include("personal_config_inc.php");}


if (file_exists("admin/admins.txt") && file_exists("admin/admin_add_admins.php")) {
	$admins2 = file("admin/admins.txt",FILE_IGNORE_NEW_LINES);
	$admins = array_merge($admins, $admins2); // und was, wenn kein $admins?
}


// Sprache abfragen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}


switch ($lang) {
        default: include("langDE_inc.php");
        break;
        case "de": include("langDE_inc.php");
        break;
        case "en": include("langEN_inc.php");
        break;
}


require("Sajax.php");
include("chat_inc.php");
// include_once("cleanup.php");

$mp3allow = "";   

$wo = trim(substr($room,6));

if (isset($_COOKIE["color"])) {
	$color = $_COOKIE["color"];
} else {
	$color = "";
}

if (isset($_COOKIE["Style"])) {
	$style = $_COOKIE["Style"];
} else {
	$style = "";
}




?>
<!DOCTYPE html>
<?php
switch ($lang) {
        default: echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">';
        break;
        case "de": echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">';
        break;
        case "en": echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">';
        break;
}
?>


<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" />
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" />
<meta name="generator" content="notepad ;-)" />
<meta name="robots" content="index, follow" /> 
<title>Du bist im Privatraum <?php echo htmlspecialchars($_GET['room']); ?></title>
<link rel="shortcut icon" href="/favicon.ico" />

<base target="_blank" /> 


<?php
$s = 1;
$hilfetexte = "off";
?>

<link rel="stylesheet" type="text/css" media="screen" href="chatcss7.php?<?php echo time(); ?>" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />

<script src="chat_js.php"></script>
   
<!-- overwrite this function    -->
<script>
	function u_online_room() {
		x_user_room(set_user_room);
		setTimeout("u_online_room()", 8000);
	}
</script>	   
   
<style>
	body, #user, #user p {font-size:.9rem !important;}
	p {line-height:1.25em;}
	#wrapper {height:unset !important;float:none;}
	.ip, #uo img {display:none;}
	fieldset.rooms {padding-bottom:0 !important;}
	#wall {
		overflow:scroll;
		height: 52vh !important;
		overflow-x: hidden !important;
		scroll-behavior: smooth;
		resize: vertical;
	}
	
	img {max-height:120px !important;}
	
	.more_smileys img {
	    border: 1px solid #eee;
	}
	#clickable {
		/*	border: 1px solid;*/
		width: 3em;
		height: 3em;
		top: -4em;
		margin: 0 0 -3em auto;
		position: relative;
		cursor: pointer;
	}
	
	#wall::-webkit-scrollbar, #user_pro_room::-webkit-scrollbar, #user::-webkit-scrollbar {
		-webkit-appearance: none;
		width: 8px;height:8px;
	  }
	#wall::-webkit-scrollbar-thumb, #user_pro_room::-webkit-scrollbar-thumb {
		border-radius: 6px;
		background-color: rgba(0, 0, 0, .3);
	}

	#wall::-webkit-scrollbar-corner, #user_pro_room::-webkit-scrollbar-corner, #user::-webkit-scrollbar-corner {
		background-color:transparent;
	}
	#wall::-webkit-resizer {
	background-color: rgba(0,0,0, .3);
	border-radius:1em;
	}
	
	html {
		background:#ddd; 	/* hier die Hintergrundfarbe fuer die Seite */
		background: url(img/wa4.png) repeat; /* https://papers.co/android/va28-pop-art-cultures-pattern/ */
	}
	
	body:after {
		background: none;	
	}
	div#uo span {
	    margin-right: 5px;
	}
	#addsmileys ul li a {
	    font-size: 20px;
	    text-decoration: none;
	    cursor: pointer;
	}
	.av {margin:2px 10px 2px -2px;}
	
	#uo li span {
	    display: none;
	}
		
</style>	   
   
<?php
echo '<style>';

################# Datum im Chatfenster ###################
if (isset($_COOKIE["dc"]) && $_COOKIE["dc"] == 0 )  { 
	echo "\n".".dt, .datum {display:none}";
}

################# Uhrzeit im Chatfenster ###################
if (isset($_COOKIE["uhr"]) && $_COOKIE["uhr"] == 0 )  { 
	echo "\n".".uz, .uhrzeit {display:none} .dt {right:7px;}";
}

################# Bilder ###################

if (isset($_COOKIE["pic"]) && $_COOKIE["pic"] == 0 )  { 
	echo "\n"."#wall img:not(.av), #addsmileys, #wall .pop {display:none}";
}


echo '</style>';
?>	
   

<script src="popbild.js"></script>

</head>
<body>
	
<!-- ########## oberhalb dieser Zeile nur aendern, wenn Du weisst, was Du tust! ######## -->
<!-- ######## hier kannst Du eigene Inhalte einfuegen, z.B. eine Kopfzeile, Navigation o.ae. ###### -->


<!-- ######## die naechsten Abschnitte nicht aendern! ######## -->
<!-- <h1><?php echo $titel ?></h1> -->

<?php

$NCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQNCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQ="ZWNobyAnPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiPic7DWVjaG8gJy8qIDwhW0NEQVRBWyAqLyc7DXNhamF4X3Nob3dfamF2YXNjcmlwdCgpOw1lY2hvICcvKiBdXT4gKi8nOw1lY2hvICc8L3NjcmlwdD4nOw1pZiAoaXNzZXQoJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10pICYmIGlzc2V0KCRwd2QpKSB7DQkkc2VydmVyID0gc3RyX3JlcGxhY2UgKCJ3d3cuIiwiIiwgJF9TRVJWRVJbJ1NFUlZFUl9OQU1FJ10gKTsNCSRzZXJ2ZXIgPSBzdHJfcmVwbGFjZSAoIisiLCIiLCAkc2VydmVyKTsNCSRzZXJ2ZXIgPSBzdHJfcmVwbGFjZSAoIi0iLCIiLCAkc2VydmVyKTsNCSRjaGF2ZSA9ICRwd2QgLyBhYnMoY3JjMzIoJHNlcnZlcikpOw19DWlmIChpc3NldCgkdmVyc2lvbikpIHsNCSR2ZXJzID0gIjxzcGFuIHN0eWxlPVwiZGlzcGxheTpub25lXCI+PGFiYnIgdGl0bGU9XCJWZXJzaW9uXCI+dmVycy48L2FiYnI+ICR2ZXJzaW9uPC9zcGFuPiI7DX0gZWxzZSB7DQkkdmVycyA9IiI7DX0NDWlmICghaXNzZXQoJGNoYXZlKSB8fCAkY2hhdmUgPD4gIjEyNCIpIHsNCWVjaG8gJzxwIHN0eWxlPSJmb250LXNpemU6MTFweDsgY29sb3I6ICMzNDM7IGJhY2tncm91bmQ6ICNmZmY7IG1pbi13aWR0aDogMTYwcHggIj4gc2NyaXB0IGJ5IDxhIHN0eWxlPSJmb250LXNpemU6MTFweDsgY29sb3I6ICMzNDM7IGJhY2tncm91bmQ6ICNmZmY7IHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lOyIgaHJlZj0iaHR0cDovL3dlYmRlc2lnbi53ZWlzc2hhcnQuZGUvY2hhdC5waHAiPndlYmRlc2lnbiB3ZWlzc2hhcnQ8L2E+IGtvc3RlbmxvcyBmJnV1bWw7ciBuaWNodCBrb21tZXJ6aWVsbGUgU2VpdGVuLicuJHZlcnMuJzwvcD4nOw19IGVsc2Ugew0JZWNobyAnPHAgc3R5bGU9ImZvbnQtc2l6ZToxMXB4Ij4nLiR2ZXJzLic8L3A+JzsNfQ0=";eval(base64_decode($NCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQNCiR0aW1lX29sZCA9IDA7IC8vIGb8ciBkaWUgRm9ydHNjaHJpdHRzYW56ZWlnZQ));?>


<fieldset id="wrapper">


<div id ="talk">

<div id="wall"></div>
<div id ="clickable" onclick="scroll_click()"></div>


<?php
if(isset($nickname)) {

	echo '
	<form  accept-charset="utf-8" id="f" method="post" action="#" onsubmit="add(); return false;" >

	<p>
	<label class="dot" for="line">'._MESSAGE.':</label>
	<input type="text" name="line" id="line"  size="67" maxlength='.$max_length.' title="'._MESSAGE.'" placeholder="'._MESSAGE.'" autofocus autocomplete="off"/>
	<button class="button" type="submit" title="Senden" onclick="closepopup()" > ✔︎</button>
	<button class="button" id="reload_btn" title="reload" style="font-size: 19px; padding: 0px 6px 5px 7px !important" onclick="window.location.href = window.location.href;">&#x21bb;</button>
	
	</form>
	';

    echo '<input type="hidden" name="handle" id="handle" value="'.$nickname.'" />';

} else {
 // Paranoia - damit popbild.js tut ein input
// echo '
// <span style = "color:red">Nur im <a href="login.php">Hauptchat</a> angemeldete User d&uuml;rfen hier schreiben!</span>
// <input type="hidden" id="line" />
// ';
}

?>



<?php
// if(!isset($nickname)) {
// echo '<!--';
// }
?>

<div id ="addsmileys">

<?php if ($smileys != "on") echo "<!--"; ?>
<h2 class="dot"><?php echo _SMIL; ?>:</h2>


<ul>

<?php
if (isset($emojis)) {
	$count_emojis = count($emojis);
	for ($i = 0; $i < $count_emojis; $i++) {
		echo '	<li><a onclick="ads(\''.$emojis[$i].'\'); return false; "> '.$emojis[$i].' </a></li> ';
	}
}
?>



<?php
if (is_dir("smileys1") && file_exists("usr_smileys1.php")) {

		echo '
			<li class="more_smileys"><a style="text-decoration:none;" href="usr_smileys1.php" target="smileybox" title ="More Smileys" onClick="smileybox()"><img  src="img/more.gif" title="more smileys (popup)" alt="more smileys" width="60" height="18" ><span class="dot"> popup!</span></a></li>
			';
	
}


?>

</ul>

<?php if ($smileys != "on") echo "-->"; ?>

</div>
</div>

<?php
// if(!isset($nickname)) {
// echo '-->';
// }
?>



</div>


</fieldset>


<script src="micoxUpload2.js" defer></script>

<script>

  function end_upload2(data){
			document.getElementById('upload_2').innerHTML =  data;
  }
  function clear_upload2(){
			document.getElementById('upload_2').innerHTML =  '';
  }
    
</script>


<?php
$img = true;

if (strpos($wo,"_pr") !== false && $imginclude_pr != "yes") $img = false;

if ($mp3allow == "alle" || ($mp3allow=="clean" && (strpos($wo,"_pr") !== false || $blankrooms == "yes" || in_array($wo,$blankroom) || $admintrue !== false)) || ($mp3allow=="admins" && $admintrue !== false)) {
	$mp3upallow=1;
} else {
	$mp3upallow=0;
}; // fuer die Uebergabe an micoxUpload2 ist diese Umwandlung erforderlich


if (@$vidallow == "alle" || (@$vidallow=="clean" && (strpos($wo,"_pr") !== false || $blankrooms == "yes" || in_array($wo,$blankroom) || $admintrue !== false)) || ($vidallow=="admins" && $admintrue !== false)) {
	$vidallow=1;
} else {
	$vidallow=0;
}; // fuer die Uebergabe an micoxUpload2 ist diese Umwandlung erforderlich


// if (phpversion() > '5.6.39' && $gd === true) {
// if (($img == true && isset($imginclude) && $imginclude=="yes" && $wo != "Info" && $wo != "Buglist"   && !file_exists("rooms/Offline")) || $admintrue !== false) {
if ($in_regdb === true || !file_exists('no_upload.php')) {
	
echo '
<fieldset style="float:left;" id="upload">
<legend style="font-size: .8em;">&nbsp;'._UPLOADLEGEND.'&nbsp;</legend>
  <form action="upa.php?rm='.$wo.'" >
    <div>
       <label class="dot" for="file">'._UPLOADLABEL.':&nbsp;</label> 
       <input type="file" style="color:transparent;" id="file" name="file" onchange="micoxUpload2(this.form,0,\'Loading \',end_upload2,'.$maxsize.','.$mp3upallow.','.$vidallow.')"/>    </div>
    <div id="upload_2"></div>
  </form>
';


echo '</fieldset>';
}
// }
// }

?>







<fieldset class="rooms">
	
<form method="post"  onsubmit="return room_name()">

<div id="user">

<?php
$file3 = "rooms/$wo";
if (strpos($wo,"_pr") !== false) {
	// echo "<p>"._PR." <span style = \"font-weight:bold; color:#f00\">$wo</span></p>";
	if ($anz_rooms != 1) echo '<div id="uo"> </div>';
} 
?>
</div>
</form>
</fieldset>





<script>
	var timeOutFunctionId;
	function workAfterResizeIsDone() {
		var pw = window.innerWidth;
		var ph = window.innerHeight;
		var pl = window.screenLeft;
		var pt = window.screenTop;
		
		localStorage.setItem("prbox_width", pw);		
		localStorage.setItem("prbox_height", ph);		
		localStorage.setItem("prbox_left", pl);		
		localStorage.setItem("prbox_top", pt);							
					
	}
	window.addEventListener("resize", function() {
		clearTimeout(timeOutFunctionId);			
		timeOutFunctionId = setTimeout(workAfterResizeIsDone, 500);
	});
	
	window.addEventListener("blur", function() {
		clearTimeout(timeOutFunctionId);
		timeOutFunctionId = setTimeout(workAfterResizeIsDone, 500);
	});
	
	
</script>	

<noscript>
	<p><?php echo _NOJS; ?>.</p>
</noscript>

</body>
</html>
