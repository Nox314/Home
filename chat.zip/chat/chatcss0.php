<?php
ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, .rooms, input, select {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #343;
}

html {overflow: hidden;padding:3px;}

body {
	font-size:85.01%;

	background: transparent;
}

p, ul li {margin-bottom: 2px;}

ul { margin-left:1.3em}

li {line-height:1em;}

a {color: blue;}
a:link, a:visited {}
a:focus, a:hover {background:#eee;}

object,
img {max-width: 100%;  height:auto;
}

fieldset {

	margin:0;
	padding:0;
	border:0;
}

object {margin: 5px;}

video {max-width:100%}
#addsmileys ul {margin: 15px 0 8px 1px;}
#addsmileys ul li {display:inline !important;}

h1, h2,h3,#opt, .rooms p, dtn, .dot, #user_pro_room, #f p span, .ip,
.dt, .uz, .tr, .stop, dfn, .av
{display:none;}

.mp3 {text-decoration:none; color: #bbb;}
.mp3:hover {background:transparent;cursor:default;}
.mp3:after {text-decoration:none; color:red; content:" ... mp3 Player leider nur im Hauptchat :-("}

img, video {max-height:150px}

#wall {
	height: calc(100vh - 15em);
	width: 99%;
	background:#fff;
	overflow: auto;
	overflow-x:hidden;
	margin: 0;
}

#line {width:85%;padding: 6px 5px;float:left !important;}
#file {border:0}

#wall p {
	padding:  .2em; line-height:1.4em;
	border-bottom:1px dashed #ccc;
}

.hello {font-size: 1em; color: #888;}

input{
	background:#fff;
	font-size: 100%;
	margin: 2px 0 0 0;
	border:1px solid #aaa;
	cursor:pointer;
}

button[type=submit] {
	border: none;
	background: transparent;
	cursor: pointer;
	font-size: 1.5em;
	opacity: .5;

}

a.pop img {cursor:zoom-in !important;}
.rooms {margin-top:3em;display:block;}
.rooms img {display:none;}
#user ul li {display:inline;}
