<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");

setcookie('bf_linear','1',time()+3600*24 ); // Cookie, um Skin an css12 zu melden wg. SR div Jaws

?>

html,body,div,p,h1,h2,h3,h4,h5,ul,ol, span, form, li, fieldset, input {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #06AEFF;

}

img {
	border:0;
	margin:0;
	padding:0;
}

html {
	padding: 10px 10px 0 10px;

}

body {
	background:#000;
}

html, body {height:100%}

h1 {
	font-size:.9em;
	letter-spacing: 1px;
	color: #ff8;
	margin-bottom: 4px !important;
	max-width: 100% !important;
	white-space:pre;
}
h1 span {color:#06AEFF}

h2 {
	font-size:.8em;
	line-height:125%;
	color:#ff8;
}

.rooms h2 {margin:0 !important;}

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}

p, ol li, #uo, #user p, #help tr, #upload input  {
	font-size:.8em;
	margin-bottom: .1em;
}

fieldset fieldset a {text-decoration:none;}

a {color:#fff}
a:link, a:visited {}
a:focus, a:hover {background:#00f;}

:focus {
	outline: 2px solid #ff8;
}

.away,
#addsmileys a:visited span{display:none !important}
#addsmileys a:hover {background:none}

#user_pro_room li {
	display:inline;
	border:1px solid #ff8;
	padding: 5px !important;
}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
}

#user_pro_room em:after {

	content:" \2713";
	font-weight:bold;
}

#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}

ul {
	font-size:.8em;
	list-style-type: none;
}

li {
	margin: 0 1em 0 0;
}

hr, #kalender {
	display:none;
}

fieldset {
	clear: right;
	margin:0 0 3px 0;
	padding: 3px;
	width: 99% !important;
}

#wrapper {
	padding-top: 8px;
	border:1px solid #888;
}

#wrapper:after, #opt:after { /* der Konq braucht das 1., der Op das 2. */
	content : ".";
	display : block;
	height : 0;
	clear : both;
	visibility : hidden;
}

.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .7em;
	color: #aaa;
}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

#talk {

	margin: 0 3px 3px 0;
	width: 100% !important;
	padding: .3em 0 1em 0;

}

#wall {
	height:35vh;

	overflow-y: scroll;

	max-width: 100% !important;
	background:#000;

	margin: -1em .2em -.7em 0;
	padding: .3em;
	line-height: 1em;
	max-width: 25em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;

}

#wall::-webkit-scrollbar {
	-webkit-appearance: none;
	width: 16px;
	height:16px;
}
#wall::-webkit-scrollbar-thumb {
	border-radius: 14px;
	background-color: rgba(255, 255, 100, .8);
}

#wall::-webkit-scrollbar-corner, #user_pro_room::-webkit-scrollbar-corner, #user::-webkit-scrollbar-corner {
	background-color:#cccc62;
}

#wall p {

	padding:  0 .5em 0 .8em;
	text-indent: -.8em;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#wall .whisper,#wall .at {color:#000 !important; background: #dd0 !important; font-weight:700}

#line {
	width: 80% !important;
	min-width:80% !important;
	max-width: 80% !important;
}
input#line {position:relative; top: -4px;}

#reload_btn {display:none;}

#ton {
	width: 0;
	height: 0;
}

#uo {

	margin-top: .3em;
}

#uo ul li {
	display: inline-block;
	font-size:120%;
	padding: 0 .2em;
	line-height:2em;
	background: #333;
	margin:0 .5em .5em 0;
	border:1px solid;
}
#uo ul li img {height:1em;max-height:1em !important;}
#uo span {float:left;margin: 0 1em .5em 0}
#uo br {display:none;}

#uo ul, #user_pro_room ul, #opt form p {
	padding: .2em 0 .25em 0;
}

.us_ip {
	font-size: .8em !important;
	margin: .4em 4px 0 0 !important;
}

#reload_time {display:none}

#user_pro_room ul li {
	padding:0;
	line-height:1.3em;
	display:inline-block;
	margin-bottom:.5em;
}

#addsmileys {
	float:left;
	margin: 5px 0 0 15px;
}

dfn, .dot, #upload {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}

#f {margin-left:10px;}

#opt input[type=submit] {margin-top:3px}

#talk input, .rooms input {
	color:#fff;
	background:#333;
	border:1px solid #888;
}

input.button {
	cursor:pointer;
}

#datum, #uhr, #sound, #nickfarben {
	border: 0;
	background: transparent;
}

#line, #handle, #room {
	border: 1px solid #888;
	padding: 2px 0 2px 3px;
	color:#fff;
	background:#000;
	cursor:text;
}

label, select {
	cursor:pointer;
}
label {margin:0 3px}

#m#menu1 {float: left;}
#einaus_ae {display:none !important;}
#ae {position:static !important;height:30px !important;}
select {
	font-size:1.2em !important;
	width: 11em;
	padding: 0 !important;
	border: 2px outset;
}

.uolist {display:none;}
#upload {padding:3px 0 0 9px; margin-top: 10px;}

#logout, .logout {
	text-align:center;
	margin:4px 18px 4px 0;
	border: 2px outset #eee;
	background-color: #000;
	width: 13em;
}
#logout a, .logout a {
	display:block;
	text-decoration:none;
	padding:0 0 2px 0;
}

.button {padding: .23em; margin-left:3px;min-height:1.7em !important;}

#wrapper,
#wall
{background: #004 !important}

#wrapper p,
#wrapper p span,
legend,
#uo li,
#uo span,
#uo a,
#user_pro_room a
{color: #ff8 !important; line-height:1.5em;}

#wall p, #wall p span
{line-height: 1.8em !important;}

#uo,
#user_pro_room em,
#f p span {color:#f60 !important}

legend {padding:0}

h2 {font-size: .9em; margin-bottom: .3em;}
h2, h2 span {color: #ddd !important}

p span span,
#wall p span span span,
#wall p span span
{color: #ff8 !important; background: #00f !important;height: 2em;}

#form {display:none}

#file {
	background: transparent !important;
	border:2px solid transparent !important;
}

fieldset #upload {
	margin-left: 10px;
	padding: 5px;
	border: 1px solid #888;
}
.helplinks p, .helplinks p a {background: black; color:white;}
.helplinks p a:focus,
.helplinks p a:hover,
.helplinks p a:active
{background: #00a; text-decoration:none;}

#wall p span span {background-color: transparent !important}

select {
	color:white;
	background:black;
}

.helplinks p a{margin-bottom:1em;}

.rooms {
	padding: 0 0 0 7px;

	border-top: 4px solid #ff8;
}

#uo, #user_pro_room {
	height: auto;
}

#f p span,
#addsmileys
{display:none}

#line, #menu2, #room, .button, #handle {
	font-size: 100%;
}
#line {padding:.23em .5em}

#mp3 {
	margin: .5em;
}

a.mp3 {
	text-decoration: none;
	padding-left: 20px;
	background-image:url(img/audio_neg.gif);
	background-repeat:no-repeat;
	background-position: 0 50% ;
}

#wall img, #wall video {
	max-height: 120px !important;
	width: auto;
	max-width: 100%;
}

#upload, #upload2,.opt {display:none !important}
.opt3 {margin-bottom: 1em}
#addsmileys, marquee {display:none}

#topic, #topic_wdw {
	margin:0 0 15px 12px;
	font-weight:bold;
	font-size:.8em;
	line-height: 1.4em;
	color:#ddd !important;
}

.sizer h3 {display:inline-block; color:#eee !important;}
.sizer a, .sizer span {margin-left:.3em;}
.sizer span {color: #555 !important;}

textarea{
	font-size:<?php echo $font_size; ?> !important;
	background:black;
	color:#ffff88 !important;
	max-width: 475px;
}

.av {display:none;}

#wunschbox {
	position:relative;
	top:150px;
	margin:-115px 5px 0 0 ;
}

iframe {
	margin: 10px -8px 0 !important;
}
