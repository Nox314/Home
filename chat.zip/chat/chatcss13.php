<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
if (!isset($user_hoehe)) $user_hoehe = 14;
?>

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, input, select {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;

}

body {
	width: 95%; max-width: 70em;min-width:41em;
	margin: auto;
	padding-top:.5em;
}

html, #file {
	background:#ddd;
	background: url(img/wa4.png) repeat;

}

fieldset, #wall {border:0 !important;}

fieldset .rooms {margin-bottom:3em !important;max-width:15em;}

h1 {
	font-size:1.3em;
	line-height:125%;
	font-variant:small-caps;
	color:#747474;
}

h2 {
	font-size:.8em;
	line-height:125%;
	margin: 1em 0 .3em 0;
}

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
	color:#747474;
}

p, ol li, #user, #help tr, legend, select {
	font-size:.8em;
}

video {vertical-align:top}

#wall p .marquee {

	display:inline-block;
}

#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}
#toggle_smileys {top:-4px !important;}

#mixed_content a {	color:#747474;font-size:80%}

#reload_btn, button[type=submit] {
	border: none;
	color:#888;
	background: transparent;
	cursor: pointer;
	font-size: 2em;
	vertical-align:top;
}

ul {
	font-size:.8em;
	list-style-type: none;
}

li {
	margin: 0 1em 0 0;
}

fieldset {
	clear: right;

	margin:0 0 0 0;
	border:none;
	padding: 2px 2px 0 2px;
}

fieldset fieldset {

	padding: 2px 4px 4px 3px;
	margin-bottom: 3px;
}

.dt, .uz {
	font-size:.7em;
	line-height:1;
	color:#888;
	display:contents;
}

.dt {
	right: 5.5em;
	padding-right: .7em;
}

.tr {
	display:none;
}

.av_link a {text-decoration:none;}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

.emoji {margin-bottom:3px;}

#talk {
	width: calc(100% - 16em) !important;
}

#wall {
	resize:vertical;
	overflow-y: scroll;
	margin: 0 15px 15px 0;
	padding: .7em .3em 0 .7em;
	line-height: 1.1em;

	word-wrap:break-word;
	max-width:70vw;

}

.av {
	margin: 2px 5px 2px -2px;
	border:1px solid #888;
	border-radius:3em;

	width:32px !important;
	height:32px !important;

	object-fit: cover;
	float:left;
	background:#fff;
}

#wall p {
	position: relative;
	background: #fff;
	color: #333 !important;
	border: 1px solid #aaa;
	border-radius: 0 .7em .7em .7em;
	padding: 3px 5px 3px 8px;
	margin: 6px 0;
	margin-left: .3em;
	max-width: calc(100% - 3.5em);
	line-height: 1.3em;
	clear: left;
	display: table;
}
/* äußeres Dreieck = Rahmen (links) */
#wall p::before {
	content: '';
	position: absolute;
	width: 0;
	height: 0;
	top: -1px;
	right: calc(100% + 1px);
	border: 5px solid;
	border-color: #aaa #aaa transparent transparent;
}
/* inneres Dreieck = Füllung, überdeckt den Rahmen der Blase */
#wall p::after {
	content: '';
	position: absolute;
	width: 0;
	height: 0;
	top: 0;
	right: 100%;
	border: 4.5px solid;
	border-color: #fff #fff transparent transparent;
}
#wall p.bg, #wall p.bm {
	background: #eee;
	border-radius: 1.7em 0 .7em 1.7em;
	margin-left: 0;
	/* padding: 3px 6px 2px 9px; */
	max-width: calc(100% - 8em);
}
/* #wall .bg .av, #wall .bm .av {margin-left: -4px;margin-top:2px;} */
#wall span img, #wall span video {margin-bottom:2px}


<?php
	if (isset($_COOKIE["avt"]) && $_COOKIE["avt"] == 0)  {
		echo "#wall p.bg {padding:5px 6px 5px 10px}";
	}
?>
/* äußeres Dreieck = Rahmen (rechts) */
#wall p.bg::before, #wall p.bm::before {
	top: -1px;
	right: auto;
	left: calc(100% + 1px);
	border-color: #aaa transparent transparent #aaa;
}
/* innere Dreiecke = Füllung */
#wall p.bg::after {
	content: '';
	position: absolute;
	width: 0;
	height: 0;
	top: 0;
	right: auto;
	left: 100%;
	border: 4.5px solid;
	border-color: #eee transparent transparent #eee;
}
#wall p.bm::after {
	content: '';
	position: absolute;
	width: 0;
	height: 0;
	top: 0;
	right: auto;
	left: 100%;
	border: 4.5px solid;
	border-color: #fff transparent transparent #fff;
}
#wall p.bm {
	background: #ffffff;
}
canvas {vertical-align:text-top;border-radius:4px;}

#wall img {
	vertical-align:text-top;

}

#wall  img:not(.av) {
	border-radius:4px;
}

#wall .pop::after {
	bottom: -7px;
	right: 2px;
}

.ip {display:inline-block;}

#wall p.bg span:not(.ytb) {
	color: #333 !important;
}

#wall .nick, #wall .nk {
	font-weight:900;
	margin: 0 3px 0 0;
}

#wall .whisper, #wall .at {color:red; background: yellow}

#wall::-webkit-scrollbar, #user_pro_room::-webkit-scrollbar, #user::-webkit-scrollbar {
	-webkit-appearance: none;
	width: 8px;height:8px;
}
#wall::-webkit-scrollbar-thumb, #user_pro_room::-webkit-scrollbar-thumb {
	border-radius: 6px;
	background-color: rgba(255, 255, 255, .7);
}
#user::-webkit-scrollbar-thumb {
	border-radius: 6px;
	background-color: rgba(255, 255, 255, .7);
}

#wall::-webkit-scrollbar-corner, #user_pro_room::-webkit-scrollbar-corner, #user::-webkit-scrollbar-corner {
	background-color:transparent;
}

#wall::-webkit-resizer, #user::-webkit-resizer {
	background-color: rgba(255, 255, 255, .7);
	border-radius:1em;
}

#line {
	width: 45em;
	max-width: 78%;
	max-width: min(82%, 60vw);
	margin-left:0;
	border: 1px solid #aaa;
	border-radius:.2em;
	padding: 3px 7px !important;
	font-size:1em;
}
input#line {position:relative; top: -7px;}
input[type=text] {height:20px}
textarea {height:35px}

#op {margin:3px 0}

#ton {
	width: 0;
	height: 0;
}
#user{
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "min-height: calc(60vh - 20em) !important; max-height: calc(100vh - 25em) !important;";
	} else {
		echo "line-height: 2em;";
	}
	?>
	overflow-y:scroll !important;
	max-width:unset !important;
	padding:2px 0;
}

#user ul { min-height:unset !important; display:block;}

#user ul, #user ul li {
	display: inline;
	<?php
	if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	}
	?>
	font-size:100%;
	margin: 0;
	padding:0 .1em;
}
#user ul, #user_pro_room ul {
	padding: .3em 0 .25em .2em;
	margin-top: .3em;
	line-height:1.35em;

}

#user_pro_room{
	/*	display:block;
	min-height:<?php echo $anz_rooms; ?>em;
	overflow-y:auto; overflow-x:hidden;
	max-height:7.45em */
}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
	border:1px solid #aaa;
	border-radius:1em;
	background: #eee;
	padding:4px 8px;

}

#user_pro_room em:after {
	content:" \2713";
	font-weight:bold;
}

#user_pro_room ul li {
	list-style-type:none;
	display:inline-block;
	margin: 12px 0 0 0;
}

#user_pro_room ul li a:hover, #user_pro_room ul li a:focus {
	background: #fff;
}

#user_pro_room a {
	text-decoration:none;
	color:#222;
	border:1px solid #aaa;
	border-radius:1em;
	background: #eee;
	padding:3px 8px 4px;
}

#user_pro_room a:has(span) {
	padding:3px 8px 4px 8px;
}

#user a {text-decoration:none; color:#222}

#user ul li {color:#444}

#addsmileys {
	float:left;
	margin: 0 !important;
}
object {margin: 5px;}

dfn, .dot, #sr {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}

.bg {background:none;}

label,
select,
input {
	cursor: pointer;
}

.button {padding:3px; top:-7px}

.away {
	border-radius: 1em;
	padding:2px 8px;
	background-color: #747474;
	color: #fff;
}

label {margin:0 3px}

#line, #handle, #room {
	background:#fff;
	cursor:text;
}
#line {
	border: 2px solid transparent;
}

#line:focus, #line:hover {
	outline:none;
	border: 2px solid #aaa;
	border-radius:3px;
}

#menu1, #menu2 {width:70%}

select {font-size: 100%}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
   echo '#menu2 {width: 100%}';
   echo '* html #menu3 {width:96%}';
}
?>

<?php
if ($stil != 0) {
   echo '#menu1 {width: 100%}';
   echo '* html #menu1 {width:96%}';
}
?>

#opt2 {clear:left; padding-top: 5px}
.opt {
	display:block;
	margin: 0 0 2px 0;
	padding: 0;
}
.uolist {display:none;}

fieldset #upload #file{
	border:0 none !important;
	margin-left:8em;
}

#upload {
	clear:left;
	min-height:4em !important;
}

#wrapper fieldset legend {
	font-size: .8em;
	margin-bottom: -2em;
	line-height: 2em;
	padding:0;
}

#mp3 {clear:unset !important}
#addsmileys {margin-right: 1em !important;}

#mp3 audio {
	margin-top: 0;
	margin-left: 0;
	width: 15em;
	max-height:20px;
}
@-moz-document url-prefix() {
	audio {filter: invert(1);}
	#mp3 audio {max-height:30px;margin-top:0;}
}

audio {
	border: 1px solid #ccc;
	border-radius: 40px;
}

_::-webkit-full-page-media, _:future, :root audio { /*Safari*/
	border: 0;
}

@-moz-document url-prefix() { /* Firefox */
	audio {
		border-radius: unset;
		border: 2px solid #333; /* weil inverted */
		filter: invert(1);
	}
	#mp3 audio {max-height:30px;margin-top:0;}
}

#upload_2 {margin: 0 6px ;}
#addsmileys ul li a:visited span {color:#ddd}

#wdw_logo {filter: invert(.4);max-width:15em !important}

#logout, .logout, #einaus_ae {
	text-align:center;
	margin:7px 0;
	padding:5px 8px;
	border: 1px solid #ccc;
	border-radius:1em;
	background-color: #f1f3f4;
	cursor:pointer;
	display:block;
}
#logout:focus, #logout:hover, .logout:focus, .logout:hover, #einaus_ae:hover, #einaus_ae:focus {
	background-color:#fff
}

#logout a, .logout a {text-decoration:none; color:#555 !important}

.helplinks p {color:transparent!important}

.helplinks p a:not(.flag) {
	border: 1px solid;
	border-radius:3px;
	padding: 2px 4px;
	background:#fff;

}
.helplinks a {color:#747474;text-decoration:none}
.helplinks a span.dot {display:none}

input, select {
	border: 1px dotted #666;
	padding: 2px;
	background:#fff;
}
input {
	margin-right: 2px;
}

a.mp3 {
	text-decoration: none;
	padding-left: 20px;
	background-image:url(img/audio.gif) !important;
	background-repeat:no-repeat !important;
	background-position: 0 50% !important;
}

.hello {color: red !important; font-size: 80%; font-style:italic;font-weight:700;}

a.stop {
	color:#fff;
	background: #747474 !important;
	text-decoration:none;
	font-size: 80%;
	padding: 3px 6px;
	border-radius: 1em;
}
#ae {margin-bottom:.5em;}
#einaus_ae {color:#555;min-height:17px}

#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
	border: 0;
	background: transparent;
}

#r_player ul, #player ul {background: #fff;}
#r_player a, #player a {color: #222;}

#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 0 auto;}

#topic, #topic_wdw {
	color: #747474;
}

#nickname {
	display: inline-block;
	color: red;
	margin: .5em 0 1em 0;
}

.uhr {font-size:.7rem;color:#747474;margin-left:1em}

.more_smileys span {display:none}

.more_smileys img {
	border: 1px solid #eee;
	border-radius: 2em;
	height: 20px;
	vertical-align: -2px;
}

input::-webkit-file-upload-button {
	border-radius: 1em;
	border: 1px solid #555;
	padding: 2px 8px;
}

.yta {color:black;font-weight:bold; font-family:Arial narrow; font-size: 1.2em;}
.ytb {font-family:Arial narrow; background:red;color:white !important;font-weight:bold;font-size: 1.1em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;margin-right:5px;}

#webradio {text-align:center;max-width:100%}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;border-radius:5px;}
input[type="image"]:hover, input[type="image"]:focus { background: #fff}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
#audio-controls {
	margin-top: -36px;
	padding-top: 10px;
	border-radius: 10px;
	background: #f1f3f4;
	border:1px solid #ccc;
}

.pin {
	background: #eee !important;
	border:1px solid #888;
	border-radius: 7px !important;
	margin-left: -.7em !important;
	top:-11px !important;
}
.pin::before {display:none;}
