<?php
	
header("Location: chatcss4.php");
die();	
	
?>
