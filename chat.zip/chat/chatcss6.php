<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li, fieldset, input {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
	color: #795548;
}

body {
	padding-top: .5em;
	width: 90%;
	margin: auto;

	background:#fff;

	background: url(img/pink2_bg.jpg) no-repeat center center fixed;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	background-size: cover;

}

h1 {
	font-size:1.2em;
	color:#f44336;
	line-height:125%;
}
h1 span {color:#f44336}

h2 {
	font-size: .9em;
	line-height:125%;
}
.rooms h2 {margin-top:1em;}

h3, h4, h5 {
	font-size:.8em;
	margin-top: 1em;
	line-height:125%;
}

p, ol li, #uo, #help tr, #upload input  {
	font-size:.8em;
	margin-bottom: .1em;
}

fieldset fieldset a {text-decoration:none;}

a {color:#c00}

#addsmileys a:hover {background:none}

#user_pro_room em {
	font-weight: bold;
	font-style: normal;
	color: red;
}

#user_pro_room em:after {
	content:"\00A0\2713";
	font-weight:bold;
}

#addsmileys ul li, #farben ul li {
	display:inline;
	margin:0;
}

ul {
	font-size:.8em;
	list-style-type: none;
}

li {
	margin: 0 1em 0 0;
}

hr {
	display:none;
}

fieldset {
	clear: right;
	margin:0 0 3px 0;
	padding: 3px;
	min-width: 8em;
}

#wrapper {

}

#wrapper:after, #opt:after { /* der Konq braucht das 1., der Op das 2. */
	content : ".";
	display : block;
	height : 0;
	clear : both;
	visibility : hidden;
}

.datum, .uhrzeit, .dt, .uz, .tr {
	font-size: .8em;
	color: #aaa;
}

.tr {visibility:hidden;}

.klein {
	font-size: .7em;
	margin: 0 0 .3em .3em;
}

.button, .away {
	border: 1px solid;
	padding: 1px 5px;
	background: #fff;
	vertical-align:bottom;
	cursor:pointer;
}

#talk {
	margin: 0 3px 0 0;
	background-color: rgba(255,255,255,0.6);
	height:unset !important;
	padding: 0.7em 0 0 0.7em;
	border-radius:5px;
}

.rooms {
	background-color: rgba(255,255,255,0.6);
	border-radius:5px;
	max-width:16em;
}

#wall {
	height:<?php echo $hoehe?>em;
	resize:vertical;

	overflow: auto;
	padding: 0 0 .7em 0;
	line-height: 1.1em;
	max-width: 60em; /* damit word-wrap weiss was es tun soll */
	word-wrap:break-word;
}

#wall p {

	padding:  0 .5em 0 3.4em;
	text-indent: -3em;
}

#wall .nick, #wall .nk {
	font-weight:900;
}

#wall .whisper, #wall .at {
	color: #222;
	background: yellow;
}

#line {
	width: 45em;
	height:31px;
	max-width: 75%;
	max-width: min(75%, 50vw);
	font-size:1em;
}
input#line {position:relative; top: -6px;}

#ton {
	width: 0;
	height: 0;
}
#uo {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
 		echo "display:block; max-height: 24em; overflow-y:auto;";
	} ?>
}
* html #uo {
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "height: 1.5em;";
	} ?>
}
#uo ul, #uo ul li {
	display: inline;
	<?php if ($chat_light != "yes" && $anz_rooms != 1) {
		echo "display:block;";
	} ?>
	font-size:100%;
}
#uo ul li {line-height:1.4em;}

#uo ul, #user_pro_room ul, #opt form p {
	padding: .2em 0 .25em 0;
}

#user_pro_room ul li {
	padding:0;
	line-height:1.3em;
}

#addsmileys {

	margin: 5px 0 0 5px;
}
object {margin: 5px;}

dfn, .dot {
	position:absolute;
	left:-1000px;
	top:-1000px;
	width:0;
	height:0;
	overflow:hidden;
	display:inline;
}

#f {margin-left:0;}

#opt input[type=submit] {margin-top:3px}

#talk input, .rooms input {
	background:#fff1fa;
	border:1px solid #c00;
	cursor:pointer;
}
#reverse, #mehrzeilig, #datum, #uhr, #bilder, #avatar, #sound, #nickfarben,#nickfarben2, #time_online, #time_real {
	border: 0;
	background: transparent;
}

#line, #handle, #room {
	border: 1px solid #c00;
	padding: 1px 0 1px 3px;

	cursor:text;
}

label, select {cursor:pointer; font-size:1em;}
label {margin-left: 4px;}

input[type="text"], select {
	border: 1px solid;
	padding: .2em .3em;
}

#menu1, #menu2 {width:65%; clear:both; display:block;margin-bottom: 4px !important;}

<?php
if ($nickcolors != "on") {
   echo '#menu1 {display:none}';
}
?>

<?php
if ($stil != 0) {
   echo '#menu1 {width: 100%}';
   echo '* html #menu1 {width:96%}';
}
?>

.uolist {display:none;}
#upload {display:block; margin:8px 0 2em 0; clear:left;min-height:unset !important;}

#logout, .logout {
	text-align:center;
	margin:4px 2px;
	padding:3px 8px;
	border: 2px outset #ccc;
	background-color: #fff1fa;
	max-width:18em;
	cursor:pointer;
}
.logout a {text-decoration:none;}

a.mp3 {
	text-decoration: none;
	padding-left: 20px;
	background-image:url(img/audio.gif) !important;
	background-repeat:no-repeat !important;
	background-position: 0 50% !important;
}
.hello {color: red !important; font-size: 80%; font-weight:bold; font-style:italic;}

.yta {color:black;font-weight:bold; font-family:Arial narrow, Arial; font-size: 1.2em;}
.ytb {font-family:Arial narrow, Arial; background:#a00;color:white !important;font-weight:bold;font-size: 1.2em; padding: 0 .2em; margin-left: .1em; border-radius:.4em;}

fieldset #upload #file{border:0 none !important; background:transparent;}

a.stop {
	color:#fff;
	background: #c00;
	text-decoration:none;
	font-size: 80%;
	padding: 0 2px;
}
#mp3 audio {
	margin-top: 3px;
	margin-left: 5px;
	width: 15em;
	max-height:20px;
}

@-moz-document url-prefix() {
	audio {filter: invert(1);}
	#mp3 audio {max-height:30px;margin-top:0;}
}

#r_player, #player {width: 95%;margin: 15px 0 !important}
#r_player ul, #player ul {background:#fff;}

#radio {text-align:center;}
#player_0 embed {max-width: 100%; outline:0; margin: 0 auto;}

.av {
	margin: 0 2px 0 0;
	border:1px solid #888;
	border-radius:3em;

	width:30px !important;
	object-fit: cover;
	clip-path: circle(50% at 50% 49%);
	position:relative;top:4px;
}

#webradio {text-align:center;}
#audio-controls {margin-top: -24px;}
input[type="image"] {cursor:pointer; padding: 2px 5px;border:1px solid #888;}
input[type="image"]:hover, input[type="image"]:focus { background: #ddd}
input[type="image"]:disabled {
	opacity:.4;
	cursor:default;
	background:transparent;
}
.helplinks {
	margin:0 10px;
	position:relative;top:2px;
}
.helplinks p {color:transparent!important}

.helplinks p a:not(.flag) {
	border: 1px solid;
	border-radius:3px;
	padding: 2px 4px;
	background:#fff;

}
.helplinks a {color:#747474;text-decoration:none}
.helplinks a span.dot {display:none}

#inner_befehle {padding:2px;}
.more_smileys img {height:22px;margin-bottom:-2px;border-radius:1em}

.pin {
	background: #eee;
	border:2px solid #ddd;
	top: -0 !important;
}
