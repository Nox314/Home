<?php
// kritische Cookies löschen
$chatcookies = array(
	'LoginCookie',
	'watch',
	'listen',
	'showip',
	'nick',
	'Style',
	'correct_logout',
);

if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);

    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
	
		if (in_array($name, $chatcookies) || strpos($name,'arrival') !== false) {
			unset($_COOKIE[$name]);
			$res = setcookie($name, '', time() - 3600);
		}
    }
}

$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname(htmlspecialchars($_SERVER['PHP_SELF'])), '/\\');
$extra = 'login.php';

header("Location: //$host$uri/$extra");
exit();

?>
