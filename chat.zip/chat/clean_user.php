<?php
date_default_timezone_set('Europe/Berlin');

$userfile = __DIR__.'/user/user.txt';
$dir = __DIR__.'/user/';
$eol = PHP_EOL;

// Tagesbackup-Datei
$backup = $dir . 'user.txt_' . date('Ymd') . '.bak';

// Prüfen: Backup existiert heute schon?
if (!file_exists($backup) && file_exists($userfile)) {

	if (file_exists('cleanup_admins.php')) { include_once('cleanup_admins.php');}
	if (file_exists('cleanup_mods.php')) { include_once('cleanup_mods.php');}
	if (file_exists('cleanup_interne.php')) { include_once('cleanup_interne.php');}
	if (file_exists('cleanup_profile.php')) { include_once('cleanup_profile.php');}

				
	// user.txt einlesen und bereinigen
	$lines = file($userfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	$newline4 = '';

	foreach ($lines as $val) {
		$teile = explode("****", $val);
		$last_access = isset($teile[3]) ? $teile[3] : null;
		$eintagsfliege = isset($teile[4]) ? trim($teile[4]) : '';
		$access = 0;

		if ($last_access) {
			$datum_teile = explode(" ", $last_access);
			if (isset($datum_teile[0], $datum_teile[1])) {
				$datum_teile1 = explode(".", $datum_teile[0]);
				if (count($datum_teile1) === 3) {
					$access = strtotime($datum_teile1[2].'-'.$datum_teile1[1].'-'.$datum_teile1[0].' '.$datum_teile[1]);
				}
			}
		}

		if ($teile[0] === 'Gast') $newline4 .= $val . $eol;
		if ($eintagsfliege == 1 && time() - $access < 60*60*24*15) $newline4 .= $val . $eol;
		if ($eintagsfliege == 2 && time() - $access < 60*60*24*30) $newline4 .= $val . $eol;
		if ($eintagsfliege == 3 && time() - $access < 60*60*24*30*3) $newline4 .= $val . $eol;
		if ($eintagsfliege == 4 && time() - $access < 60*60*24*30*4) $newline4 .= $val . $eol;
		if ($eintagsfliege == 5 && time() - $access < 60*60*24*30*5) $newline4 .= $val . $eol;
		if ($eintagsfliege >= 6 && time() - $access < 60*60*24*30*6) $newline4 .= $val . $eol;
	}

	// Backup für heute erstellen
	copy($userfile, $backup);

	// user.txt einmal täglich neu schreiben
	// file_put_contents($userfile, $newline4, LOCK_EX);

	$tmp = $userfile . '.tmp';
	file_put_contents($tmp, $newline4, LOCK_EX);
	rename($tmp, $userfile);

}
?>
