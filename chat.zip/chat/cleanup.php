<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include("chat_config.php");

$clean_dir = 'rooms/';
$logs_dir  = 'logs/';
$anzahl_msg = $anz_msg * 2;

$logging_enabled = (isset($logfile) && $logfile === "on");


// ------------------- HELPERS -------------------

function safe_read($file) {
	if (!is_file($file)) return '';
	$size = filesize($file);
	if ($size <= 0) return '';
	
	$h = fopen($file, "r");
	if (!$h) return '';
	
	$data = fread($h, $size);
	fclose($h);
	
	return $data ?: '';
}

function safe_write($file, $content) {
	$f = fopen($file, "w");
	if (!$f) return;
	
	flock($f, LOCK_EX);
	fwrite($f, $content);
	flock($f, LOCK_UN);
	fclose($f);
}

function append_log($file, $content) {
	$f = fopen($file, "a");
	if (!$f) return;
	
	flock($f, LOCK_EX);
	fwrite($f, $content);
	flock($f, LOCK_UN);
	fclose($f);
}

function clean_content($text) {
	if ($text === '') return '';

	$lines = explode("\n", $text);
	$out = [];

	foreach ($lines as $line) {
		if (strpos($line,"approve") === false && strpos($line,"Chatbot") === false) {
			$out[] = $line;
		}
	}

	$text = implode("\n", $out);

	$text = preg_replace('/smileys\d{1,2}\//', '../$0', $text);
	$text = str_replace(
		["img/", "profile/", "popprof.php"],
		["../img/", "../profile/", "../popprof.php"],
		$text
	);

	return preg_replace('~(\d+)\.(\d+)\.(\d+)\.(\d+)~', "$1.$2.$3.x", $text);
}

function is_valid_room($file) {
	return !in_array($file, [
		".","..",".htaccess",".htusers",".htpasswd"
	]);
}


// ------------------- 1. FILES KÜRZEN -------------------

if ($dh = opendir($clean_dir)) {
	while (($file = readdir($dh)) !== false) {

		if (!is_valid_room($file)) continue;

		$full = $clean_dir.$file;
		if (!is_file($full)) continue;

		if (strpos($file,"_log") !== false) continue;

		$lines = @file($full);
		if (!$lines) continue;

		if (count($lines) > $anzahl_msg) {

			$cut = floor($anzahl_msg / 2);

			$new  = array_slice($lines, -$cut);
			$old  = array_slice($lines, 0, -$cut);

			safe_write($full, implode("", $new));

			if ($logging_enabled) {
				$content = clean_content(implode("", $old));
				append_log($logs_dir.$file."_log", $content);
			}
		}
	}
	closedir($dh);
}


// ------------------- 2. ALTE ROOMS -------------------

$delete = [];

if ($dh = opendir($clean_dir)) {
	while (($file = readdir($dh)) !== false) {

		if (!is_valid_room($file)) continue;

		$full = $clean_dir.$file;
		if (!is_file($full)) continue;

		$filealter = time() - filemtime($full);
		$is_private = strpos($file,"_pr") !== false;

		// leere private löschen
		if ($is_private && $filealter >= 180 && filesize($full) == 0) {
			unlink($full);
			continue;
		}

		// öffentliche Räume
		if (
			!$is_private
			&& strpos($file,"_log") === false
			&& !in_array($file, ["Standard","Offline","Flirtchat","Lobby"])
			&& $filealter >= 3600 * $clean
		) {
			if ($logging_enabled) {
				append_log($logs_dir.$file."_log", clean_content(safe_read($full)));
			}
			$delete[] = $full;
			continue;
		}

		// private Räume
		if ($is_private && $filealter >= 3600 * $clean_priv) {
			if ($logging_enabled) {
				append_log($logs_dir.$file."_log", clean_content(safe_read($full)));
			}
			$delete[] = $full;
		}
	}
	closedir($dh);
}

// löschen
foreach ($delete as $f) {
	if (file_exists($f)) unlink($f);
}


// ------------------- 3. USER CLEANUP -------------------

foreach (glob(__DIR__."/user/max_on*") as $f) {
	if (strpos($f,'_on_01') === false && strpos($f,'max_on_tag') === false && strpos($f,'alltime') === false && time()-filemtime($f) > 30*86400) {
		unlink($f);
	}
}

foreach (glob(__DIR__."/user/user.txt_*") as $f) {
	if (time()-filemtime($f) > 7*86400) unlink($f);
}

foreach (glob(__DIR__."/user/verified.txt_*") as $f) {
	if (time()-filemtime($f) > 7*86400) unlink($f);
}


// ------------------- 4. BAN / MAULKORB / NOPV -------------------

function clean_time_file($file) {
	if (!file_exists($file)) return;

	$lines = file($file);
	$new = '';
	$changed = false;

	foreach ($lines as $line) {
		$t = explode("****", $line);
		if (!isset($t[1])) continue;

		$t2 = explode("++++", $t[1]);
		$time = $t2[0] ?? 0;

		if (time() < $time) {
			$new .= $line;
		} else {
			$changed = true;
		}
	}

	if ($changed) safe_write($file, $new);
}

clean_time_file("user/ban.txt");
clean_time_file("user/maulkorb.txt");
clean_time_file("user/nopv.txt");


// ------------------- 5. SPERRE -------------------

if (file_exists("user/sperre.txt") && time()-filemtime("user/sperre.txt") > 86400) {
	safe_write("user/sperre.txt", "");
}


// ------------------- 6. UPLOAD CLEAN -------------------

function clean_upload($dir, $max, $max_mp3 = null) {

	$files = glob($dir.'*.*');

	array_multisort(
		array_map('filemtime', $files),
		SORT_NUMERIC,
		SORT_DESC,
		$files
	);

	$count = 0;
	$count_mp3 = 0;

	foreach ($files as $f) {

		$name = str_replace($dir,'',$f);

		if (strpos($name,".mp3") !== false) {
			if ($max_mp3 !== null && $count_mp3++ >= $max_mp3) unlink($f);
			continue;
		}

		if ($count++ >= $max) unlink($f);
	}
}

clean_upload('upload/', 500, 20);
clean_upload('tn_upload/', 200);


// ------------------- 7. LOGS -------------------

$protected = array('.htusers', '.htaccess', 'reader.php', 'log_list.php');

if ($dh = opendir($logs_dir)) {
	while (($file = readdir($dh)) !== false) {
		if (in_array($file, $protected, true)) continue;
		if (!is_valid_room($file)) continue;
		$full = $logs_dir.$file;
		if (!is_file($full)) continue;
		$age = time()-filemtime($full);
		if ($age > 90*86400) {
			unlink($full);
			continue;
		}
		$size = @filesize($full);
		if ($size >= 1000000 && strpos($file,"_bak") === false) {
			rename($full, $full.time().'_bak');
		}
	}
	closedir($dh);
}

// ------------------- 8. LOG-TRIM -------------------

function trim_file($file, $max) {
	if (!file_exists($file)) return;

	$lines = explode("\n", safe_read($file));

	if (count($lines) > $max) {
		$lines = array_slice($lines, -$max);
		safe_write($file, implode("\n", $lines));
	}
}

trim_file('skincount.txt', 101);
trim_file('tmp/torlog.txt', 101);
trim_file('tmp/vpnlog.txt', 101);


// ------------------- 9. FS CHECK -------------------

if (!file_exists("fp.txt") || file_get_contents("fp.txt") == "null") {
	$ok = @fsockopen('www.google.de', 80, $e, $s, 2);
	safe_write("fp.txt", $ok ? "yes" : "no");
}

?>