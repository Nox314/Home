<?php
// admins User löschen, wenn nicht (mehr) in der user.txt:

$user_dateiname = __DIR__."/user/user.txt";

if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);

	foreach($lines as $key => $val) {
		$teile = explode("****", $val);
		$reg_user[] = $teile[0];
	}
}
// print_r($reg_user);


$admins_dateiname = __DIR__."/admin/admins.txt";

if (file_exists($admins_dateiname)) {

	$cont_vor = file_get_contents($admins_dateiname);

	$lines1 = file($admins_dateiname);
	$unique = array_unique($lines1);
	natcasesort($unique);

	$admins_user = "";
	foreach($unique as $key => $val1) {
		if (in_array(trim($val1), $reg_user)) {
			$admins_user .= $val1;
		}
	}
}
// echo $admins_user;

if ($cont_vor == $admins_user) {
	return;
}


// backup erstellen
$newfile = __DIR__.'/user/admins.txt_'.time().'.bak';

if (!copy($admins_dateiname, $newfile)) {
    // echo "Sicherung der Datei $admins_dateiname schlug fehl...\n";
} else {
    // echo "Backup der Datei $admins_dateiname nach $newfile erfolgreich. \n";
}


$handler4 = fopen($admins_dateiname, "w");
flock($handler4,LOCK_EX);
fwrite($handler4 , $admins_user);
flock($handler4,LOCK_UN);
fclose($handler4);







?>