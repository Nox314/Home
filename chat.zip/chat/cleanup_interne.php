<?php
// interne User löschen, wenn nicht (mehr) in der user.txt:

$user_dateiname = __DIR__."/user/user.txt";

if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);

	foreach($lines as $key => $val) {
		$teile = explode("****", $val);
		$reg_user[] = $teile[0];
	}
}
// print_r($reg_user);


$interne_dateiname = __DIR__."/admin/interne.txt";

if (file_exists($interne_dateiname)) {

	$cont_vor = file_get_contents($interne_dateiname);

	$lines1 = file($interne_dateiname);
	$unique = array_unique($lines1);
	natcasesort($unique);

	$interne_user = "";
	foreach($unique as $key => $val1) {
		if (in_array(trim($val1), $reg_user)) {
			$interne_user .= $val1;
		}
	}
}
// echo $interne_user;

if ($cont_vor == $interne_user) {
	return;
}

// backup erstellen
$newfile = __DIR__.'/user/interne.txt_'.time().'.bak';

if (!copy($interne_dateiname, $newfile)) {
    // echo "Sicherung der Datei $interne_dateiname schlug fehl...\n";
} else {
    // echo "Backup der Datei $interne_dateiname nach $newfile erfolgreich. \n";
}


$handler4 = fopen($interne_dateiname, "w");
flock($handler4,LOCK_EX);
fwrite($handler4 , $interne_user);
flock($handler4,LOCK_UN);
fclose($handler4);







?>