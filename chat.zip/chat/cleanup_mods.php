<?php
// mods User löschen, wenn nicht (mehr) in der user.txt:

$user_dateiname = __DIR__."/user/user.txt";

if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);

	foreach($lines as $key => $val) {
		$teile = explode("****", $val);
		$reg_user[] = $teile[0];
	}
}
// print_r($reg_user);

$mods_dateiname = __DIR__."/admin/mods.txt";

if (file_exists($mods_dateiname)) {

	$cont_vor = file_get_contents($mods_dateiname);

	$lines1 = file($mods_dateiname);
	$unique = array_unique($lines1);
	natcasesort($unique);

	foreach($unique as $key => $val1) {
		if (in_array(trim($val1), $reg_user)) {
			$mods_user .= $val1;
		}
	}
}

// echo $mods_user;

if ($cont_vor == $mods_user) {
	return;
}

// backup erstellen
$newfile = __DIR__.'/user/mods.txt_'.time().'.bak';

if (!copy($mods_dateiname, $newfile)) {
    // echo "Sicherung der Datei $mods_dateiname schlug fehl...\n";
} else {
    // echo "Backup der Datei $mods_dateiname nach $newfile erfolgreich. \n";
}

$handler4 = fopen($mods_dateiname, "w");
flock($handler4,LOCK_EX);
fwrite($handler4 , $mods_user);
flock($handler4,LOCK_UN);
fclose($handler4);







?>