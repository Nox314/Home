<?php
// profile files löschen, wenn nicht (mehr) in der user.txt:
$clean_dir5 = __DIR__."/profile/";
if ($handle = opendir($clean_dir5)) {
	// Das ist der korrekte Weg, ein Verzeichnis zu durchlaufen:
	while (false !== ($file = readdir($handle))) {

        // nur registrierte User
        $in_regdb = false;
        if (file_exists(__DIR__."/user/user.txt")) {
        	$d1 = file(__DIR__."/user/user.txt");
        	foreach ($d1 as $c) {
        		$part1 = explode("****",$c);
        		if ($part1[0] == $file) {
					$in_regdb = true;
        		} elseif ($part1[0].'.jpg' == $file) {
					$in_regdb = true;
        		} elseif ($part1[0].'.gif' == $file) {
					$in_regdb = true;
                }
        	}
        }

		// if(($in_regdb !== true 	|| filesize($clean_dir5.$file) < 160)
		if(($in_regdb !== true )
			&& $file != "."
			&& $file != ".."
			&& $file != ".htaccess"
			&& $file != ".htusers"
			&& $file != ".htpasswd"
			// && strpos($file,"_inv.txt") === false // flirtfiles anders behandeln
		){$profile_array[] = $file;}
	}
	closedir($handle);
}
if(isset($profile_array)) {
	$del5_file = $profile_array;
} else {
	$del5_file = "";
}

// print_r ($del5_file);


// array durchlaufen und löschen (if fileexist):
if ($del5_file != "") {
	$anz = count($del5_file);
	for($i = 0; $i < count($del5_file); $i++){
		if(file_exists($clean_dir5.$del5_file[$i])) {
			unlink($clean_dir5.$del5_file[$i]);
		}
	}
}
?>