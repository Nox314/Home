<?php
// Verified User löschen, wenn nicht (mehr) in der user.txt:

$user_dateiname = __DIR__."/user/user.txt";

if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);

	foreach($lines as $key => $val) {
		$teile = explode("****", $val);
		$reg_user[] = $teile[0];
	}
}
// print_r($reg_user);


$verified_dateiname = __DIR__."/admin/verified.txt";

if (file_exists($verified_dateiname)) {

	$cont_vor = file_get_contents($verified_dateiname);

	$lines1 = file($verified_dateiname);
	$unique = array_unique($lines1);
	natcasesort($unique);

	$verified_user = "";
	foreach($unique as $key => $val1) {
		if (in_array(trim($val1), $reg_user)) {
			$verified_user .= $val1;
		}
	}
}
// echo $verified_user;

if ($cont_vor == $verified_user) {
	exit;
}

// backup erstellen
$newfile = __DIR__.'/user/verified.txt_'.time().'.bak';

if (!copy($verified_dateiname, $newfile)) {
    echo "Sicherung der Datei $verified_dateiname schlug fehl...\n";
} else {
    echo "Backup der Datei $verified_dateiname nach $newfile erfolgreich. \n";
}


$handler4 = fopen($verified_dateiname, "w");
flock($handler4,LOCK_EX);
fwrite($handler4 , $verified_user);
flock($handler4,LOCK_UN);
fclose($handler4);







?>