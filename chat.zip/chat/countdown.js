let reloadPending = false; // Flag, um mehrfaches Reload zu verhindern

// Funktion zum Laden der Datei set_offline.txt
async function loadTimeRange() {
	try {
		const response = await fetch("proxy.php");
		if (!response.ok) throw new Error("Datei konnte nicht geladen werden");

		let timeRange = (await response.text()).trim();

		// Wenn Datei fehlt oder leer ist → abbrechen, keine Errors
		if (!timeRange || !timeRange.includes(" - ")) {
			console.warn("set_offline.txt fehlt oder hat kein gültiges Format.");
			return; // Countdown nicht starten
		}

		const [start, end] = timeRange.split(" - ").map(t => t.trim());

		// Falls aus irgendeinem Grund end leer ist
		if (!end) {
			console.warn("Endzeit fehlt in set_offline.txt");
			return;
		}

		initializeCountdown(end);

	} catch (error) {
		console.error("Fehler beim Laden der Datei:", error);
	}
}

// Countdown initialisieren
function initializeCountdown(endTime) {
	const [endHour, endMinute] = endTime.split(":").map(Number);

	// Endzeit des Countdowns berechnen
	const endDateTime = new Date();
	endDateTime.setHours(endHour, endMinute, 0, 0);

	const countdownStartTime = new Date(endDateTime.getTime() - 5 * 60 * 1000); // 5 Minuten vor Endzeit

	// Speichere die relevanten Zeiten im localStorage
	localStorage.setItem("countdownEndTime", endDateTime.toISOString());
	localStorage.setItem("countdownStartTime", countdownStartTime.toISOString());

	checkCountdownStatus();
}

// Countdown-Status prüfen und gegebenenfalls starten
function checkCountdownStatus() {
	const countdownElement = document.getElementById("status");
	const countdownEndTime = new Date(localStorage.getItem("countdownEndTime"));
	const countdownStartTime = new Date(localStorage.getItem("countdownStartTime"));
	const now = new Date();

	if (now >= countdownStartTime && now <= countdownEndTime) {
		// Wenn die aktuelle Zeit im Countdown-Zeitraum liegt, Countdown starten
		startCountdown(countdownEndTime);
	} else if (now < countdownStartTime) {
		// Wartezeit bis zum Countdown berechnen
		const timeUntilStart = countdownStartTime - now;

		// countdownElement.textContent = `Countdown startet um ${countdownStartTime.toLocaleTimeString()}`;

		// Timer setzen, um den Countdown zur richtigen Zeit zu starten
		setTimeout(() => {
			checkCountdownStatus();
		}, timeUntilStart);
	} else {
		// Countdown-Zeitraum ist vorbei
		// countdownElement.textContent = "Countdown nicht aktiv.";
	}
}

// Countdown starten
function startCountdown(countdownEndTime) {
	const countdownElement = document.getElementById("status");

	const countdownInterval = setInterval(() => {
		const now = new Date();
		const timeLeft = Math.max(0, Math.floor((countdownEndTime - now) / 1000)); // Sekunden bis zur Endzeit

		if (timeLeft > 0) {
			const minutes = Math.floor(timeLeft / 60);
			const seconds = timeLeft % 60;
			countdownElement.textContent = `Chatroom schließt in ${minutes}:${seconds.toString().padStart(2, '0')} Minuten`;
		} else {
			clearInterval(countdownInterval);
			// countdownElement.textContent = "Zeit abgelaufen!";
			localStorage.removeItem("countdownEndTime");
			localStorage.removeItem("countdownStartTime");
			setTimeout(() => location.reload(), 1000);
						
		}
	}, 1000);
}

// Datei prüfen und Countdown starten
loadTimeRange();

