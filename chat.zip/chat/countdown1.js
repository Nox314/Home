// Funktion zum Laden der Datei set_offline.txt
async function loadTimeRange() {
	try {
		const response = await fetch("admin/set_offline.txt");
		if (!response.ok) throw new Error("Datei konnte nicht geladen werden");
		const timeRange = await response.text();

		const [start, end] = timeRange.split(" - ").map(t => t.trim());
		initializeCountdown(end);
	} catch (error) {
		console.error("Fehler beim Laden der Datei:", error);
	}
}

// Countdown initialisieren
function initializeCountdown(endTime) {
	const [endHour, endMinute] = endTime.split(":").map(Number);

	// Endzeit des Countdowns berechnen
	const endDateTime = new Date();
	endDateTime.setHours(endHour, endMinute, 0, 0);

	const countdownStartTime = new Date(endDateTime.getTime() - 5 * 60 * 1000); // 5 Minuten vor Endzeit

	// Speichere die Endzeit und Startzeit im localStorage
	localStorage.setItem("countdownEndTime", endDateTime.toISOString());
	localStorage.setItem("countdownStartTime", countdownStartTime.toISOString());

	startCountdown();
}

// Countdown starten
function startCountdown() {
	const countdownElement = document.getElementById("status");

	const countdownEndTime = new Date(localStorage.getItem("countdownEndTime"));
	const countdownStartTime = new Date(localStorage.getItem("countdownStartTime"));

	const countdownInterval = setInterval(() => {
		const now = new Date();

		// Prüfen, ob die aktuelle Zeit im Countdown-Fenster liegt
		if (now >= countdownStartTime && now <= countdownEndTime) {
			const timeLeft = Math.max(0, Math.floor((countdownEndTime - now) / 1000)); // Sekunden bis zur Endzeit

			const minutes = Math.floor(timeLeft / 60);
			const seconds = timeLeft % 60;

			countdownElement.textContent = `Chatroom schließt in ${minutes}:${seconds.toString().padStart(2, '0')} Minuten`;

			if (timeLeft <= 0) {
				clearInterval(countdownInterval);
				// countdownElement.textContent = "Zeit abgelaufen!";
				localStorage.removeItem("countdownEndTime");
				localStorage.removeItem("countdownStartTime");
				location.reload();
						
			}
		} else if (now < countdownStartTime) {
			// Zeige die geplante Startzeit des Countdowns
			// countdownElement.textContent = `Countdown startet um ${countdownStartTime.toLocaleTimeString()}`;
		} else {
			clearInterval(countdownInterval);
			// countdownElement.textContent = "Countdown nicht gestartet.";
		}
	}, 1000);
}

// Datei prüfen und Countdown starten
loadTimeRange();
