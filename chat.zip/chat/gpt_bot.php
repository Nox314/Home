<?php

if (file_exists('personal_config_inc.php')) {
	include ('personal_config_inc.php');
} else {
	include ('config_inc.php');	
}

if (!isset($apiKey)) {
	die('API-Key not found');
}



$input = json_decode(file_get_contents('php://input'), true);
$messages = $input['messages'] ?? [];

$url = 'https://api.openai.com/v1/chat/completions';

$model = 'gpt-4o-mini';  // 'gpt-5' wenn verfügbar

// 🟢 Datum & Uhrzeit hinzufügen
$today = date('d.m.Y');
$time = date('H:i');
array_unshift($messages, [
	'role' => 'system',
	'content' => "Das heutige Datum ist $today, die aktuelle Uhrzeit ist $time (Serverzeit)."
]);

$data = [
	'model' => $model,
	'messages' => $messages,
	'temperature' => 0.7
];

$options = [
	'http' => [
		'header'  => "Content-Type: application/json\r\nAuthorization: Bearer $apiKey\r\n",
		'method'  => 'POST',
		'content' => json_encode($data)
	]
];

$context  = stream_context_create($options);
$result = file_get_contents($url, false, $context);

if ($result === FALSE) {
	http_response_code(500);
	echo 'Fehler bei der GPT-Antwort.';
	exit;
}

$responseData = json_decode($result, true);

$reply = $responseData['choices'][0]['message']['content'] ?? 'Keine Antwort';

echo $reply;
