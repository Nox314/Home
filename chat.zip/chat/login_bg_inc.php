<?php

if (date('md') == '1030' || date('md') == '1031' ) {
	unset($_SESSION['bg_img']);
	if (strpos($file,'halloween') !== false) {
		$bg_array[] = 'bg_img/'.$file;
	}
}
elseif (date('m') >= '09' && date('m') <= '11') {
	unset($_SESSION['bg_img']);
	if (strpos($file,'autumn-') !== false) {
		$bg_array[] = 'bg_img/'.$file;
	}
}
// elseif (date('md') >= '1215' && date('md') <= '1231'  || date('md') >= '0101' && date('md') <= '0106' ) {
elseif (date('md') >= '1215' && date('md') <= '1226') {
	unset($_SESSION['bg_img']);
	if (strpos($file,'christmas-') !== false) {
		$bg_array[] = 'bg_img/'.$file;
	}
}
elseif (date('m') == '12' || (date('m') >= '01' && date('m') <= '02')) {
	unset($_SESSION['bg_img']);
	if (strpos($file,'winter-') !== false ) {
		$bg_array[] = 'bg_img/'.$file;
	}
	if (date('m') == '02') {
		if (strpos($file,'spring-') !== false) {
			$bg_array[] = 'bg_img/'.$file;
		}
	}
}
elseif (date('m') == '03') {
	unset($_SESSION['bg_img']);
	if (strpos($file,'spring-') !== false ) {
		$bg_array[] = 'bg_img/'.$file;
	}
}
else {
	unset($_SESSION['bg_img']);
	// if (strpos($file,'spring-') === false && strpos($file,'winter-') === false && strpos($file,'halloween-') === false && strpos($file,'christmas-') === false ) {
		if (strpos($file,'winter-') === false && strpos($file,'autumn-') === false && strpos($file,'halloween') === false && strpos($file,'christmas-') === false ) {
		$bg_array[] = 'bg_img/'.$file;
	}
}



?>