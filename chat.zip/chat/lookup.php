<?php

$angemeldet = "user/user.txt";
$lines = file($angemeldet);
array_unshift($lines,"Gast****fe01ce2a7fbac8fafaed7c982a04e229"); // macht Gastlogin nur noch von $allowguest abhängig machen, auch wenn der erste User in der user.txt gelöscht wird.


$alluser[0] = ""; // sollte jemand alle User löschen
// Prüfung ob Nick in der reg-DB:
foreach ($lines as $line_num => $line) {
     $user = explode("****",$line);
     $alluser[] = $user[0];
}


if (isset($_GET['value'])) {
    $inputValue = $_GET['value'];

    // Überprüfen, ob der Wert im Array enthalten ist
    if (in_array($inputValue, $alluser)) {
        echo "Der Wert '$inputValue' ist im Array enthalten.";
    } else {
        echo "Der Wert '$inputValue' ist nicht im Array enthalten.";
    }
}
?>
