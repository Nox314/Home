<?php
session_start();

$dir      = 'bg_img';
$bg_array = [];

// Filterdatei einmal prüfen, nicht pro Schleifendurchlauf
$useFilter = file_exists('login_bg_inc.php');

foreach (scandir($dir) as $file) {
	if ($file === '.' || $file === '..') continue;

	if ($useFilter) {
		// Saisonfilter pro Datei: entscheidet anhand des Datums,
		// ob $file in $bg_array aufgenommen wird.
		include 'login_bg_inc.php';
	} else {
		$bg_array[] = $dir.'/'.$file;
	}
}

// Fallback: hat die saisonale Filterung nichts geliefert
// (z.B. keine passenden Saison-Bilder vorhanden), alle Bilder nehmen,
// damit array_rand() nie auf ein leeres Array trifft.
if (!$bg_array) {
	foreach (scandir($dir) as $file) {
		if ($file === '.' || $file === '..') continue;
		$bg_array[] = $dir.'/'.$file;
	}
}

if ($bg_array) {
	$_SESSION['bg_img'] = $bg_array[array_rand($bg_array)];
}

header('Location: chat.php');
exit;