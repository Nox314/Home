<?php

date_default_timezone_set('Europe/Berlin');

include('chat_config.php');
if (!isset($time_offset)) {$time_offset = 0;}


// Chat zeitabhaengig offline:
if (file_exists('admin/set_offline.txt') && (!isset($ab_offen) || !isset($ab_offen))){
	$times_online = file_get_contents('admin/set_offline.txt');

	$offen = explode('-',$times_online);
	$ab_offen = trim($offen[0]);
	$bis_offen = trim($offen[1]);
}


$closed = true;

if ($ab_offen != "" && $bis_offen !="" ) {
	// $uhrzeit = date("H:i");
	$uhrzeit = date("H:i", strtotime("$uhrzeit +".$time_offset." hour")); // Server Offset hinzufügen

	$uhrzeit_std = substr($uhrzeit,0,2);
	$uhrzeit_min = substr($uhrzeit,3,2);
	$uhrzeit_norm = $uhrzeit_std * 60 + $uhrzeit_min;

	$ab_offen_std = substr($ab_offen,0,2);
	$ab_offen_min = substr($ab_offen,3,2);
	$ab_offen_norm = $ab_offen_std * 60 + $ab_offen_min;

	$bis_offen_std = substr($bis_offen,0,2);
	$bis_offen_min = substr($bis_offen,3,2);
	$bis_offen_norm = $bis_offen_std * 60 + $bis_offen_min;


	$noch_norm = $ab_offen_norm - $uhrzeit_norm;

	if ($noch_norm < 0) {$noch_norm = $noch_norm + 1440; }

	$hours = intval($noch_norm/60);
	$minutes = $noch_norm%60;
	
	if ($minutes != 1) {$plural = "n";} else {$plural = "";}

	$length = 2;
	$char = 0;
	$type = 'd';
	$format = "%{$char}{$length}{$type}";
	$minutes2 = sprintf($format, $minutes);

	if ($uhrzeit == $ab_offen) {$closed = false;}
	if ($bis_offen >= $uhrzeit && $uhrzeit >= $ab_offen) {$closed = false;}	
	if ($bis_offen < $ab_offen && $uhrzeit >= $ab_offen) {$closed = false;}	
	if ($bis_offen < $ab_offen && $uhrzeit <= $bis_offen){$closed = false;}	

		
	if ($closed !== false) {
		if ($hours == 0) {
			echo "<h3  class='noch'>Dieser Chatraum ist momentan geschlossen  - öffnet in $minutes Minute$plural </h3>";			
		} else {
			echo "<h3  class='noch'>Dieser Chatraum ist momentan geschlossen  - öffnet in $hours:$minutes2 Stunden </h3>";
		}
	}
	echo "<h3 class='noch'>Öffnungszeit $ab_offen Uhr bis $bis_offen Uhr</h3>";
}
?>