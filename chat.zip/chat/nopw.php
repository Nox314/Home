<?php

// function myucfirst($str) {
	// in login deklariert


if ($nickgross === true) {
	$regnick = myucfirst(htmlspecialchars(trim($_POST['regname'], " \t\n\r\0\x0B\xC2\xA0")));
} else {
	$regnick = htmlspecialchars(trim($_POST['regname'], " \t\n\r\0\x0B\xC2\xA0"));
}


if (file_exists("user/user.txt")) {
	$registered = file("user/user.txt");
	foreach ($registered as $r) {
		$part1 = explode("****",$r);
      	if (strtoupper($part1[0]) == strtoupper(trim($regnick))) {
            $meldung = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM2.'</span>';
			$passed = false;
		} 	
	}
}

// Anwesende Nicks nicht erlauben:
$show_dir = 'user/';
$dir=opendir($show_dir);
while (false !== ($file = readdir($dir))) {
	if(strpos($file,"ip_") !== false) {
		$userfile = $show_dir.$file;
       	$other_user = file($userfile);

		foreach ($other_user as $u) {
			$part2 = explode("++++",$u);
			$anw = str_replace("####","",$part2[1]);
      		if (trim($anw) == trim($regnick)) {
            	$meldung = '<span style="color:red;font-weight:bold;">'._DBLUSER.'</span>';
				$passed = false;
			}
		}
	} 
}



if (strlen(trim($regnick)) < 3) {
	$meldung = '<span style="color:red;font-weight:bold;">'._REG_FORM1.'</span>';
	$passed = false;
}


// // Benutzte Nicks nicht erlauben:
// $show_dir = 'rooms/';
// $dir=opendir($show_dir);
// while (false !== ($file = readdir($dir))) {
// 	$userfile = $show_dir.$file;
// 	$other_user = file($userfile);
//
// 	foreach ($other_user as $u) {
// 		foreach ($other_user as $o) {
// 			if ($regnick) {
// 				$yet = "0040".$regnick;
//       			if (strpos($o,$yet) !== false) {
//             		$meldung = '<span style="color:red;font-weight:bold;">'._DBLUSER.'</span>';
// 					$passed = false;
// 				}
// 			}
// 		}
// 	}
// }



if (in_array(strtolower(trim($regnick)), $nicknotallowed))  { // andere verbotene Nicks (chat_config.php)
    $meldung = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM3.'</span>';
	$passed = false;
}
if (preg_match("/:|;|,|\.|%|\"|<|>|\?|\/|&| |\+|\*|@|'/",trim($regnick))) {
    $meldung = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM4.'</span>';
	$passed = false;
}

if ($reg_closed == true) {
    // do nothing $meldung = '<span style="color:red;font-weight:bold;">'._LOG_FORM.'</span>';
	$passed = false;
}

if (!isset($passed)) {
	$_SESSION['chatuser'] = trim($regnick);
	setcookie("nick",trim($regnick), time()+86400*30); // nick cookie speichern fuer ban
	goodlog();
}
?>