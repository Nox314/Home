/*
 * passkey.js
 * Vanilla JS für WebAuthn/Passkey-Registrierung und -Login.
 * Erwartet auf der Seite:
 *   - login.php: <form id="login"> mit Feld regname (bereits vorhanden) -
 *                 Passkey wird transparent beim Absenden des Formulars versucht,
 *                 kein eigener Button nötig.
 *   - passkey_setup.php: Button id="passkey_register_btn"
 *                 plus Status-Element id="passkey_status"
 */

function b64urlToBuffer(b64url) {
	let b64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
	while (b64.length % 4) { b64 += '='; }
	const raw = atob(b64);
	const buf = new Uint8Array(raw.length);
	for (let i = 0; i < raw.length; i++) { buf[i] = raw.charCodeAt(i); }
	return buf;
}

function bufferToB64url(buf) {
	const bytes = new Uint8Array(buf);
	let str = '';
	for (let i = 0; i < bytes.length; i++) { str += String.fromCharCode(bytes[i]); }
	return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function passkeySetStatus(msg, isError) {
	const el = document.getElementById('passkey_status');
	if (!el) { return; }
	el.textContent = msg;
	el.style.color = isError ? '#c00' : '#080';
}

function passkeySupported() {
	return !!(window.PublicKeyCredential && navigator.credentials && navigator.credentials.create);
}


/* ---------- Registrierung (aus dem eingeloggten Chat heraus) ---------- */

async function passkeyRegister() {
	if (!passkeySupported()) {
		passkeySetStatus('Passkeys werden von diesem Browser/Gerät nicht unterstützt.', true);
		return;
	}

	try {
		passkeySetStatus('Passkey wird eingerichtet …', false);

		const optRes = await fetch('passkey_register_challenge.php', { credentials: 'same-origin' });
		const opts = await optRes.json();
		if (opts.error) { passkeySetStatus(opts.error, true); return; }

		const publicKey = {
			challenge: b64urlToBuffer(opts.challenge),
			rp: opts.rp,
			user: {
				id: b64urlToBuffer(opts.user.id),
				name: opts.user.name,
				displayName: opts.user.displayName,
			},
			pubKeyCredParams: opts.pubKeyCredParams,
			timeout: opts.timeout,
			attestation: opts.attestation,
			authenticatorSelection: opts.authenticatorSelection,
			excludeCredentials: (opts.excludeCredentials || []).map(c => ({
				type: c.type,
				id: b64urlToBuffer(c.id),
			})),
		};

		const cred = await navigator.credentials.create({ publicKey });

		const payload = {
			id: cred.id,
			rawId: bufferToB64url(cred.rawId),
			response: {
				clientDataJSON: bufferToB64url(cred.response.clientDataJSON),
				attestationObject: bufferToB64url(cred.response.attestationObject),
			},
		};

		const verifyRes = await fetch('passkey_register_verify.php', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(payload),
		});
		const result = await verifyRes.json();

		if (result.success) {
			passkeySetStatus('Passkey erfolgreich eingerichtet. Du kannst dich jetzt per Face ID/Touch ID einloggen.', false);
			localStorage.setItem('passkeyRegistered', '1');
		} else {
			passkeySetStatus(result.error || 'Registrierung fehlgeschlagen.', true);
		}
	} catch (err) {
		if (err.name === 'InvalidStateError') {
			// Das Gerät besitzt bereits einen passenden Passkey für diese Seite
			// (deshalb die Ablehnung durch excludeCredentials) - das ist der
			// Beweis, dass Login per Passkey funktionieren sollte, kein Fehler.
			localStorage.setItem('passkeyRegistered', '1');
			passkeySetStatus('Auf diesem Gerät ist bereits ein Passkey für diese Seite vorhanden - Login damit sollte funktionieren.', false);
		} else if (err.name === 'NotAllowedError') {
			passkeySetStatus('Abgebrochen.', true);
		} else {
			passkeySetStatus('Fehler beim Einrichten: ' + err.message, true);
		}
	}
}


/* ---------- Login (discoverable credentials, ohne Nickname-Eingabe) ---------- */

async function passkeyBuildLoginOptions() {
	const optRes = await fetch('passkey_login_challenge.php', { credentials: 'same-origin' });
	const opts = await optRes.json();
	return {
		challenge: b64urlToBuffer(opts.challenge),
		rpId: opts.rpId,
		timeout: opts.timeout,
		userVerification: opts.userVerification,
	};
}

// Baut aus dem Credential das Payload und schickt es als echtes Formular an
// login.php, damit der bestehende Redirect-Mechanismus (goodlog() -> Location:
// chat.php) unverändert greift.
function passkeySubmitCredential(cred) {
	const payload = {
		id: cred.id,
		rawId: bufferToB64url(cred.rawId),
		response: {
			clientDataJSON: bufferToB64url(cred.response.clientDataJSON),
			authenticatorData: bufferToB64url(cred.response.authenticatorData),
			signature: bufferToB64url(cred.response.signature),
			userHandle: cred.response.userHandle ? bufferToB64url(cred.response.userHandle) : null,
		},
	};

	const form = document.getElementById('login');
	let field = document.getElementById('passkey_response');
	if (!field) {
		field = document.createElement('input');
		field.type = 'hidden';
		field.name = 'passkey_response';
		field.id = 'passkey_response';
		form.appendChild(field);
	}
	field.value = JSON.stringify(payload);
	form.submit();
}

// Wird beim Absenden des Login-Formulars (Klick auf "Login"/Enter) ausgeführt:
// versucht einen Passkey NUR, wenn auf diesem Gerät/Browser zuvor tatsächlich
// einer eingerichtet wurde (lokaler Merker "passkeyRegistered" in localStorage,
// wird von passkeyRegister() gesetzt). Ohne diesen Merker wird gar nicht erst
// navigator.credentials.get() aufgerufen - sonst würde der Browser (bzw. z.B.
// 1Password) bei jedem Login-Versuch einen "keine Passkeys gespeichert"-Dialog
// zeigen, obwohl der User nie einen eingerichtet hat.
//
// Schlägt der Versuch fehl, wird NUR auf normales Nickname/Passwort umgeschaltet
// - der Merker bleibt bestehen. WebAuthn liefert für "User hat abgebrochen" und
// "kein passendes Credential vorhanden" bewusst denselben Fehler (NotAllowedError,
// aus Datenschutzgründen nicht unterscheidbar) - den Merker deshalb bei jedem
// Fehlschlag zu löschen, würde auch ein einfaches Vertippen/Wegtippen im
// Auswahl-Dialog dauerhaft abschalten. Ist der Passkey tatsächlich weg, hilft
// ein erneuter Besuch von passkey_setup.php.
let passkeySkipNextSubmit = false;

async function passkeyHandleFormSubmit(event) {
	if (event.defaultPrevented) { return; } // z.B. Nutzungsbedingungen nicht akzeptiert
	if (passkeySkipNextSubmit) { passkeySkipNextSubmit = false; return; } // regulärer Re-Submit nach gescheitertem Passkey-Versuch
	if (!passkeySupported()) { return; } // ganz normal mit Passwort weiter
	if (localStorage.getItem('passkeyRegistered') !== '1') { return; } // nie ein Passkey eingerichtet -> gar nicht erst versuchen

	event.preventDefault();

	try {
		const publicKey = await passkeyBuildLoginOptions();
		const cred = await navigator.credentials.get({ publicKey });
		passkeySubmitCredential(cred);
	} catch (err) {
		// abgebrochen, daneben getippt oder Passkey (mehr) verfügbar -> einfach
		// normal mit Nickname/Passwort weiter, Merker bleibt unangetastet
		passkeySkipNextSubmit = true;
		event.target.requestSubmit();
	}
}


document.addEventListener('DOMContentLoaded', function () {
	if (!passkeySupported()) {
		const regBtn = document.getElementById('passkey_register_btn');
		if (regBtn) { regBtn.style.display = 'none'; }
		return;
	}

	const regBtn = document.getElementById('passkey_register_btn');
	if (regBtn) { regBtn.addEventListener('click', passkeyRegister); }

	const loginForm = document.getElementById('login');
	if (loginForm) { loginForm.addEventListener('submit', passkeyHandleFormSubmit); }

	// Icon im Login-Button nur zeigen, wenn auf diesem Gerät ein Passkey
	// eingerichtet ist (gleicher Merker wie passkeyHandleFormSubmit())
	const icon = document.getElementById('passkey_icon');
	if (icon && localStorage.getItem('passkeyRegistered') === '1') {
		icon.style.display = 'inline-block';
	}
});  