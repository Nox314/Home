<?php
/*
 * passkey_login_challenge.php
 * Liefert die Optionen für navigator.credentials.get() beim Passkey-Login.
 * Keine allowCredentials -> der Browser zeigt die Konto-Auswahl aus den
 * auf dem Gerät hinterlegten (discoverable) Passkeys für diese Domain.
 */

header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once __DIR__ . '/webauthn_lib.php';

$challenge = random_bytes(32);
$_SESSION['passkey_login_challenge'] = base64url_encode($challenge);

$rpId = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']);

echo json_encode([
	'challenge' => base64url_encode($challenge),
	'rpId' => $rpId,
	'timeout' => 60000,
	'userVerification' => 'preferred',
]);
