<?php
/*
 * passkey_register_challenge.php
 * Liefert die Optionen für navigator.credentials.create().
 * Voraussetzung: der User ist bereits per Nickname/Passwort im Chat eingeloggt
 * (gleiche Session wie login.php / chat.php).
 */

header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once __DIR__ . '/webauthn_lib.php';

if (empty($_SESSION['login']) || empty($_SESSION['chatuser'])) {
	http_response_code(403);
	echo json_encode(['error' => 'Bitte zuerst im Chat einloggen.']);
	exit;
}

$nickname = $_SESSION['chatuser'];

$challenge = random_bytes(32);
$_SESSION['passkey_reg_challenge'] = base64url_encode($challenge);

$rpId = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']);

$existing = webauthn_get_credentials_for_user($nickname);
$excludeCredentials = array_map(function ($rec) {
	return ['type' => 'public-key', 'id' => $rec['credId']];
}, $existing);

echo json_encode([
	'challenge' => base64url_encode($challenge),
	'rp' => [
		'id'   => $rpId,
		'name' => $rpId,
	],
	'user' => [
		'id'          => base64url_encode($nickname),
		'name'        => $nickname,
		'displayName' => $nickname,
	],
	'pubKeyCredParams' => [
		['type' => 'public-key', 'alg' => -7],   // ES256
		['type' => 'public-key', 'alg' => -257], // RS256
	],
	'timeout' => 60000,
	'attestation' => 'none',
	'excludeCredentials' => $excludeCredentials,
	'authenticatorSelection' => [
		'residentKey'      => 'required',
		'requireResidentKey' => true,
		'userVerification' => 'preferred',
	],
]);
