<?php
/*
 * passkey_register_verify.php
 * Nimmt die Antwort von navigator.credentials.create() entgegen, prüft sie
 * und speichert das Credential in user/passkeys.txt.
 */

header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once __DIR__ . '/webauthn_lib.php';

if (empty($_SESSION['login']) || empty($_SESSION['chatuser'])) {
	http_response_code(403);
	echo json_encode(['error' => 'Bitte zuerst im Chat einloggen.']);
	exit;
}

if (empty($_SESSION['passkey_reg_challenge'])) {
	http_response_code(400);
	echo json_encode(['error' => 'Keine offene Registrierungs-Anfrage. Bitte erneut versuchen.']);
	exit;
}

$nickname = $_SESSION['chatuser'];

$body = json_decode(file_get_contents('php://input'), true);
if (!$body || !isset($body['rawId'], $body['response']['clientDataJSON'], $body['response']['attestationObject'])) {
	http_response_code(400);
	echo json_encode(['error' => 'Ungültige Anfrage.']);
	exit;
}

$expectedRpId = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']);
$expectedOrigin = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];

try {
	$clientDataJSON = base64url_decode($body['response']['clientDataJSON']);
	$attestationObject = base64url_decode($body['response']['attestationObject']);
	$credId = base64url_decode($body['rawId']);

	$clientData = json_decode($clientDataJSON, true);

	if (!$clientData || ($clientData['type'] ?? '') !== 'webauthn.create') {
		throw new Exception('Falscher Typ in clientDataJSON.');
	}
	if (($clientData['challenge'] ?? '') !== $_SESSION['passkey_reg_challenge']) {
		throw new Exception('Challenge stimmt nicht überein.');
	}
	if (rtrim($clientData['origin'] ?? '', '/') !== rtrim($expectedOrigin, '/')) {
		throw new Exception('Origin stimmt nicht überein.');
	}

	$offset = 0;
	$attObj = cbor_decode($attestationObject, $offset);
	$authData = $attObj['authData'] ?? null;
	if ($authData === null) {
		throw new Exception('authData fehlt im attestationObject.');
	}

	$parsed = webauthn_parse_auth_data($authData);

	if (!$parsed['at'] || !isset($parsed['credentialId'], $parsed['credentialPublicKey'])) {
		throw new Exception('Keine Credential-Daten in authData.');
	}

	$expectedRpIdHash = hash('sha256', $expectedRpId, true);
	if ($parsed['rpIdHash'] !== $expectedRpIdHash) {
		throw new Exception('RP-ID-Hash stimmt nicht überein.');
	}
	if (!$parsed['up']) {
		throw new Exception('User-Presence-Flag fehlt.');
	}

	// Hinweis: Attestation-Statement (Vertrauenskette zum Hersteller) wird hier
	// bewusst nicht geprüft - Standardverhalten bei attestation:"none", üblich
	// und ausreichend für Passkeys (synced credentials liefern ohnehin meist
	// keine verwertbare Hardware-Attestation).

	webauthn_store_credential($nickname, $parsed['credentialId'], $parsed['credentialPublicKey'], $parsed['signCount']);

	unset($_SESSION['passkey_reg_challenge']);
	echo json_encode(['success' => true]);

} catch (Exception $e) {
	unset($_SESSION['passkey_reg_challenge']);
	http_response_code(400);
	echo json_encode(['error' => 'Passkey konnte nicht registriert werden: ' . $e->getMessage()]);
}
