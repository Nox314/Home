<?php
/*
 * passkey_setup.php
 * Seite zum Einrichten eines Passkeys für den aktuell eingeloggten Chat-User.
 * Von chat.php/Profil aus verlinken, z.B.: <a href="passkey_setup.php">Passkey einrichten</a>
 */

if (!isset($_SESSION)) { session_start(); }

if (empty($_SESSION['login']) || empty($_SESSION['chatuser'])) {
	header('Location: login.php');
	exit;
}

$nickname = htmlspecialchars($_SESSION['chatuser']);
?>
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<title>Passkey einrichten</title>
<style>
	body {
		font-family: -apple-system, system-ui, sans-serif;
		max-width: 30em;
		margin: 2em auto;
		padding: 0 1em;
		line-height: 1.5;
	}
	button {
		font-size: 1.1em;
		padding: .75em 1.25em;
		border-radius: .5em;
		border: 1px solid #888;
		background: #f5f5f5;
		cursor: pointer;
		min-height: 44px; /* iOS-Mindestgröße für Touch-Ziele */
	}
	button:focus-visible {
		outline: 3px solid #06c;
		outline-offset: 2px;
	}
	#passkey_status {
		margin-top: 1em;
		min-height: 1.5em;
	}
	.back_btn {
		background: none;
		border: none;
		padding: .5em 0;
		font-size: 1em;
		color: #06c;
		min-height: 44px;
	}
</style>
</head>
<body>

<h1>Passkey einrichten</h1>

<p>Angemeldet als <strong><?php echo $nickname; ?></strong>.</p>

<p>Mit einem Passkey kannst Du Dich künftig per Face&nbsp;ID, Touch&nbsp;ID oder Geräte-PIN einloggen -
ganz ohne Passwort einzugeben.</p>

<p>
	<button type="button" id="passkey_register_btn">🔑 Passkey jetzt einrichten</button>
</p>

<p id="passkey_status" role="status" aria-live="polite"></p>

<p><button type="button" class="back_btn" onclick="history.back()">&larr; Zurück</button></p>

<script src="passkey.js"></script>
</body>
</html>