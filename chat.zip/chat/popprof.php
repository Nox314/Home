<?php
header('Content-type: text/html; charset=utf-8');

include("chat_config.php");


if (isset($stil) && $stil <> 0) {
        $s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} elseif (isset($default_skin)) {
	$s = $default_skin;
} else {
	// $s = $default_skin;
	$s = 10;
}


// Sprache abfragen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
      $lang = $languages[0];
}
$lang = (isset($languages) && is_array($languages) && in_array($lang, $languages)) ? $lang : "de";

$lang_file = 'lang'.strtoupper($lang).'_inc.php';

if (file_exists($lang_file)) {
	include ($lang_file);
}



$profile_file = "";
if (isset($_REQUEST["profil"])) $profile_file = htmlspecialchars($_REQUEST["profil"]);

$verzeichnis = __DIR__ . '/profile'; // Pfad zum Verzeichnis
// $pro_file = $profile_file; // Variable, die geprüft werden soll

// Prüfen, ob das Verzeichnis existiert
if (!is_dir($verzeichnis)) {
    exit('Verzeichnis nicht gefunden');
}

// Alle Dateien einlesen, Endungen entfernen und .htaccess ausschließen
$files = [];
foreach (scandir($verzeichnis) as $file) {
    if ($file === '.' || $file === '..' || $file === '.htaccess') {
        continue;
    }
    $files[] = pathinfo($file, PATHINFO_FILENAME);
}

// Prüfen, ob die Variable $pro_file im Array existiert
if (!in_array($profile_file, $files)) {
    exit('Kein Zugriff');
}
?>


<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
<title>Profil von <?php echo $profile_file; ?></title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" >
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" >
<link rel="stylesheet" type="text/css" media="screen" href="chatcss<?php echo $s; ?>.php" >

<style>

#pb {
    margin: .5em 0;
    max-width: 200px !important;
    max-height: 200px;
	object-fit: contain;
}

img#fem, img#masc {height:32px;width:auto !important;}
body {min-width:auto;overflow: hidden;}
@supports not (-moz-appearance:none) { /* damit dunkle Firefox-Themes die Skins nicht zerschießen */
	@media (prefers-color-scheme: dark) {
		html{background:#fff !important;filter:invert(1)}
		body{background:transparent !important;}
		p {filter:invert(0);}
		img {filter:invert(1);}
			}
}

<?php 
if ($s == 4 || $s == 11 ) {
	echo'
	@media (prefers-color-scheme: dark) {
		p {filter:invert(1);}
		img {filter:invert(0);}
	}
	';	
}
?>

body:after {opacity:.2;animation:none;top:0;}

body:before {display:none;}


<?php if ($s == 11 || $s == 4 || $s == 9): ?>
p {color:#fff !important; }
a {color:#aaf !important; }
<?php endif; ?>

<?= $s == 7 ? 'html {background:none;}' : '' ?>


</style>


<?php
if ($s == 8 && file_exists('popprof_inc.php')) {
	include ('popprof_inc.php');
}
?>


<script>
	function kp(e){if (!e) e=window.event;if (e.keyCode==27){self.close();}}window.onkeypress=kp;		
</script>


</head>
<body onkeydown="kp()" onload="focus()">
<p id="profil">


<?php
if (isset ($reg_only_viewprof) && $reg_only_viewprof !== false) {
	session_start();

	if (isset($_SESSION['chatuser'])) {
		$nickname= $_SESSION['chatuser'];
	}

	$in_regdb = false;
	// nur registrierte User
	if (file_exists("user/user.txt")) {
		$d1 = file("user/user.txt");
		foreach ($d1 as $c) {
			$part1 = explode("****",$c);
			if ($part1[0] == $nickname) {
				$in_regdb = true;
			}
		}
	}

	if ($in_regdb !== true) {
		echo '
			<div style="margin:1em">	
		<p>Nur registrierte User dürfen Profile anschauen.</p>
		</div>
		
		
		<p style="position:fixed; bottom: 1em;right:1em"><a style="color:#444;text-decoration:none;	text-shadow:.6px  .6px .6px white,.6px -.6px .6px white,-.6px  .6px .6px white,-.6px -.6px .6px white;font-size:2em; opacity:1" href="javascript:self.close()">X</a>
		
		';
		
		exit;
	}
}


$zeile ="";


include("linker.php");


if(file_exists("profile/$profile_file")) {

    $lines = file("profile/$profile_file");

    $profiletime = filemtime("profile/$profile_file");
    $dt7 = date("(d.m.y H:i \U\h\\r) ", $profiletime);

    for($i=1;$i<count($lines);$i++) {
       // leere nicht anzeigen
       if (trim($lines[$i]) != "Hobbys:&nbsp;"
        && trim($lines[$i]) != "kein Bild &nbsp;"
        && trim($lines[$i]) != "&nbsp;"
        && trim($lines[$i]) != ""
        && trim($lines[$i]) != "Geschlecht:&nbsp;"
        && trim($lines[$i]) != "Alter:&nbsp;"
        && trim($lines[$i]) != "Wohnort:&nbsp;"
        && trim($lines[$i]) != "Sternzeichen:&nbsp;"
        && trim($lines[$i]) != "E-Mail:&nbsp;"
        && trim($lines[$i]) != "Bemerkung:&nbsp;"
        // && trim($lines[$i]) != "wei√ü nicht"
       ) {
           $zeile = $zeile." <br >".trim($lines[$i]);
       }
	   
	   if (strpos($zeile,'männlich') !== false) {
		   $gendermod = "einer unserer coolen Moderatoren.";
		   $genderadmin = "Administrator.";
	   } elseif (strpos($zeile,'weiblich') !== false) {
		   $gendermod = "eine unserer netten Modinen.";
		   $genderadmin = "Admina.";
	   } else {
		   $gendermod = "Mod.";	   	
		   $genderadmin = "Admin.";
	   }
		   
       $zeile = str_replace("E-Mail:&nbsp;","E-Mail: ",$zeile); // das ist noetig wg. auto-E-Mail
       $zeile = str_replace("männlich"," männlich ",$zeile); // das ist noetig wg. smiley_create
       $zeile = str_replace("weiblich"," weiblich ",$zeile); // das ist noetig wg. smiley_create
    }

    if ($zeile == "") {

	    $msg = $profile_file." hat kein Profil angelegt.";

          if(file_exists("profile/$profile_file")) {
          }

    } else {
          $msg = '<b>Profil von '.$profile_file.':</b> '.$dt7.$zeile;
    }

} else {
    $msg = $profile_file." hat kein Profil angelegt.";
}

$msg_explode[1] = linker($msg);

$msg_explode[1] = str_replace("https://  ","",$msg_explode[1]); // Paranoia
$msg_explode[1] = str_replace("img alt","img id='pb' alt",$msg_explode[1]);

if (file_exists("smiley_create.php")) include("smiley_create.php");

if (strpos($msg_explode[1],"Grafik") === false) {
	if (file_exists('profile/'.$profile_file.'.jpg')) {
		$pb = 'profile/'.$profile_file.'.jpg';
	} elseif (file_exists('profile/'.$profile_file.'.gif')) {
		$pb = 'profile/'.$profile_file.'.gif';		
	} 
	
	if (isset ($pb)) {
		$hilfs_pb = "<br> <img id='pb' alt='Grafik' src=$pb style='max-width:250px;'>  &nbsp;<br>";
		$msg_explode[1] = str_replace(" Uhr) ",$hilfs_pb,$msg_explode[1]);
		
	}
}


echo $msg_explode[1];


$mods = file_exists("admin/mods.txt") ? file("admin/mods.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
if (in_array($profile_file, $mods, true)) { echo '<p>… übrigens: '.$profile_file.' ist '.$gendermod.'</p>'; }

$admin = file_exists("admin/admins.txt") ? file("admin/admins.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
if (in_array($profile_file, $admin, true) || (isset($admins) && in_array($profile_file, $admins) && isset($superadmin) && !in_array($profile_file, $superadmin))) { echo '<p>'.$profile_file.' ist '.$genderadmin.'</p>'; }

?>

<?php if ($s != 7): ?>
	<p style="position:fixed; bottom: 1em;right:1em"><a style="color:#444;text-decoration:none;	text-shadow:.6px  .6px .6px white,.6px -.6px .6px white,-.6px  .6px .6px white,-.6px -.6px .6px white;font-size:2em; opacity:1" href="javascript:self.close()">X</a></p>
<?php endif; ?>

<script>
	window.addEventListener('load', function() {
		var targetHeight = document.body.scrollHeight + 100;
		var startHeight = window.outerHeight;
		var duration = 300;
		var startTime = performance.now();

		function animate(currentTime) {
			var elapsed = currentTime - startTime;
			var progress = Math.min(elapsed / duration, 1);

			// Ease-out cubic
			var eased = 1 - Math.pow(1 - progress, 3);

			window.resizeTo(window.outerWidth, startHeight + (targetHeight - startHeight) * eased);

			if (progress < 1) { requestAnimationFrame(animate); }
		}

		requestAnimationFrame(animate);
	});
</script>

</body>
</html>