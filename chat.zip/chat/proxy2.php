<?php
header('Content-Type: text/plain');

include_once('chat_config.php');
if (!isset($standard)) {$standard = "Standard";}

echo file_get_contents('user/ip_'.$standard.'.txt');
?>
