<?php
$standard = $_GET['standard'] ?? '';
$standard = preg_replace('/[^a-z0-9_-]/i', '', $standard);

$file = __DIR__ . '/user/ip_' . $standard . '.txt';

header('Content-Type: text/plain; charset=utf-8');

if (!is_file($file)) {
	echo 1;
	exit;
}

$lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
echo max(1, count($lines));
