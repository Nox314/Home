﻿
Der Chat von webdesign.weisshart.de


                            |         |          _)
             \ \  \   / _ \ __ \   _` |  _ \  __| |  _` | __ \
              \ \  \ /  __/ |   | (   |  __/\__ \ | (   | |   |
               \_/\_/ \___|_.__/ \__,_|\___|____/_|\__, |_|  _|  _)
                                                   |___/
                      _)           |                |             |
        \ \  \   / _ \ |  __|  __| __ \   _` |  __| __|        _` |  _ \
         \ \  \ /  __/ |\__ \\__ \ | | | (   | |    |         (   |  __/
          \_/\_/ \___|_|____/____/_| |_|\__,_|_|   \__|  _)  \__,_|\___|


                                                  https://webdesign.weisshart.de
###############################################################################

Mit jeglicher Verwendung des Scripts anerkennen Sie folgende Bedingungen:

webdesign weisshart ist nicht für den Einsatz des Scripts verantwortlich. 
Alle für den Betrieb des Scripts zutreffenden rechtlichen Obliegenheiten
sind allein in der Verantwortung des Betreibers.

Sie können dieses Script auf nicht kommerziellen Seiten kostenlos benutzen,
solange Sie den Link auf webdesign.weisshart.de
inclusive umgebendem Text und dem Kaufen-Button unverändert, intakt und sichtbar lassen.
Diese Einschränkung gilt für jegliche Verwendung, also z.B. auch in Intranets.

Für den Einsatz auf einer kommerziellen Seite ist eine gewerbliche Lizenz erforderlich.
Dies gilt auch und insbesondere für Agenturen und Webdesigner, die den Chat auf Kundenseiten einsetzen.

Kommerziell ist jede Seite mit Gewinnerzielungsabsicht.
Entscheidend ist die Absicht, nicht der realisierte Gewinn.
Werbung auf der Seite deutet in aller Regel auf Gewinnerzielungsabsicht.

Wenn Sie das Script auf einer kommerziellen Seite einsetzen wollen,
und/oder den Link auf webdesign.weisshart.de entfernen wollen,
können Sie hier eine Lizenz erwerben:
https://webdesign.weisshart.de/chat-lizenz.php


Für evl. auftretende Schäden, die durch die Verwendung dieses Scripts entstehen,
kann webdesign weisshart nicht haftbar gemacht werden.
Die Benutzung erfolgt auf eigene Gefahr des Anwenders.
Klären Sie insbesondere vorab, ob Ihr Webhoster den Betrieb des Scripts zulässt.


Der Original-Quelltext darf nicht weiter gegeben werden, und nicht zum Download angeboten werden.
Ein Download ist nur von der Seite des Anbieters erlaubt: https://webdesign.weisshart.de/chat.php


Der Verkauf dieses Scripts, auch in modifizierter Form, ist ohne vorherige
Absprache ausdrücklich untersagt!

Es ist ausdrücklich verboten, das Script zum Gelderwerb einzusetzen,
z. B. durch den Betrieb eines kostenpflichtigen Chats.
Bitte fragen Sie, bevor Sie versuchen, mit dem Script Geld zu verdienen.



#############################################

Voraussetzungen serverseitig:
Der Server muss PHP ab Version 7.4 unterstützen.
Ältere Versionen von PHP (mindestens 4.3.0) ermöglichen keinen Dateiupload und keine Profile.
Für den Uplaod von Dateien muss die GD-Library in PHP geladen sein.
Eine Datenbank ist nicht erforderlich.
Wichtig! Der Server muss .htaccess Dateien verarbeiten, um den Zugriff auf verschiedene Bereiche zu beschränken
Andernfalls kann der Chat auf diesem Server nicht betrieben werden.

Voraussetzungen clientseitig:
Javascript muss beim Benutzer verfügbar und aktiviert sein.
Cookies werden für verschiedene Funktionen gesetzt, und müssen beim Benutzer zugelassen sein.
Der Referrer darf im Browser des Benutzers nicht geblockt sein.


Voraussetzungen adminseitig:
ACHTUNG!
Wenn du eine der obigen Voraussetzungen nicht verstanden hast,
oder nicht weisst, was ein FTP Programm und CHMOD ist,
dann solltest du das Script besser nicht installieren ;-)


#############################################
Installation:

1. zip entpacken (NICHT direkt auf dem Server entpacken, sondern lokal!)
   Darauf achten, dass die Ordnerstruktur (Unterverzeichnisse) beim Entpacken beibehalten wird.
   
2. Alles in ein eigenes Verzeichnis namens /chat auf den Server uploaden.

3. Aufruf mit http://www.Pfad_zum_Verzeichnis/login.php
   z.B. http://www.meineSeite.de/chat/login.php
   Die erste Anmeldung kann auch als Gast erfolgen.

   Falls du im Chat nichts schreiben kannst (und nur dann!):
   CHMOD für die Ordner "rooms", "user" "admin", "upload", "tn_upload", "smileys1", "smileys2", "smileys3", "sounds" und "logs": 777
   CHMOD für die Datei Standard im Ordner "rooms" 666
   CHMOD für die Datei clear.txt (im Stammordner) 666
   CHMOD für die Datei user.txt im Ordner "user" 666
   CHMOD für die Datei flood.txt im Ordner "user" 666

4. Wenn geschrieben werden kann (und ERST DANN):
   Anpassung: die Datei chat_config.php mit einem Texteditor bearbeiten.
   dort erst einmal die Namen für die Admins festlegen: $admins = array( ...
   ACHTUNG! Der Editor von Windows macht die chat_config.php kaputt. Nach dem Login erscheint dann nur eine weiße Seite,
   oder allerhand Doppelpunkte auf der Seite.
   In diesem Fall bitte einen anderen Editor verwenden. Ich empfehle Notepad++ http://notepad-plus-plus.org/
   
   Hinweis:
   Alle anderen Dateien nicht ändern! Mit unbedachten Änderungen kann der Chat schnell kaputt geändert werden!

5. WICHTIG! Die Admin Namen schützen:
   In der Konfigurationsdatei chat_config.php sind einige Admin-Nicks vorbelegt. Diese Admin-Nicks anpassen.
   Jetzt jeden Admin-Nick mit einem eigenen Passwort registrieren (auch nicht benutzte Admin-Nicks!).
   Dazu mit dem Admin-Nick einloggen, und dann im Chat den Button "Zur Registrierung".

   Hinweise:
   - Erkennbar ist der Admin-Status in der Eingabezeile an einem angehängten [A] nach dem Nick
   - Die Hilfe für die Admin-Befehle wird nur angezeigt, wenn du Admin bist!

6. WICHTIG! Schütze die Ordner /admin und /logs per .htaccess!
   Für den Ordner /admin ist bereits ein Passwortschutz eingerichtet. 
   ACHTUNG! Dort unbedingt die Zugangsdaten ändern! Zumindest das Passwort in der Datei /admin/.htpasswd 
   Siehe z. B. https://www.entwicklertools.de/tools/htaccess/htpasswd-generator/
   
7. Registrierungen verwalten:
   Für Verwaltungsaufgaben steht dem Admin im Chatfenster ein Button "A" zur Verfügung (rechts oben).
   Um diesen Adminbereich aufzurufen, brauchst du das im Schritt 6 von dir geänderte Passwort.
   
8. Weitere Konfigurationsmöglichkeiten sind in der Datei chat_config.php beschrieben.
   Anpassungen am besten immer nur einen Schritt, und dann das Ergebnis testen.
   Bitte beachte den Hinweis am Ende der chat_config.php

9.  Anpassung von Farben usw.: chatcss1.php bis chatcss13.php - aber nur, wenn Du etwas CSS kannst!
   - chatcss2:  Skin Boxes
   - chatcss3:  Skin Web2
   - chatcss4:  Skin Black
   - chatcss5:  Skin Stage
   - chatcss6:  Skin Flowers
   - chatcss7:  Skin Mobil - wird auf Smartphones automtisch verwendet
   - chatcss8:  Skin Firebox
   - chatcss10: Skin Sky
   - chatcss11: Skin Invers - optimiert auf Lesbarkeit
   - chatcss12: Skin BF-Linear - wie Invers, jedoch zusätzlich optimiert für starke Schriftvergrößerung
   - chatcss13: Skin Messenger
   - chatcss14: Skin Foto

10. Upload von mp3 BITTE GENAU LESEN UND BEACHTEN!

	Wenn du mp3 Upload im Chat erlauben willst, dann beachte bitte:

	Für die Veröffentlichung von urheberrechtlich geschützten Werken ist VORAB eine Lizenz zu erwerben.
	In Deutschland ist hierfür die GEMA zuständig.
	https://www.gema.de/


	Nachdem du die Lizenz erworben hast, kannst du mp3 Uploads in der chat_config.php freischalten:

	$mp3allow = "xxx";             

	an Stelle von "xxx" schreibe:
	"alle" - Alle dürfen in allen Räumen mp3 hochladen
	"clean" - mp3 hochladen erlaubt in privaten Räumen, Admins in allen Räumen
	"admins" - nur Admins dürfen mp3 hochladen (in allen Räumen)
	"" - kein mp3 Uplodad
	
	Tipp: Die Einstellung "clean" und "admins" ermöglicht dem Admin eine bessere Kontrolle über die hochgeladenen mp3.
	

	Nachmals:
	Für die korrekte Lizenzierung von mp3 Uploads ist ausschließlich der Chatbetreiber verantwortlich!
	


#############################


HINWEIS: vor du fragst: "wie geht ...." lies bitte erst mal
- diese readme.txt
- die Kommentare in der chat_config.php
- die Hilfe (Link im Chat)
- die FAQ: https://webdesign.weisshart.de/chat-faq.php

Support:
https://forum.weisshart.de

- die neueste Version? -> https://webdesign.weisshart.de/chat.php


#############################
Zusätzliche Funktionen - nur für Admins mit guten HTML/PHP/Javscript Kenntnissen:
Diese Funktionen erst dann installieren, wenn der Chat läuft!
Und wenn du glaubst, "relative Adressierung" spart Briefporto,
dann solltest du die Installation dieser Funktionen eventuell nochmal überdenken ;-)

ACHTUNG! Für diese Funktionen gibt es keinerlei Support.
Ich freue mich aber, wenn mir bugs gemeldet werden.



###### offline Schaltung #####
- Eingabe von /offline schaltet den Chat offline
- in der chat_config.php kannst du einstellen, ob bei offline Schaltung auch private Räume offline geschaltet werden.
- wenn der Chat offline ist, kannst du in den Raum "Offline" zusätzliche Informationen eingeben,
  die dann den Besuchern angezeigt werden.
- wieder online schalten: Löschen des Raumes Offline, z.B. durch Eingabe von /del Offline
##############################




######## logfiles ############
- Wenn in der chat_config.php $logfile = "on"; gesetzt ist, werden alte Nachrichten im Ordner /logs gespeichert.
- WICHTIG! den Ordner /logs per .htaccess schützen
- Ein Programm zum Anzeigen der Logfiles gibt es für Inhaber einer kommerziellen Lizenz.
- mit der Druckfunktion deines Browsers kannst du die Logfiles ausdrucken
- Achtung! Logfiles können sehr schnell sehr groß werden, und viel Speicherplatz belegen.
- Logfiles werden nach 180 Tagen automatisch gelöscht.
##############################


##### user online Anzeige ####
1.   Wenn die Seiten mit der user online Anzeige auf dem gleichen Server liegen, auf dem der Chat läuft:

1.1. Nur die Gesamtzahl der user anzeigen:

     Hierfür sind die beiden AJAX Dateien anw_anz.js und anw_anz.php zuständig.

     Mit diesem Code wird die Anzahl angezeigt:
     <span id="anw"></span>
     und ans Ende der Datei (unmittelbar vor </body>:
     <script type="text/javascript" src ="pfad_zum_Chat/anw_anz.js"></script>

     User in privaten Räumen können wahlweise angezeigt werden oder nicht.
     Dazu in der anw_anz.php die Zeile   && strpos($file,"_pr") === false weg-/oder entkommentieren.
     
     Achtung! unter Umständen muss die Datei anw_anz.js angepasst werden:
     Die Zeile
         loadurl2('http://' + document.domain + '/chat/anw_anz.php');
     durch den kompletten Pfad ersetzen.


1.2. user pro Raum namentlich auflisten:

     Aufruf mit http://www.Pfad_zum_Chat-Verzeichnis/whoson.php
     HINWEIS: Dies kann jeder sehen, der die Adresse aufruft.
     Wenn du das nicht willst: Entweder die Datei whoson.php per .htaccess schützen, oder die Datei whoson.php löschen 


1.3. die obige Anzeige in einem popup:
     ACHTUNG! hier wird unterstellt, dass die Datei mit dem Aufruf des popup eine Verzeichnisebene höher steht als der Chat selbst.
     die Datei whoson.php muss also vom Verzeichnis /chat ins Verzeichnis ./ verschoben werden!
     <a  title="Wer ist online?" href="whoson.php" target="detail" onclick="javascript:window.open('','detail','width=175, height=120, toolbar=no, location=no, menubar=no, scrollbars=yes, status=no, resizable=yes, dependent=no')">die Anzeige der aktuell anwesenden Besucher in einem popup</a>



#################################


####### Säuberungstools #########
Die Datei clean_user.php löscht automatisch Registrierungen, die eine bestimmte Zeit inaktiv waren.
Die Datei cleanup_profile.php löscht Profile, die aus der Registrierungsdatei gelöscht wurden
Die Datei cleanup_verified.php löscht Verifizierte User, die aus der Registrierungsdatei gelöscht wurden

Es empfielt sich, diese Dateien regelmäßig, z.B. täglich mittels Cronjob aufzurufen.
#################################



