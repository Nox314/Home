<?php

session_start();

// Überprüfe, ob die Session noch existiert
if (!isset($_SESSION['access_token'])) {
	die("Fehler: Ungültiger Zugriff.");
}

// Freigabe einmalig per GET-Token aus chat.php, danach in der Session merken
if (isset($_GET['token']) && hash_equals($_SESSION['access_token'], $_GET['token'])) {
	$_SESSION['reg_allowed'] = true;
}

if (empty($_SESSION['reg_allowed'])) {
	die("Du hast keinen Zugriff.");
}

// CSRF-Token für das Formular
if (empty($_SESSION['reg_csrf'])) {
	$_SESSION['reg_csrf'] = bin2hex(random_bytes(16));
}


setcookie("correct_logout","1",time()+86400*30);

$path = '../wartung/sperren.php';
if (file_exists($path)) {require $path; }

if (file_exists("redir_unwanted.php")) {
	include "redir_unwanted.php";
}	

if (file_exists("tor_test.php")) {
	include("tor_test.php");
} elseif (file_exists("stopforumspam.php")) {
	include("stopforumspam.php");
}

// Chat zeitabhaengig offline:
if (file_exists('admin/set_offline.txt') && (!isset($ab_offen) || !isset($ab_offen))){
	$times_online = file_get_contents('admin/set_offline.txt');

	$offen = explode('-',$times_online);
	$ab_offen = trim($offen[0]);
	$bis_offen = trim($offen[1]);
}

// $start = microtime(true);


// wg. Umlauten:
// https://stackoverflow.com/questions/25729900/ucfirst-doesnt-work-on-non-english-characters
function myucfirst($str) {
	$fc = mb_strtoupper(mb_substr($str, 0, 1));
	return $fc.mb_substr($str, 1);
}


if(isset($_SESSION['bg_img'])) {
	$bg = $_SESSION['bg_img'];
} 

elseif (is_dir("bg_img")) {  // bg_img nicht in DL
	
	foreach (scandir("bg_img") as $file) {
		if ($file === ".." or $file === ".") continue;

		if (strpos($file,'winter') === false && strpos($file,'autumn') === false) {
			$bg_array[] = 'bg_img/'.$file;
		}
	}

	if (isset($bg_array)) {
		$count = count($bg_array);
		$bg = $bg_array[rand(1,$count) -1]; // -1, weil array mit 0 beginnt


		// wenn bg nur täglich wechsel soll, die folgenden 3 Zeilen entkommentieren:
		
		// $daynum = date('z') + 1;
		// $r = fmod($daynum,$count) + 1;
		// $bg = $bg_array[$r];
	}
} 


else {
	$bg = 'img/helena-lopes-e3OUQGT9bWU-unsplash_1.jpg';		
}
$_SESSION["bg_img"] = $bg;

// $end = microtime(true);

// echo $diff = ($end - $start) *1000;

// fastreg
header('Content-type: text/html; charset=utf-8');

include("chat_config.php");


// Keine reg wenn offline
if (file_exists("rooms/Offline")) {
	echo "<p>Dieser Chatraum ist vorübergehend geschlossen. Registrierung nur während der Öffnungszeiten möglich.<br>This chat room is temporarily closed.</p>";
	exit();
}


// Chat zeitabhaengig offline:
if (isset($ab_offen) && isset($bis_offen)) {
	$uhrzeit = date("H:i");

	if ($ab_offen < $bis_offen) {
		if ($uhrzeit < $ab_offen || $uhrzeit >= $bis_offen) {
			echo "<p>Dieser Chatraum ist vorübergehend geschlossen. Registrierung nur während der Öffnungszeiten möglich.<br>This chat room is temporarily closed.</p>";
			exit();
		}
	} else {
		if ($uhrzeit < $ab_offen && $uhrzeit >= $bis_offen) {
			echo "<p>Dieser Chatraum ist vorübergehend geschlossen. Registrierung nur während der Öffnungszeiten möglich.<br>This chat room is temporarily closed.</p>";
			exit();
		}
	}		
}

if (!isset($reg_block_time)) {$reg_block_time = 240;}


// Sprache abfragen und lang-file includen:
if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = $languages[0];
}
$lang = (isset($languages) && is_array($languages) && in_array($lang, $languages)) ? $lang : "de";

$lang_file = 'lang'.strtoupper($lang).'_inc.php';
if (file_exists($lang_file)) {
	include ($lang_file);
}


if (!isset($mailmust)) $mailmust = false;

if (isset($stil) && $stil <> 0) {
	$s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
	$s = $default_skin;
}

if (isset($_COOKIE["schrift"])) {
	$schrift= $_COOKIE["schrift"];
}


$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname(htmlspecialchars($_SERVER['PHP_SELF'])), '/\\');
$extra = 'login.php';


$angemeldet = "user/user.txt";
$lines = file($angemeldet);
$meldung = 	_LOGIN_FORM; 
$meldung1 = _LOGIN_FORM1;

$closed = 0;


$alluser[0] = ""; // sollte jemand alle User löschen
// Prüfung ob Nick in der reg-DB:
foreach ($lines as $line_num => $line) {
	$user = explode("****",$line);
	$alluser[] = strtolower($user[0]);
}

if (file_exists("user_anw.txt")) {
	$user = file("user_anw.txt");
	$user1 = implode("",$user);

	if (isset($maxuser) && $user1 >= $maxuser) {
		echo "<p>Maximale Anzahl user erreicht - please try later</p>";
		exit;
	}
}


// nur alle 300 Sek ein reg zulassen
$reg_closed = false;
if (isset($reg_block_time)) {
	$rbt = $reg_block_time;
} else {
	$rbt = 0;
}
	
if (file_exists("user/user_reg.txt")) {
	$prev_reg = filemtime("user/user_reg.txt");
	$frei = time() - $prev_reg;
	if ($frei < $rbt) {
		$closed = ceil(($rbt-$frei));
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM10.'<span aria-live="assertive" aria-relevant="all"  id="countdwn"></span></span>';
		$reg_closed = true;
	}
}


$_SESSION['login'] = 0;

	
if (isset($_POST['anname'])) {  // wenn Registrierung abgeschickt

	if (!isset($_POST['reg_csrf']) || !hash_equals($_SESSION['reg_csrf'], $_POST['reg_csrf'])) {
		die("Du hast keinen Zugriff.");
	}

if ($nickgross === true) {
	$anname = myucfirst(trim($_POST['anname'], " \t\n\r\0\x0B\xC2\xA0"));
} else {
	$anname = trim($_POST['anname'], " \t\n\r\0\x0B\xC2\xA0");
}
	
	
if (trim($_POST["wdwchatemail"]) != "") {
	echo "<p>Sie haben ein Feld ausgefüllt, das leer bleiben muss. Bitte gehen Sie mit der Zurück-Funktion Ihres Browsers zurück. Eventuell müssen Sie im Browser gespeicherte Passwörter löschen.</p>";
	exit;
}

if (isset($_POST['date']) && is_numeric($_POST['date'])) {
	$posted = intval($_POST['date']);
	$sendezeit = (time() - $posted);
	if ($sendezeit < 5 || $sendezeit > 300) {
		die("no bots here - take it easy");
	}
} 
// keine Registrierung fuer gebannte User
if (file_exists("user/ban.txt")) {
	$banned = file("user/ban.txt");
	foreach ($banned as $c) {
		$part1 = explode("****",$c);
		$part2 = explode("++++",$part1[1]);
		if (strlen($c) > 1 && $part2[0] > time()) {
			$rip = $_SERVER['REMOTE_ADDR'];

			if ($part1[0] == $anname
				|| (trim($rip) == trim($part2[1]) )
				)  {
				echo "You're banished";
				exit();
			}
		}
	}
}
// keine Registrierung fuer muzzled User
if (file_exists("user/maulkorb.txt")) {
	$banned = file("user/maulkorb.txt");
	foreach ($banned as $c) {
		$part1 = explode("****",$c);
		$part2 = explode("++++",$part1[1]);
		if (strlen($c) > 1 && $part2[0] > time()) {
			$rip = $_SERVER['REMOTE_ADDR'];

			if ($part1[0] == $anname
				|| (trim($rip) == trim($part2[1]) )
			)  {
				echo "You're muzzled";
				exit();
			}
		}
	}
}

if (isset($_POST['usermail'])) { 
	$usermail = htmlspecialchars($_POST['usermail']); 
} 
if (strlen($usermail) < 1){
	$usermail = "mail_not_set";
} 

$forbidden = false;
$regnick = strtolower($anname);
foreach ( $nicknotallowed as $key => $value ) {
	if (trim($regnick) == trim($value)) {
		$forbidden = true;
		break;
	}
}


// // nur alle 300 Sek ein reg von der gleichen IP zulassen
// $reg_closed = false;
//
// if (file_exists("user/user_reg.txt")) {
// 	$prev_reg = file("user/user_reg.txt");
// 	foreach ($prev_reg as $c) {
// 		$part = explode("****",$c);
// 		$frei = time() - $part[0];
//
// 		//		echo $part[0].'---'.$part[1].'---'.$frei;
// 		if (strlen($c) > 1 && $frei < 300) {
// 			$rip = $_SERVER['REMOTE_ADDR'];
//
// 			$closed = ceil((300-$frei));
//
//
// 			if (trim($rip) == trim($part[1])) {
// 		        $meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM10.'<span aria-live="assertive" aria-relevant="all"  id="countdwn"></span></span>';
//
// 				$reg_closed = true;
// 			}
// 		}
// 	}
// }
	
	

	
if (in_array(strtolower($anname), $alluser) && strlen($anname) >= 1)  { // wenn Nick schon registriert
	$meldung1 = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM2.'</span>';

	//      } elseif (in_array(strtolower($anname), $nicknotallowed))  { // andere verbotene Nicks (chat_config.php)
		//            $meldung1 = "<span style='color:red;font-weight:bold;'>Dieser Nick ist nicht erlaubt!</span>";

	} elseif ($forbidden === true)  { // andere verbotene Nicks (chat_config.php) auch Substrings
		$meldung1 = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM3.'</span>';


		// nicht erlaubte Zeichen abweisen (mit chat_js abgleichen
	} elseif (preg_match("/:|;|,|\.|%|\"|<|>|\?|\/|&| |\+|\*|@|'|-/",$anname)) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._LOGIN_FORM_FORUM4.'</span>';

	} elseif (strlen($anname) < 1) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM.'</span>';

	} elseif (strlen($anname) < 3) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM1.'</span>';

	} elseif (trim($_POST['anpassword']) == trim($anname)) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM11.'</span>';

	} elseif (!isset($_POST['anpassword']) || strlen($_POST['anpassword']) < 1) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM2.'</span>';

	} elseif ($_POST['anpassword'] != $_POST['password2']) {
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM3.'</span>';



	} elseif (
	$mailmust &&
		!preg_match("/^([\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+\.)*[\w\!\#$\%\&\'\*\+\-\/\=\?\^\`{\|\}\~]+@((((([a-z0-9]{1}[a-z0-9\-]{0,62}[a-z0-9]{1})|[a-z])\.)+[a-z]{2,6})|(\d{1,3}\.){3}\d{1,3}(\:\d{1,5})?)$/i", $usermail)
	){
		$meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM4.'</span>';


	} elseif ($reg_closed === true) {
		// do nothing	        $meldung1 = '<span style="color:red;font-weight:bold;">'._REG_FORM10.'</span>';

		

	} else {
		// user.txt schreiben:
		$fp = fopen($angemeldet, "a+");
		flock($fp,LOCK_EX);
		// fputs($fp, trim($anname) . "****" . md5($_POST['anpassword']).'****'.$usermail.'****'.date("d.m.Y H:i:s"). "****1\n");
		fputs($fp, trim($anname) . "****" . password_hash($_POST['anpassword'], PASSWORD_DEFAULT).'****'.$usermail.'****'.date("d.m.Y H:i:s"). "****1\n");
		flock($fp,LOCK_UN);
		fclose($fp);

		// Session-Fixierung verhindern: ID genau einmal wechseln, nach erfolgreicher Registrierung
		session_regenerate_id(true);

		$_SESSION['login'] = 1;
		$_SESSION['chatuser'] = $anname;
			
		// jetzt festhalten, wann und von welcher IP reg.php aufgerufen wird
		$regtime = time()."****".$_SERVER['REMOTE_ADDR']."\n";

		$file7 = 'user/user_reg.txt';
						
		$lines = file($file7);
		foreach ($lines as $line_num => $line) { // aelter als 1 h loeschen
			$part = explode("****",$line);
			if ((time() - $part[0]) < 60*60) {
				$regtime .= $line;
			}
		}
			
		$open7 = fopen($file7, "w");
		fwrite($open7,$regtime); 
		fclose($open7);
			
		// backup erstellen

		// $file = 'user/user.txt';
		// $newfile = 'user/user.txt_'.time().'.bak';
		//
		// if (!copy($file, $newfile)) {
		//     // echo "Sicherung der Dateu $file schlug fehl...\n";
		// } else {
		//     // echo "Backup der Datei $file nach $newfile erfolgreich. \n";
		// }

		// Registrierungsfreigabe verbrauchen
		unset($_SESSION['reg_allowed'], $_SESSION['reg_csrf']);

		// Redirect zum Chat:
		header("Location: //$host$uri/$extra");
		exit;
	}
}



?>



 <!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="de" lang="de">

<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" >
<meta name="description" content="Der barrierefreie Chat von webdesign weisshart" >
<meta name="keywords" content="@bots: please look for keywords in document body ;-)" >
<meta name="author" content="Dipl.-Ing.(FH) F. Weisshart" >
<meta name="generator" content="notepad ;-)" >
<meta name="robots" content="index, follow" >
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes" >

<title>Der Chat von webdesign weisshart - Registrierung</title>
<link rel="icon" href="favicon.ico" >
<!-- <link rel="stylesheet" type="text/css" media="screen" href="helpcss<?php echo $s; ?>.css" > -->


<?php
if ($s != 7) {
echo '	 
<!-- <link rel="stylesheet" type="text/css" media="screen" href="helpcss'.$s.'.css" > -->
';
}
?>

<link rel="stylesheet" type="text/css" media="screen" href="login.css" >

<script src="chat_js.php"></script>

<script>
// <![CDATA[

function fuehrendeNull(wert) {
  if (wert<10) return "0" + parseInt(wert);
  else return parseInt(wert);
}

function Sekundenumwandeln(Sekundenzahl) {
 Sekundenzahl = Math.abs(Sekundenzahl)
 return   fuehrendeNull((Sekundenzahl/60)%60) + ":" + fuehrendeNull(Sekundenzahl%60);
}



var zeit = <?php echo $closed; ?>;      

function ZeitAnzeigen() {
if (document.getElementById('countdwn')) {



	if (zeit >= 1) {
		document.getElementById('countdwn').innerHTML = 'in ' + Sekundenumwandeln(zeit);
		zeit = zeit - 1;
		setTimeout("ZeitAnzeigen()", 1000);
	}
	else {
		document.getElementById('countdwn').innerHTML = '';
	}
}
}


function laden() {
//    noshowWait();
// if (!navigator.platform.match(/iPhone/)) {
// 	document.getElementById('anname').focus();
// }
}

if (navigator.cookieEnabled == true) {
      window.onload=laden;
}
// ]]>
</script>


<style>
#wdw_logo {height: 50px !important;}
body:after {
    content: "";
    position: fixed;
    top: 0;
    height: 100vh;
    left: 0;
    right: 0;
    z-index: -1;
	background: url("<?php echo $bg; ?>") center center;		
    background-size: cover;
}

h1 {
	font-size: 1.5em;
	margin: 10px auto;
	display: inline-block;
	padding: 5px 10px;
	color: white;
	background-image: linear-gradient(90deg,#7a7afb,red,yellow,green,#ca4aca);
	-webkit-background-clip: text;
	-webkit-text-fill-color: transparent;
	-webkit-text-stroke: 1px #000;
}
<?php 
if (isset($login_background)) {
	echo 'body:after{background:'.$login_background.'}';
}
?>	

/* damit dunkle Firefox-Themes die Skins nicht zerschießen */
@supports not  (-moz-appearance:none) { 
	@media (prefers-color-scheme: dark) {
		html,h1,h2{filter:invert(1)}
		body::after{filter:invert(1)}
	}
}


</style>


</head>
<body>


<!-- die folgende Zeile ist nur fuer die Demo, und kann ohne Folgen geloescht oder auch belassen werden: -->
<!-- Wer will, kann hier ein eigenes Logo einbinden -->
<?php if(file_exists("wdw_inc.php") && $s != 12 && $s != 7 ) {
	echo '<div id="logo" style="margin:auto; height:55px; max-width: 200px; padding: 5px 10px">';
	include ("wdw_inc.php"); 
	echo '</div>';
}
?>

<h1><?php echo _REG_H1; ?></h1>

<section role="main">


<?php if(file_exists("lang_switcher_inc.php")) {include("lang_switcher_inc.php");} ?>


<!-- fastreg: -->
<p class="stats">
<?php echo _TO_REG;
if (isset($create_profile) && $create_profile == "yes"){ echo ', '._TO_REG2;} 
?>
.</p>

<p class="stats">
<?php echo _REG_HINWEIS; ?>
<br ><?php echo _REG_HINWEIS1; ?>
</p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" id="reg">
<fieldset>
<legend><?php echo $meldung1; ?></legend>

<input type="hidden" name="reg_csrf" value="<?php echo htmlspecialchars($_SESSION['reg_csrf'], ENT_QUOTES, 'UTF-8'); ?>" >

<label for="anname" class="left"><?php echo _LOGIN_GUEST2; ?></label>


<input type="text" size="20" id="anname" name="anname" maxlength="20" autofocus
	value="<?php echo isset($_COOKIE['nick']) ? htmlspecialchars($_COOKIE['nick'], ENT_QUOTES, 'UTF-8') : ''; ?>"> <br>


<label for="anpassword" class="left"><?php echo _LOGIN_GUEST3; ?></label>
<input type="password" id="anpassword" name="anpassword" ><br >

<label for="password2" class="left"><?php echo _REG_FORM6; ?></label>
<input name="password2" id="password2" type="password"  ><br >


<span style="display:none">
   <label for="wdwchatemail"><?php echo _REG_FORM5; ?></label>
   <input type="text" name="wdwchatemail" id="wdwchatemail" title=" dieses Feld muss leer bleiben " ><br >
</span>



<?php
if ($mailmust) {
echo '
<label for="usermail" class="left">'._REG_FORM7.'</label>
';
}else{
echo '
<label for="usermail" class="left">'._REG_FORM8.'</label>
';
}
?>

<input type="text" size="20" id="usermail" name="usermail" maxlength="50" ><br >

<?php
  echo '<p><input name="date" type="hidden" value="', time(), '" ></p>';
?>

<input type="submit" class="right" value="<?php echo _REG_FORM9; ?>" >
</fieldset>
</form>
<?php
$file = file("user/user.txt");
echo '<p style="margin: 0.5em auto;background: #ddd;width: max-content;padding: 2px 5px;">'.count($file).' '._REG_HINWEIS2.'</p>' ;
?>
<!-- end fastreg -->





<?php
if ($_SERVER['SERVER_NAME'] == "webdesign.weisshart.de") {
   echo '
   <p  class="stats">'._REG_HINWEIS3.'</p>
   ';
}
echo '<p class="lnk"><a href="http://webdesign.weisshart.de">Chat by webdesign weisshart</a></p>';
?>

<p><a href="login.php" style="font-weight:bold;text-shadow: black 0.1em 0.1em 0.2em;color: white !important;padding-bottom:3em;background:transparent !important;text-decoration:none;"><?php echo _TO_LOGIN; ?></a></p>

</section>


<script>
// http://ichwill.net/chapter4.html

function addEvent(obj, evType, fn){
 if (obj.addEventListener){
   obj.addEventListener(evType, fn, false);
   return true;
 } else if (obj.attachEvent){
   var r = obj.attachEvent("on"+evType, fn);
   return r;
 } else {
   return false;
 }
}
addEvent(window, 'load', ZeitAnzeigen);

</script>

<?php if (file_exists("footer_inc.php")) include("footer_inc.php"); ?>

</body>
</html>