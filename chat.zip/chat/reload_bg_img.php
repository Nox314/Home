<?php
// error_reporting(E_ALL);

if (!isset($_SESSION)){session_start();}
session_destroy(); // destroy session
setcookie("PHPSESSID","",time()-3600,"/"); // delete session cookie  


//Redirect zum login:
$host  = $_SERVER['HTTP_HOST'];
$uri  = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra1 = 'login.php';

header("Location: //$host$uri/$extra1");
exit();
?>

