<!DOCTYPE html>
<html  lang="de">	
<head>

<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="admin.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Aktive User</title>

<style>
	body {
		max-width: 30em;
		margin: auto;
	}
	ol {
		border: 1px solid #aaa;
		max-width: fit-content;
		padding: 1em;
	}
</style>

</head>
<body>

<?php

$user_dateiname = "../user/user.txt";
if (file_exists($user_dateiname)) {
	$lines = file($user_dateiname);

	foreach($lines as $key => $val) {

		$teile = explode("****", $val);
		$eintagsfliege = trim($teile[4]);

		if ($eintagsfliege >= 2 && $teile[0] !== "Support" && $teile[0] !== "System") {
			$newline4 .= '<li>'.$teile[0].'</li>';				
		}
	}
	


	echo '<h1>Aktive User</h1>';
	echo '<h2>Registrierte User, die mindestens an zwei verschiedenen Tagen im Chat waren, also ohne "Eintagsfliegen", und ohne "Spione".</h2>';
	echo '<p>Bem.: Gäste ohne Registrierung, auch "Stammgäste", können natürlich von dieser Statistik nicht erfasst werden. <br>(Beginn der Erfassung: 22.08.2022)</p><br>';
	$newline4 = '<ol>'.$newline4.'</ol>';
	echo $newline4;

	
}

$time_on = time() - $_COOKIE['arrival'];		
if (!isset($_COOKIE['arrival']) || $time_on > 60 * 60 * 3) {
	echo '<p><a href="../login.php">zum Chat-Login</a></p>';
} else {
	echo '<p><a href="../chat.php">zum Chat</a></p>';
}

echo '<p><a href="admin.php">zu den Admin-Tools</a></p>';
	
?>
