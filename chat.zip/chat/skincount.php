<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Titel</title>
  </head>
  <body>
<?php
$filename = 'skincount.txt';

if (is_readable($filename)) {

	echo "<pre>"; // Bewahrt Leerzeichen, Tabs und Zeilenumbrüche

	$handle = fopen($filename, "r");
	while (($zeile = fgets($handle)) !== false) {
		echo htmlspecialchars($zeile);
	}
	fclose($handle);

	echo "</pre>";

} else {
	echo "Datei nicht gefunden oder nicht lesbar.";
}

?>
  </body>
</html>