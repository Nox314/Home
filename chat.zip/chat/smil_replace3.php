<?php
 
// $user = htmlspecialchars($_COOKIE["nick"]);
include("chat_config.php");

$shortcut = [];
$long = [];

for($i = 0; $i <= count($smiley_dirs); $i++){

	if (file_exists("smileys$i")) {
		$bilder = array();
		$verz = "smileys$i";

		$dir1=opendir($verz);
		
		$alphabet = '0abcdefghijklmnopqrstuvwxyz';
		$alf = substr($alphabet,$i, 1);
		
		while (false !== ($file = readdir($dir1))) {
			if(strpos($file,".gif") !== false || strpos($file,".png") !== false  || strpos($file,".mp4") !== false  ) { 
				$bilder[] = $file;
			}
		}
		sort($bilder);

		$k = 1;
		foreach($bilder as $wert) {
			$link = str_replace($wert,':'.$alf.$k.':',$wert);
			$shortcut[] = $link;
			
			// if ($link == ':a10:' && ($user == "Verboten" || $user == "test123")) {
			// 	$long[] = '';
			// 	$k++;
			// }
			if (strpos($wert,".gif") !== false || strpos($wert,".png") !== false) {
				$long[] = ' <img src="'.$verz.'/'.$wert.'"  onError="this.src=\'img/0.gif\';" onclick="ads(\''.$link.'\'); return false;" oncontextmenu="max(this);return false;" style="cursor:pointer" alt="Grafik" /> ';
				$k++;
			} if (strpos($wert,".mp4") !== false) {
				$long[] = ' <video src="'.$verz.'/'.$wert.'" type="video/mp4" autoplay loop muted playsinline onmouseover="this.setAttribute(\'controls\', true)"  onmouseout="this.removeAttribute(\'controls\', true)" onfocus="this.setAttribute(\'controls\', true)" ></video>';
				$k++;
			}
		}
	}
}


$msg_explode[1] = str_replace($shortcut, $long, $msg_explode[1]);

?>