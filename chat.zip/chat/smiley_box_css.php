<?php
if ((ini_get('zlib.output_compression') != 1)) ob_start("ob_gzhandler");
header('Content-Type: text/css');
include("chat_config.php");
?>

html,body,div,p,h1,h2,h3,h4,h5,ul,ol,span,form,img,li {
	font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
	border:0;
	margin:0;
	padding:0;
}

html {
    -webkit-text-size-adjust: 100%; /* Prevent font scaling in landscape while allowing user zoom */
}

p  {
	font-size: clamp(11px, 3vw, 14px);		
	margin: 1.5em 1em;
}
ul {list-style-type:none;}
li {display:inline-block;margin:1em;}
img {
	border:0;
	margin: 0;
	max-height: 100px;
	max-width:35vw;
}
    
a {text-decoration:none;}
a.mucke:before {content:url(data:image/gif;base64,R0lGODlhDQAKAIAAAAAAAP///yH5BAEAAAEALAAAAAANAAoAAAIajI+Ap9HNoHqgToedvVdb3G1cFjGkmUELWgAAOw==)}

<?php
if (isset($usr_smileys_table_x) && isset($usr_smileys_table_y) && is_numeric($usr_smileys_table_x) && is_numeric($usr_smileys_table_y) ) {
	echo '
	table td {width: '.$usr_smileys_table_x.'px; height: '.$usr_smileys_table_y.'px;} 
	table img {max-height: '.$usr_smileys_table_y.'px; max-width: '.$usr_smileys_table_x.'px; }
	td a {display:block; height: '.$usr_smileys_table_y.'px; width: '.$usr_smileys_table_x.'px; }
	';
}
?>
    
table {width:100%;}
	
table td {
	overflow: hidden;
	display: inline-block;
	white-space: nowrap;
	border: 1px solid;
	text-align:center;
	margin:2px;
	padding: 5px;
	vertical-align: middle; /* cant work, weil img height unknown */
		
	white-space: pre-wrap; /* css-3 */    
}
table img {margin:0;}
table img {margin:0;}
table video {width:90%;height:auto;}
			
.button {
	
	font-size: clamp(13px, 3.5vw, 16px);
	
	border: 1px solid;
	padding: 2px 6px;
	border-radius: 1em;
	background: #fff;
	display: inline-block;
	margin: 5px 0 0 10px;
}

.wechselbuttons{
	position: sticky;
	top: 5px;
	margin-bottom: 10px;
	background:transparent;
	z-index:2;
}

@media screen and (max-width: 339px) {
	.wechselbuttons{
		position: static;
	}
}
<?php
// if (file_exists('smileys13')) {
// 	echo '.wechselbuttons{position: static;}';
// }
?>


.current::after {
 content: ' ✔︎';
}

.mucke {
	font-size: 1em !important;
	margin: .5em 1em .5em 0;
	display: inline;
}


/* http://ryanfait.com/sticky-footer/ */
html, body {
	height: 100%;
}
.wrapper {
	text-align:center;
}

.footer {
	position:sticky;
	opacity:0;
	bottom: 0;
	left:0;
	width: 100%;
	animation-name: myfirst;
	animation-duration: 10s;
	animation-iteration-count: 1;
}


.footer p {
	margin:0;
	padding:3px;
	font-size:13px;
	text-align:center;
}


@keyframes myfirst {
	0% {opacity: .9;}  
	70% {opacity: .9;}
	100% {opacity: 0;}
}




/* damit dunkle Firefox-Themes die Skins nicht zerschießen */
@supports not (-moz-appearance:none) {
	@media (prefers-color-scheme: dark) {
		table {
			filter:unset;
		}
	}
}


