<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include("chat_config.php");

//var_dump(gd_info());
$gd = gd_info();
// echo $gd["GD Version"];

if (!isset($gd) || $gd == "") {echo "<p>Keine GD-Bibliothek installiert, Bilder-Upload leider nicht möglich.</p>"; exit();}

// function memory_limit_bytes() {
// 	$val = ini_get('memory_limit');
// 	if ($val == -1) {
// 		return -1; // unbegrenzt
// 	}
// 	$unit = strtolower(substr($val, -1));
// 	$num = (int)$val;
// 	switch ($unit) {
// 		case 'g':
// 			$num *= 1024;
// 		case 'm':
// 			$num *= 1024;
// 		case 'k':
// 			$num *= 1024;
// 	}
// 	return $num;
// }

/* http://us2.php.net/manual/en/function.imagecolortransparent.php */
function setTransparency($new_image,$image_source)
{
       
	$transparencyIndex = imagecolortransparent($image_source);
	$transparencyColor = array('red' => 255, 'green' => 255, 'blue' => 255);
            
	if ($transparencyIndex >= 0) {
		$transparencyColor    = imagecolorsforindex($image_source, $transparencyIndex);   
	}
           
	$transparencyIndex    = imagecolorallocate($new_image, $transparencyColor['red'], $transparencyColor['green'], $transparencyColor['blue']);
	imagefill($new_image, 0, 0, $transparencyIndex);
	imagecolortransparent($new_image, $transparencyIndex);
       
} 


// Abfrage, ob Admin:
$admintrue = false;

session_start();
if (isset($_SESSION['chatuser'])) {
	$nickname= $_SESSION['chatuser'];
	// if (in_array(utf8_decode($nickname), $admins)) $admintrue = true;
	if (in_array($nickname, $admins)) $admintrue = true;
}



// $maxsize_a = $maxsize; // kB
// $upload_max_size = floatval((ini_get('upload_max_filesize'))) * 1024; // kB
//
// $mem_limit = memory_limit_bytes() / 1024; // kB
//
// if ($mem_limit > 0) {
// 	$mem_avail = $mem_limit / 5; // statt komischer Faktor (1024/5)
// 	$maxsize_b = min($maxsize_a, $upload_max_size, $mem_avail);
// } else {
// 	// -1 = unbegrenzt
// 	$maxsize_b = min($maxsize_a, $upload_max_size);
// }
//
// echo $maxsize_b; // kB
// exit;


if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}

switch ($lang) {
        default: include("langDE_inc.php");
        break;
        case "de": include("langDE_inc.php");
        break;
        case "en": include("langEN_inc.php");
        break;
        case "es": include("langES_inc.php");
        break;
        case "lu": include("langLU_inc.php");
        break;
}

//http://p2p.wrox.com/topicindex/14728.htm:
if (!isset($_SERVER['REQUEST_URI'])) {
    $_SERVER['REQUEST_URI'] = $_SERVER["SCRIPT_NAME"];
}


$url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$pfad_zum_updir = str_replace(basename($_SERVER['PHP_SELF']),"",$url).'upload/';

if (isset($_SERVER["HTTPS"])) {
	if ($_SERVER["HTTPS"] == "on") {$pfad_zum_updir = str_replace("http","https",$pfad_zum_updir);} 
}

// das ist wegen der mp3 Abfrage noetig
if(isset($_GET['rm'])) {
	$weg = '?rm='.$_GET['rm'];
	$pfad_zum_updir = str_replace($weg,"",$pfad_zum_updir);
}

// mp3 Upload:
$mp3up = false;

if(isset($_GET['rm'])) $wo = $_GET['rm'];

if (isset($mp3allow)) {
	if ($mp3allow == "clean" && ((strpos($wo,"_pr") !== false || $blankrooms == "yes" || in_array($wo,$blankroom)) || $admintrue !== false )) {$mp3up = true;}
	if ($mp3allow == "alle") {$mp3up = true;}
	if ($mp3allow == "admins" && ($admintrue !== false )) {$mp3up = true;}
}


// http://getid3.sourceforge.net/
// include getID3() library (can be in a different directory if full path is specified)
require_once('getid3/getid3.php');


// Initialize getID3 engine
$getID3 = new getID3;

// Analyze file and store returned data in $ThisFileInfo
$ThisFileInfo = $getID3->analyze($_FILES["file"]["tmp_name"]);

$audio_mp4 = false;
$filetype = $ThisFileInfo['fileformat'] ?? '';
if (!isset($ThisFileInfo['video']) || $ThisFileInfo['video'] === '') {
	$audio_mp4 = true;
}


$str = file_get_contents($_FILES["file"]["tmp_name"]);

// if (strpos($str,'.php') !== false || strpos($str,'fopen') !== false || strpos($str,'fpassthru') !== false || strpos($str,'script') !== false) {
if (strpos($str,'?php') !== false) {
	echo "<p style='color:#fff;text-shadow: 0.6px 0.6px 0.6px #000, 0.6px -0.6px 0.6px #000, -0.6px 0.6px 0.6px #000, -0.6px -0.6px 0.6px #000;'>Die Datei enthält möglicherweise Schadcode und wird nicht hochgeladen. (1)</p>";
	exit;
}
if (strpos($str,'fopen') !== false) {
	echo "<p style='color:#fff;text-shadow: 0.6px 0.6px 0.6px #000, 0.6px -0.6px 0.6px #000, -0.6px 0.6px 0.6px #000, -0.6px -0.6px 0.6px #000;'>Die Datei enthält möglicherweise Schadcode und wird nicht hochgeladen. (2)</p>";
	exit;
}
if (strpos($str,'fpassthru') !== false) {
	echo "<p style='color:#fff;text-shadow: 0.6px 0.6px 0.6px #000, 0.6px -0.6px 0.6px #000, -0.6px 0.6px 0.6px #000, -0.6px -0.6px 0.6px #000;'>Die Datei enthält möglicherweise Schadcode und wird nicht hochgeladen. (3)</p>";
	exit;
}
if (strpos($str,'script') !== false && stripos($str,'description') === false) {
	echo "<p style='color:#fff;text-shadow: 0.6px 0.6px 0.6px #000, 0.6px -0.6px 0.6px #000, -0.6px 0.6px 0.6px #000, -0.6px -0.6px 0.6px #000;'>Die Datei enthält möglicherweise Schadcode und wird nicht hochgeladen. (4)</p>";
	exit;
}


$allowed = ["gif", "bmp", "jpg", "png", "webp", "avif", "mp3", "quicktime", "mp4", "webm"];

// if (in_array($filetype, $allowed, true) && $_FILES["file"]["size"] <= ($maxsize_b * 1024)) {
if (in_array($filetype, $allowed, true)) {


// if (
//    ($filetype == "gif" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "bmp" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "jpg" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "png" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "webp" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "avif" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "mp3" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "quicktime" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "mp4" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
// || ($filetype == "webm" && $_FILES["file"]["size"] <= ($maxsize_b*1024))
//
// ) {

  if ($_FILES["file"]["error"] > 0) {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
  } else {

// $unter = str_replace(" ","_",$_FILES["file"]["name"]);
// echo $unter; exit;

	if($filetype == "mp3" || ($filetype == "mp4" && $audio_mp4 === true) || $filetype == "quicktime") {
				
    	//$upfilename = str_replace(" ","_",$_FILES["file"]["name"]);         // bei mp3 name nicht aendern
    	$upfilename = $_FILES["file"]["name"];         // bei mp3 name nicht aendern 
		
    	
    	$upfilename = str_replace(".MP3",".mp3", $upfilename);
    	$upfilename = str_replace(".m4a",".mp3", $upfilename);
    	$upfilename = str_replace(".mov",".mp3", $upfilename);

		// deutsche Umlaute im Dateinamen umwandeln
		$upfilename = str_replace("ß","ss", $upfilename);
		$upfilename = str_replace("ä","ae", $upfilename);
		$upfilename = str_replace("ö","oe", $upfilename);
		$upfilename = str_replace("ü","ue", $upfilename);
		$upfilename = str_replace("Ä","Ae", $upfilename);
		$upfilename = str_replace("Ö","Oe", $upfilename);
		$upfilename = str_replace("Ü","Ue", $upfilename);

		$upfilename2 = $upfilename;

		$upfilename2 = str_replace("a?","ae", $upfilename2);
		$upfilename2 = str_replace("o?","oe", $upfilename2);
		$upfilename2 = str_replace("u?","ue", $upfilename2);
		$upfilename2 = str_replace("A?","Ae", $upfilename2);
		$upfilename2 = str_replace("O?","Oe", $upfilename2);
		$upfilename2 = str_replace("U?","Ue", $upfilename2);
		
		$allowed = "/[^a-z0-9-_\.]/i";
		$upfilename = preg_replace($allowed,"_",$upfilename2);

		// $upfilename = utf8_encode($upfilename);
		
	// } elseif($filetype == "quicktime") {
	// 	$upfilename = uniqid ("").'.'.'mp4';         //  eleganter
				
	} else { 
		$upfilename = uniqid ("").'.'.$filetype;         //  eleganter
	}


// echo $filetype.$_FILES["file"]["size"];exit;

if ($filetype == "jpg" || $filetype == "png" || $filetype == "avif" || $filetype == "webp" || $filetype == "gif") {

    $sourcefile = $_FILES["file"]["tmp_name"];
    $popfile = "upload/".$upfilename;
    $thumbfile = "tn_upload/".$upfilename;
	

    /* Get the dimensions of the source picture */
    $picsize=getimagesize("$sourcefile");

	// https://stackoverflow.com/questions/7489742/php-read-exif-data-and-adjust-orientation
	if (@exif_read_data($sourcefile)['Orientation'] == 6 || @exif_read_data($sourcefile)['Orientation'] == 8) {
		// echo @exif_read_data($sourcefile)['Orientation'];
		
		$source_y = $picsize[0];
    	$source_x = $picsize[1];
	} else {
		$source_y = $picsize[1];
    	$source_x = $picsize[0];
	}

	$ratio = $source_x / $source_y;


     /* pop berechnen, keep ratio */
     if ($source_x > $show_x || $source_y > $max_y ) {
			if ($ratio >= 1) { // Querformat
				$show_x = $show_x; $show_y = $show_x / $ratio;
			} else { // Hochformat
				$show_y = $max_y; $show_x = $show_y * $ratio;				
			}
     } else {
            $show_x = $source_x;
            $show_y = $source_y;
     }

    /* thumb berechnen, keep ratio */
	$nothumb = false;
     if ($source_x > $maxwidth || $source_y > $maxheight ) {
			if ($ratio >= 1) { // Querformat
				$thumb_x = $maxwidth; $thumb_y = $thumb_x / $ratio;
				if ($thumb_y > $maxheight) {$thumb_y = $maxheight; $thumb_x = $thumb_y * $ratio;}
			} else { // Hochformat
				$thumb_y = $maxheight; $thumb_x = $thumb_y * $ratio;				
				if ($thumb_x > $maxwidth) {$thumb_x = $maxwidth; $thumb_y = $thumb_x / $ratio;}
			}
     } else {
		 $thumb_x = $source_x;
		 $thumb_y = $source_y;
		 $nothumb = true; 
     }
}



      /* ############ jetzt jpg files zum Speichern verkleinern ############ */
      if ($filetype == "jpg") {
		  

        $jpegqual   = 90;                          // jpg-Qualitaet


        @$source_id = imageCreateFromJPEG("$sourcefile");
		imageinterlace($source_id, false); // Entfernt versteckte Daten
		
		
		// https://stackoverflow.com/questions/7489742/php-read-exif-data-and-adjust-orientation
 		$source_id = imagerotate($source_id, array_values([0, 0, 0, 180, 0, 0, -90, 0, 90])[@exif_read_data($sourcefile)['Orientation'] ?: 0], 0);
		
        if (!$source_id) $jpeg_error = "err";            // jpeg Fehler abfangen



        /* Create a new image object (not neccessarily true colour) */
        $pop_id=imagecreatetruecolor($show_x, $show_y);

        /* Resize the original picture and copy it into the just created image object.*/

        @$pop_pic=imagecopyresampled($pop_id,$source_id,0,0,0,0,$show_x,$show_y,$source_x,$source_y);


        /* Create a jpeg with the quality of "$jpegqual" out of the image object "$pop_pic".
        This will be saved as $popfile */
		imagejpeg ($pop_id,"$popfile",$jpegqual);


        /* Create thumb */
		if (!isset($nothumb) || $nothumb !== true) {
			$thumb_x = (int) round($thumb_x);
			$thumb_y = (int) round($thumb_y);
			$source_x = (int) round($source_x);
			$source_y = (int) round($source_y);
	        $thumb_id=imagecreatetruecolor($thumb_x,$thumb_y);
        	@$thumb_pic=imagecopyresampled($thumb_id,$source_id,0,0,0,0,$thumb_x,$thumb_y,$source_x,$source_y);
        	imagejpeg ($thumb_id,"$thumbfile",$jpegqual);
		}



      /* ############ jetzt png files zum Speichern verkleinern ########## */
      } elseif ($filetype == "png") {


        @$source_id = imageCreateFromPNG("$sourcefile");
        if (!$source_id) $jpeg_error = "err";            // jpeg Fehler abfangen

 
        /* Create a new image object (not neccessarily true colour) */
        $pop_id=imagecreatetruecolor($show_x, $show_y);

setTransparency($pop_id,$source_id);


        /* Resize the original picture and copy it into the just created image object.*/

        @$pop_pic=imagecopyresampled($pop_id,$source_id,0,0,0,0,$show_x,$show_y,$source_x,$source_y);


        /* Create a png out of the image object "$pop_pic".
        This will be saved as $popfile */
        imagePNG ($pop_id,"$popfile");

        /* Create thumb */
		if ($nothumb !== true) {
			$thumb_x = (int) round($thumb_x);
			$thumb_y = (int) round($thumb_y);
        	$thumb_id=imagecreatetruecolor($thumb_x,$thumb_y);
        	
			setTransparency($thumb_id,$source_id);

        	@$thumb_pic=imagecopyresampled($thumb_id,$source_id,0,0,0,0,$thumb_x,$thumb_y,$source_x,$source_y);
        	imagePNG ($thumb_id,"$thumbfile");
		}

		/* ############ jetzt webp files zum Speichern verkleinern ########## */
		} elseif ($filetype == "webp") {
			
			$mime = mime_content_type($sourcefile);
			if (!in_array($mime, ["image/webp"])) {
			    $jpeg_error = "err";
			}

			// Animated WebP erkennen: RIFF-Container auf ANIM-Chunk prüfen
			$webp_animated = false;
			$webp_raw = file_get_contents($sourcefile, false, null, 0, 64);
			if ($webp_raw !== false && strpos($webp_raw, 'ANIM') !== false) {
				$webp_animated = true;
			}

			if ($webp_animated) {
				// Animated WebP wie GIF: unverändert speichern, kein Resize
				move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $upfilename);
				chmod("upload/" . $upfilename, 0644);
			} else {
			
			@$source_id = imageCreateFromWebp("$sourcefile");
			imageinterlace($source_id, false); // Entfernt versteckte Daten
			
			if (!$source_id) {
				error_log("Fehler: imageCreateFromWebp konnte die Datei nicht laden.");
			} 

			if (!$source_id) $jpeg_error = "err"; // WebP Fehler abfangen

			/* Create a new image object (true colour for WebP support) */
			$pop_id = imagecreatetruecolor($show_x, $show_y);

			setTransparency($pop_id, $source_id);

			/* Resize the original picture and copy it into the just created image object */
			@$pop_pic = imagecopyresampled($pop_id, $source_id, 0, 0, 0, 0, $show_x, $show_y, $source_x, $source_y);

			/* Create a WebP out of the image object "$pop_pic".
			This will be saved as $popfile */
			imageWebp($pop_id, "$popfile");

			/* Create thumb */
			if ($nothumb !== true) {
				$thumb_x = (int) round($thumb_x);
				$thumb_y = (int) round($thumb_y);
				
				$thumb_id = imagecreatetruecolor($thumb_x, $thumb_y);

				setTransparency($thumb_id, $source_id);

				@$thumb_pic = imagecopyresampled($thumb_id, $source_id, 0, 0, 0, 0, $thumb_x, $thumb_y, $source_x, $source_y);
				imageWebp($thumb_id, "$thumbfile");
			}

			} // end animated WebP branch


		/* ############ jetzt avif files zum Speichern verkleinern ########## */
		} elseif ($filetype == "avif") {
			
			$mime = mime_content_type($sourcefile);
			if (!in_array($mime, ["image/avif"])) {
			    $jpeg_error = "err";
			}

		    @$source_id = imagecreatefromavif("$sourcefile");

		    if (!$source_id) {
		        echo "Fehler beim Laden der AVIF-Datei.\n";
		        error_log("Fehler: imagecreatefromavif konnte die Datei nicht laden.");
		    }

		    if (!$source_id) $jpeg_error = "err"; // AVIF Fehler abfangen

		    /* Create a new image object (true colour for AVIF support) */
		    $pop_id = imagecreatetruecolor($show_x, $show_y);

		    setTransparency($pop_id, $source_id);

		    /* Resize the original picture and copy it into the just created image object */
		    @$pop_pic = imagecopyresampled($pop_id, $source_id, 0, 0, 0, 0, $show_x, $show_y, $source_x, $source_y);

		    /* Create an AVIF out of the image object "$pop_pic".
		    This will be saved as $popfile */
		    imageavif($pop_id, "$popfile");

		    /* Create thumb */
		    if ($nothumb !== true) {
		        $thumb_id = imagecreatetruecolor($thumb_x, $thumb_y);

		        setTransparency($thumb_id, $source_id);

		        $thumb_pic = imagecopyresampled($thumb_id, $source_id, 0, 0, 0, 0, $thumb_x, $thumb_y, $source_x, $source_y);
		        imageavif($thumb_id, "$thumbfile");
		    }
		


      /*  ############# jetzt bmp files zum Speichern verkleinern ########## */
		//       } elseif ($filetype == "bmp") {
		//
		//         // http://www.hotscripts.com/Detailed/41077.html
		//         include("bmp.php");
		//
		//
		//         @$source_id = imagecreatefrombmp("$sourcefile");
		//         if (!$source_id) $jpeg_error = "err";            // jpeg Fehler abfangen
		//
		//         /* Create a new image object (not neccessarily true colour) */
		//         $pop_id=imagecreate($show_x, $show_y);
		//
		//
		//         /* Resize the original picture and copy it into the just created image object.*/
		//
		//         @$pop_pic=imagecopyresampled($pop_id,$source_id,0,0,0,0,$show_x,$show_y,$source_x,$source_y);
		//
		//         /* Create a png out of the image object "$pop_pic".
		//         This will be saved as $popfile */
		//         imagePNG ($pop_id,"$popfile");
		//
		//         /* Create thumb */
		// if ($nothumb !== true) {
		//         	$thumb_id=imagecreatetruecolor($thumb_x,$thumb_y);
		//         	@$thumb_pic=imagecopyresampled($thumb_id,$source_id,0,0,0,0,$thumb_x,$thumb_y,$source_x,$source_y);
		//         	imagePNG ($thumb_id,"$thumbfile");
		// }

      /*  ############# jetzt gif files zum Speichern verkleinern ########## */
      } elseif ($filetype == "gif") {
		  
		  
		  $info = getimagesize($sourcefile);
		  if ($info === false || $info[2] !== IMAGETYPE_GIF) {
		      $jpeg_error = "err";
		  }  

		$nothumb = true; 
		if ($nothumb !== true) { // gifs nur behandeln, wenn thumb erforderlich

        @$source_id = imagecreatefromgif("$sourcefile");
		imageinterlace($source_id, false); // Entfernt versteckte Daten
		
        if (!$source_id) $jpeg_error = "err";            // jpeg Fehler abfangen

		// $white = imageColorAllocate ($im, 255, 255, 255);
		// $trans = imagecolortransparent($source_id,$white);

        /* Create a new image object (not neccessarily true colour) */
        $pop_id=imagecreatetruecolor($show_x, $show_y);

setTransparency($pop_id,$source_id);

        /* Resize the original picture and copy it into the just created image object.*/

        @$pop_pic=imagecopyresampled($pop_id,$source_id,0,0,0,0,$show_x,$show_y,$source_x,$source_y);

        /* Create a png out of the image object "$pop_pic".
        This will be saved as $popfile */
        imageGIF ($pop_id,"$popfile");

        /* Create thumb */
        	$thumb_id=imagecreatetruecolor($thumb_x,$thumb_y);
        	
setTransparency($thumb_id,$source_id);
        	
        	@$thumb_pic=imagecopyresampled($thumb_id,$source_id,0,0,0,0,$thumb_x,$thumb_y,$source_x,$source_y);
        	imageGIF ($thumb_id,"$thumbfile");
		} else {
        	move_uploaded_file($_FILES["file"]["tmp_name"],"upload/" . $upfilename);
         	chmod ("upload/".$upfilename, 0644);           // manche Server setzen sonst 600
		}


      
      } elseif ($filetype == "mp3" && $mp3up) {
              move_uploaded_file($_FILES["file"]["tmp_name"],"upload/" . $upfilename);
              chmod ("upload/".$upfilename, 0644);           // manche Server setzen sonst 600
      
      } elseif ($filetype == "quicktime" || $filetype == "mp4" || $filetype == "webm") {
              move_uploaded_file($_FILES["file"]["tmp_name"],"upload/" . $upfilename);
              chmod ("upload/".$upfilename, 0644);           // manche Server setzen sonst 600

      }
 
      if (isset($jpeg_error)) {
              echo '<p>'._JPGERR.' (err 1)</p>';
      } else {
              echo '<p><a href="#" onclick="ads(\''.$pfad_zum_updir.$upfilename.'\'); clear_upload2(); return false; ">'._UPDONE.'</a></p>';
      }

  }

} else {
	if ($_FILES["file"]["size"] > ($maxsize_b * 1024) || $_FILES["file"]["size"] == 0) {
		echo '<p>'._SIZEERR1.$maxsize_b._SIZEERR2.' (2)</p>';
	} elseif ($filetype == "mp3" && $mp3up !== true) {
		echo '<p>'._MP3ADMINONLY.'</p>';

		/*        } elseif ($filetype == "swf" && $admintrue !== true) {
		echo '<p>'._SWFADMINONLY.'</p>';
		*/

	} elseif ($filetype != "gif" && $filetype != "png" && $filetype != "jpg" && $filetype != "quicktime" && $filetype != "mp4" && $filetype != "webm" && $filetype != "mp3" ) {
		// echo $filetype;
		echo '<p>'.$filetype.': '._TYPEERR.'(1)</p>';

	} else {
		echo '<p>'._UPERR.' (3)</p>';
	}
}
// bei zu grossen files gibt PHP anscheinend kein filesize zurueck
?>