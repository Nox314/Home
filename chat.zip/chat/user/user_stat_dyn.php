<?php
error_reporting(E_ALL);

// ----------------------------------------------------------
// Konfiguration laden
// ----------------------------------------------------------
include(__DIR__ . '/../chat_config.php');
if (file_exists(__DIR__ . '/../personal_config_inc.php')) {
	include(__DIR__ . '/../personal_config_inc.php');
}
if (empty($standard)) exit;

// ----------------------------------------------------------
// Dateipfade
// ----------------------------------------------------------
$dir           = __DIR__ . '/';
$userfile      = $dir . "ip_{$standard}.txt";
$dayFile       = $dir . 'max_on_tag.php';
$alltimeFile   = $dir . 'max_on_alltime.php';
$averageFile   = $dir . 'max_on_average.php';
$midnightFlag  = $dir . 'last_midnight_run.txt';
$dayLockFile   = $dir . 'max_on_tag.lock';

// ----------------------------------------------------------
// LOCK-FUNKTIONEN
// ----------------------------------------------------------
function lockDayFile($lockFile) {
	$fp = fopen($lockFile, 'c');
	if ($fp === false) return false;
	flock($fp, LOCK_EX);
	return $fp;
}

function unlockDayFile($fp) {
	if ($fp) {
		flock($fp, LOCK_UN);
		fclose($fp);
	}
}

// ----------------------------------------------------------
// Hilfsfunktionen
// ----------------------------------------------------------
function createZeroFile24($file) {
	$content = str_repeat("0\n", 24);
	file_put_contents($file, $content, LOCK_EX);
	chmod($file, 0644);
}

function load24($file) {
	if (!file_exists($file) || filesize($file) === 0) {
		createZeroFile24($file);
	}
	$lines = file($file, FILE_IGNORE_NEW_LINES);
	if (!is_array($lines) || count($lines) !== 24) {
		createZeroFile24($file);
		$lines = file($file, FILE_IGNORE_NEW_LINES);
	}
	return array_map('intval', $lines);
}

function save24($file, $lines) {
	$tmp = $file . '.tmp';
	file_put_contents($tmp, implode("\n", $lines) . "\n", LOCK_EX);
	chmod($tmp, 0644);
	rename($tmp, $file);
}

// ----------------------------------------------------------
// EINZIGER LOCK für Mitternacht + Besucher
// ----------------------------------------------------------
$lock = lockDayFile($dayLockFile);
if ($lock === false) exit; // wenn Lock nicht geht, abbrechen

$today     = date('Y-m-d');
$yesterday = date('d.m.Y', strtotime('-1 day'));
$lastRunDate = file_exists($midnightFlag) ? trim(file_get_contents($midnightFlag)) : '';

// ----------------------------------------------------------
// MITTERNACHTSROUTINE
// ----------------------------------------------------------
if ($lastRunDate !== $today) {

	$dayData = load24($dayFile);

	if (array_sum($dayData) > 0) {

		// 🔹 Archiv für abgeschlossenen Tag
		$archiveDest = $dir . "max_on_{$yesterday}.php";
		save24($archiveDest, $dayData);

		// 🔹 Backup optional
		$backupFile = $dir . "max_on_tag_backup_{$yesterday}.php";
		if (!file_exists($backupFile)) {
			save24($backupFile, $dayData);
		}

		// 🔹 ALLTIME MAX aktualisieren
		$allData = load24($alltimeFile);
		$changed = false;
		for ($i = 0; $i < 24; $i++) {
			if ($dayData[$i] > $allData[$i]) {
				$allData[$i] = $dayData[$i];
				$changed = true;
			}
		}
		if ($changed) {
			save24($alltimeFile, $allData);
		}
	}

	// 🔹 Reset für neuen Tag
	createZeroFile24($dayFile);
	file_put_contents($midnightFlag, $today, LOCK_EX);
	chmod($midnightFlag, 0644);
}

// ----------------------------------------------------------
// BACKUPS älter als 30 Tage löschen
// ----------------------------------------------------------
$backupFiles = glob($dir . 'max_on_tag_backup_*.php');
$limitTs     = strtotime('-30 days');
foreach ($backupFiles as $file) {
	if (preg_match('/max_on_tag_backup_(\d{2}\.\d{2}\.\d{4})\.php$/', $file, $m)) {
		$dt = DateTime::createFromFormat('d.m.Y', $m[1]);
		if ($dt && $dt->getTimestamp() < $limitTs) {
			@unlink($file);
		}
	}
}

// ----------------------------------------------------------
// BESUCHER ZÄHLEN / TAGESMAX aktualisieren
// ----------------------------------------------------------
$count = 0;
if (file_exists($userfile) && (time() - filemtime($userfile) < 20)) {
	$lines = @file($userfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	foreach ($lines as $line) {
		$user = explode("++++", $line);
		if (!empty($user[1]) && strpos($user[1], "ghost") === false && trim($user[1]) !== '####') {
			$count++;
		}
	}
}

$dayData = load24($dayFile);
$h = (int) date("G");

if ($count > $dayData[$h]) {
	$dayData[$h] = $count;
	save24($dayFile, $dayData);
}

// ----------------------------------------------------------
// DURCHSCHNITT DER LETZTEN 30 TAGE
// ----------------------------------------------------------
$files = glob($dir . "max_on_*.php");
$dated = [];
foreach ($files as $f) {
	if (preg_match('/max_on_(\d{2}\.\d{2}\.\d{4})\.php$/', $f, $m)) {
		$dt = DateTime::createFromFormat('d.m.Y', $m[1]);
		if ($dt) {
			$dated[] = ['ts' => $dt->getTimestamp(), 'file' => $f];
		}
	}
}

usort($dated, function($a, $b) { return $b['ts'] <=> $a['ts']; });
$dated = array_slice($dated, 0, 30);

$sum  = array_fill(0, 24, 0);
$days = 0;

foreach ($dated as $d) {
	$lines = load24($d['file']);
	if (array_sum($lines) > 0) {
		for ($i = 0; $i < 24; $i++) {
			$sum[$i] += $lines[$i];
		}
		$days++;
	}
}

if ($days > 0) {
	$avg = [];
	for ($i = 0; $i < 24; $i++) {
		$avg[$i] = round($sum[$i] / $days, 2);
	}
	save24($averageFile, $avg);
}

// ----------------------------------------------------------
// LOCK FREIGEBEN
// ----------------------------------------------------------
unlockDayFile($lock);
?>
