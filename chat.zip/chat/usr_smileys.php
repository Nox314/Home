<?php
// error_reporting(E_ALL);

if (isset($_COOKIE["lang"])) {
	$lang = $_COOKIE["lang"];
} else {
	$lang = "de";
}

switch ($lang) {
	default: include("langDE_inc.php");
	break;
	case "de": include("langDE_inc.php");
	break;
	case "en": include("langEN_inc.php");
	break;
}

include("chat_config.php");

if (!isset($smiley_dirs)) {
	foreach (glob("smileys*") as $filename) {
    	$smiley_dirs[] = ucwords($filename);
	}
	natsort($smiley_dirs);
}
// print_r ($smiley_dirs);


if (count($smiley_dirs) > 26) {
	echo "Max. 26 Smiley-Boxen möglich. <br>Bitte lösche die Ordner ab smiley27 und entferne sie ggf. aus deiner config-Datei."; exit;
}
	
function isMobile() {
	return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}

if (!isset($self_close) || $self_close != "" || isMobile() ) {$self_close = "self.close();";}

if (isset($stil) && $stil <> 0) {
	$s = $stil;
} elseif (isset($_COOKIE["Style"])) {
	$s = $_COOKIE["Style"];
} else {
	$s = $default_skin;
}

if ($_GET["file"]) {
	$m = htmlspecialchars($_GET["file"]);
} else {
	exit;
}

$alphabet = '0abcdefghijklmnopqrstuvwxyz';
$alf = substr($alphabet,$m, 1);

?>

<!DOCTYPE html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1" />

<title>Smileys einfügen</title>

<link rel="stylesheet" type="text/css" media="screen" href="helpcss<?php echo $s; ?>.css" />
<link rel="stylesheet" type="text/css" media="screen" href="smiley_box_css.php?<?php echo time() ?>" />

<script>

	// Überwachung von Änderungen in localStorage
	window.addEventListener("storage", function(event) {
		if (event.key === "closeUsrX" && event.newValue === "true") {
			window.close();  // Schließt das Tab, falls "closeUsrX" (durch login.php) auf "true" gesetzt wird
		}
	});

	function newsmile(smiley) {
		if (window.opener.document.getElementById('line').value.indexOf('<? echo _MESSAGE; ?>') !== -1) {
			window.opener.document.getElementById('line').value = "";
		}
        	
		window.opener.document.getElementById('line').value += " "+smiley+" ";
		window.opener.focus();
		window.opener.document.getElementById('line').focus();
	}
		
	function kp(e){if (!e) e=window.event;if (e.keyCode==27 && !e.shiftKey){self.close();}}window.onkeypress=kp;

	var cookieWert;
	function holeCookie(keksname) {
		var alleCookies, i;
		alleCookies=document.cookie;
		cookieArr=alleCookies.split(";");
		for(var i=0;i<cookieArr.length;i++) {
			if(cookieArr[i].split("=")[0].replace(/\s+/,"") == keksname) {
				cookieWert=cookieArr[i].split("=");
				cookieWert=decodeURIComponent(cookieWert[1].replace(/\+/g," "));
				return true;
			}
		}
		return false;
	}
	
	var timeOutFunctionId;
	function workAfterResizeIsDone() {
		var w = window.innerWidth;
		var h = window.innerHeight;
		var l = window.screenLeft;
		var t = window.screenTop;
		
		localStorage.setItem("box_width", w);		
		localStorage.setItem("box_height", h);		
		localStorage.setItem("box_left", l);		
		localStorage.setItem("box_top", t);							
					
	}
	window.addEventListener("resize", function() {
		clearTimeout(timeOutFunctionId);			
		timeOutFunctionId = setTimeout(workAfterResizeIsDone, 500);
	});
	window.addEventListener("blur", function() {
		clearTimeout(timeOutFunctionId);
		timeOutFunctionId = setTimeout(workAfterResizeIsDone, 500);
	});
	

</script>


</head>
<body onkeydown="kp()" onload="focus();">


<div class="wrapper">
<div class="wechselbuttons">



<?php

$verz = 'smileys'.$m;

$i = 1;
foreach ($smiley_dirs as $key){
	// echo $key;
	if (file_exists ('smileys'.$i)  && $m != $i) {
		echo '<a class="button" href="usr_smileys.php?file='.$i.'">▹ '.$key.'</a>&nbsp;';
	} elseif (file_exists ('smileys'.$i)) {
		echo '<p class="button current" >'.$key.'</p>&nbsp;';
	}
	$i++;
}
 
echo "</div>";

$bilder = array();

$dir=opendir($verz);
if (!$dir) {exit; }
while (false !== ($file = readdir($dir))) {
	if(strpos($file,".gif") !== false || strpos($file,".png") !== false || strpos($file,".mp3") !== false || strpos($file,".mp4") !== false ) { 
		$bilder[] = $file;
	}
}
		
if(empty($bilder)) {
	echo "<p>Hier gibt es (noch) keine Smileys</p>"; 
}

sort($bilder);


if ( isset( $_SERVER["HTTPS"] ) && strtolower( $_SERVER["HTTPS"] ) == "on" ) {
	$prot="https://";
} else {
	$prot="http://";
}

$k = 1;

if (isset($usr_smileys_table_x) && isset($usr_smileys_table_y) && is_numeric($usr_smileys_table_x) && is_numeric($usr_smileys_table_y) ) {
	echo '<table><tr>';
	
	foreach($bilder as $wert) {
		$smiley = '<img src="'.$verz.'/'.$wert.'" alt="" />';
		$directory = "";
		if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
		$link = $prot.$_SERVER['SERVER_NAME'].$directory.'/'.$verz.'/'.$wert;
		$linktext = str_replace("Audio:","",$link);
		$linktext = str_replace(".mp3","",$linktext);
		$linktext = str_replace("_"," ",$linktext);


		// auch mp4
		if(strpos($wert,".mp4") !== false ) {
			$link = str_replace($wert,':'.$alf.$k.':',$wert);
			$smiley = '<video src="'.$verz.'/'.$wert.'" height="100" width="150"  autoplay muted playsinline  ></video>';
			echo '<td><a href="#" onclick="newsmile(\''.$link.' \'); '.$self_close.' return false;" title=":'.$alf.$k.':">'.$smiley.'</a></td>';
			$k++;
		} elseif (strpos($wert,".gif") !== false || strpos($wert,".png") !== false) {
			$link = str_replace($wert,':'.$alf.$k.':',$wert);
			echo '<td><a href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;" title=":'.$alf.$k.':">'.$smiley.'</a></td>';
			$k++;
		} else {
			// mp3 kein shortlink
			echo '<td> <a class="mucke" href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.basename($linktext).'</a></td>';
		}
	}
	echo '</tr></table>';
        
} else {
        
	echo '<ul>';
	foreach($bilder as $wert) {
		$smiley = '<img src="'.$verz.'/'.$wert.'" alt="" />';
		$directory = "";
		if (dirname($_SERVER['PHP_SELF']) != '/') {$directory = dirname($_SERVER['PHP_SELF']);}
		$link = $prot.$_SERVER['SERVER_NAME'].$directory.'/'.$verz.'/'.$wert;
		$linktext = str_replace("Audio:","",$link);
		$linktext = str_replace(".mp3","",$linktext);
		$linktext = str_replace("_","&nbsp;",$linktext);

		// auch mp4
		if(strpos($wert,".mp4") !== false ) {
			$link = str_replace($wert,':'.$alf.$k.':',$wert);
			$smiley = '<video src="'.$verz.'/'.$wert.'" height="100" width="150"  autoplay muted playsinline  ></video>';
			echo '<li><a href="#" onclick="newsmile(\''.$link.' \'); '.$self_close.' return false;">'.$smiley.'</a></li>';
			$k++;
		} elseif (strpos($wert,".gif") !== false || strpos($wert,".png") !== false) {
			$link = str_replace($wert,':'.$alf.$k.':',$wert);
			echo '<li><a href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;" title=":'.$alf.$k.':">'.$smiley.'</a></li>';
			$k++;
		} else {
			echo '<li> <a class="mucke" href="#" onclick="newsmile(\''.$link.'\'); '.$self_close.' return false;">'.basename($linktext).'</a></li>';
		}
	}
	echo '</ul>';
        
}

closedir($dir);
?>

<!-- <div class="push"></div> -->

</div>

<div class="footer">

<?php
if(!empty($bilder)) {
	echo '<p>'._USR_SMILEY1._USR_SMILEY2.'</p>';
}
?>
</div>
<p style="position:fixed; bottom: -2em;right:-.5em"><a style="color:#444;text-decoration:none;	text-shadow:.6px  .6px .6px white,.6px -.6px .6px white,-.6px  .6px .6px white,-.6px -.6px .6px white;font-size:2em; opacity:1" href="javascript:self.close()">X</a>

</body>
</html>