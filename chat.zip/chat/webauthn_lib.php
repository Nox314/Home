<?php
/*
 * webauthn_lib.php
 * Minimale WebAuthn/Passkey-Bibliothek in reinem PHP, ohne Abhängigkeiten.
 * Deckt genau das ab, was für Registrierung + Login (Passkeys, discoverable
 * credentials, ES256/RS256) nötig ist - kein vollständiger WebAuthn-Stack,
 * keine Attestation-Prüfung (attestation = "none", wie bei Passkeys üblich).
 */

define('PASSKEY_FILE', __DIR__ . '/user/passkeys.txt');


// ---------- Base64url ----------

function base64url_encode($data) {
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64url_decode($data) {
	$data = strtr($data, '-_', '+/');
	$pad = strlen($data) % 4;
	if ($pad) { $data .= str_repeat('=', 4 - $pad); }
	return base64_decode($data);
}


// ---------- CBOR-Decoder (nur definite-length, reicht für WebAuthn) ----------

function cbor_read_uint($data, &$offset, $ai) {
	if ($ai < 24) { return $ai; }
	if ($ai == 24) { $v = ord($data[$offset]); $offset += 1; return $v; }
	if ($ai == 25) { $v = unpack('n', substr($data, $offset, 2))[1]; $offset += 2; return $v; }
	if ($ai == 26) { $v = unpack('N', substr($data, $offset, 4))[1]; $offset += 4; return $v; }
	if ($ai == 27) {
		$hi = unpack('N', substr($data, $offset, 4))[1];
		$lo = unpack('N', substr($data, $offset + 4, 4))[1];
		$offset += 8;
		return $hi * 4294967296 + $lo;
	}
	throw new Exception('CBOR: ungültige additional-info');
}

function cbor_decode($data, &$offset) {
	$byte = ord($data[$offset]);
	$offset++;
	$major = $byte >> 5;
	$ai = $byte & 0x1f;

	switch ($major) {
		case 0: // unsigned int
			return cbor_read_uint($data, $offset, $ai);

		case 1: // negative int
			return -1 - cbor_read_uint($data, $offset, $ai);

		case 2: // byte string
			$len = cbor_read_uint($data, $offset, $ai);
			$v = substr($data, $offset, $len);
			$offset += $len;
			return $v;

		case 3: // text string
			$len = cbor_read_uint($data, $offset, $ai);
			$v = substr($data, $offset, $len);
			$offset += $len;
			return $v;

		case 4: // array
			$len = cbor_read_uint($data, $offset, $ai);
			$arr = [];
			for ($i = 0; $i < $len; $i++) { $arr[] = cbor_decode($data, $offset); }
			return $arr;

		case 5: // map
			$len = cbor_read_uint($data, $offset, $ai);
			$map = [];
			for ($i = 0; $i < $len; $i++) {
				$k = cbor_decode($data, $offset);
				$v = cbor_decode($data, $offset);
				$map[$k] = $v;
			}
			return $map;

		case 6: // tag - Tag-Nummer ignorieren, inneren Wert liefern
			cbor_read_uint($data, $offset, $ai);
			return cbor_decode($data, $offset);

		case 7:
			if ($ai == 20) { return false; }
			if ($ai == 21) { return true; }
			if ($ai == 22) { return null; }
			if ($ai == 24) { $offset += 1; return null; } // simple value, für uns irrelevant
			return null; // floats werden hier nicht benötigt
	}
	throw new Exception('CBOR: unbekannter Major-Type');
}


// ---------- authenticatorData parsen ----------
// Struktur: rpIdHash(32) | flags(1) | signCount(4, big-endian)
//           [ aaguid(16) | credIdLen(2, BE) | credId | credentialPublicKey (CBOR) ]  <- nur wenn AT-Flag
//           [ extensions (CBOR) ]                                                     <- nur wenn ED-Flag

function webauthn_parse_auth_data($authData) {
	if (strlen($authData) < 37) {
		throw new Exception('authData zu kurz');
	}

	$rpIdHash = substr($authData, 0, 32);
	$flags = ord($authData[32]);
	$signCount = unpack('N', substr($authData, 33, 4))[1];

	$result = [
		'rpIdHash'  => $rpIdHash,
		'flags'     => $flags,
		'signCount' => $signCount,
		'up'        => (bool) ($flags & 0x01), // User Present
		'uv'        => (bool) ($flags & 0x04), // User Verified
		'at'        => (bool) ($flags & 0x40), // Attested Credential Data vorhanden
		'ed'        => (bool) ($flags & 0x80), // Extensions vorhanden
	];

	$offset = 37;

	if ($result['at']) {
		$aaguid = substr($authData, $offset, 16);
		$offset += 16;

		$credIdLen = unpack('n', substr($authData, $offset, 2))[1];
		$offset += 2;

		$credId = substr($authData, $offset, $credIdLen);
		$offset += $credIdLen;

		$rest = substr($authData, $offset);
		$o2 = 0;
		$pubKey = cbor_decode($rest, $o2); // COSE-Key-Map, weiterer Rest (Extensions) wird ignoriert

		$result['aaguid'] = $aaguid;
		$result['credentialId'] = $credId;
		$result['credentialPublicKey'] = $pubKey;
	}

	return $result;
}


// ---------- DER/PEM-Aufbau für EC (P-256) und RSA ----------

function der_len($len) {
	if ($len < 128) { return chr($len); }
	$bytes = '';
	while ($len > 0) { $bytes = chr($len & 0xff) . $bytes; $len >>= 8; }
	return chr(0x80 | strlen($bytes)) . $bytes;
}

function der_integer($raw) {
	$raw = ltrim($raw, "\x00");
	if ($raw === '') { $raw = "\x00"; }
	if (ord($raw[0]) & 0x80) { $raw = "\x00" . $raw; } // positive Zahl erzwingen
	return "\x02" . der_len(strlen($raw)) . $raw;
}

function ec_p256_pem_from_xy($x, $y) {
	// Fester Header für "EC Public Key, Kurve prime256v1" - nur X||Y variieren
	$prefix = hex2bin('3059301306072a8648ce3d020106082a8648ce3d03010703420004');
	$der = $prefix . $x . $y;
	$b64 = base64_encode($der);
	return "-----BEGIN PUBLIC KEY-----\n" . chunk_split($b64, 64, "\n") . "-----END PUBLIC KEY-----\n";
}

function rsa_pem_from_ne($n, $e) {
	$modulus  = der_integer($n);
	$exponent = der_integer($e);
	$seq = "\x30" . der_len(strlen($modulus . $exponent)) . $modulus . $exponent;
	$bitstring = "\x00" . $seq; // 0 ungenutzte Bits
	$bitstringDer = "\x03" . der_len(strlen($bitstring)) . $bitstring;
	$algId = hex2bin('300d06092a864886f70d0101010500'); // rsaEncryption + NULL
	$spkiInner = $algId . $bitstringDer;
	$spki = "\x30" . der_len(strlen($spkiInner)) . $spkiInner;
	$b64 = base64_encode($spki);
	return "-----BEGIN PUBLIC KEY-----\n" . chunk_split($b64, 64, "\n") . "-----END PUBLIC KEY-----\n";
}

// COSE-Key-Map (aus authData) -> ['alg' => 'ES256'|'RS256', 'pem' => ...]
function cose_key_to_pem($coseMap) {
	$kty = $coseMap[1] ?? null;

	if ($kty == 2) { // EC2
		$crv = $coseMap[-1] ?? null;
		if ($crv != 1) { throw new Exception('Nur P-256 (crv=1) wird unterstützt'); }
		$x = $coseMap[-2];
		$y = $coseMap[-3];
		return ['alg' => 'ES256', 'pem' => ec_p256_pem_from_xy($x, $y)];
	}

	if ($kty == 3) { // RSA
		$n = $coseMap[-1];
		$e = $coseMap[-2];
		return ['alg' => 'RS256', 'pem' => rsa_pem_from_ne($n, $e)];
	}

	throw new Exception('Unbekannter/nicht unterstützter Schlüsseltyp (kty=' . $kty . ')');
}


// ---------- Credential-Speicherung (user/passkeys.txt, eine JSON-Zeile pro Credential) ----------

function webauthn_get_all_credentials() {
	if (!file_exists(PASSKEY_FILE)) { return []; }
	$lines = file(PASSKEY_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	$out = [];
	foreach ($lines as $line) {
		$rec = json_decode($line, true);
		if ($rec) { $out[] = $rec; }
	}
	return $out;
}

function webauthn_get_credentials_for_user($nickname) {
	$out = [];
	foreach (webauthn_get_all_credentials() as $rec) {
		if ($rec['nickname'] === $nickname) { $out[] = $rec; }
	}
	return $out;
}

function webauthn_find_credential_by_id($credIdB64) {
	foreach (webauthn_get_all_credentials() as $rec) {
		if ($rec['credId'] === $credIdB64) { return $rec; }
	}
	return null;
}

function webauthn_store_credential($nickname, $credId, $coseKeyMap, $signCount) {
	$kty = $coseKeyMap[1] ?? null;
	$rec = [
		'nickname'  => $nickname,
		'credId'    => base64url_encode($credId),
		'signCount' => $signCount,
		'created'   => date('c'),
	];

	if ($kty == 2) {
		$rec['kty'] = 'EC2';
		$rec['crv'] = $coseKeyMap[-1];
		$rec['x']   = base64url_encode($coseKeyMap[-2]);
		$rec['y']   = base64url_encode($coseKeyMap[-3]);
	} elseif ($kty == 3) {
		$rec['kty'] = 'RSA';
		$rec['n']   = base64url_encode($coseKeyMap[-1]);
		$rec['e']   = base64url_encode($coseKeyMap[-2]);
	} else {
		throw new Exception('Unbekannter Schlüsseltyp beim Speichern');
	}

	$dir = dirname(PASSKEY_FILE);
	if (!is_dir($dir)) { mkdir($dir, 0755, true); }

	$handle = fopen(PASSKEY_FILE, 'a');
	if (flock($handle, LOCK_EX)) {
		fwrite($handle, json_encode($rec) . "\n");
		flock($handle, LOCK_UN);
	}
	fclose($handle);
}

function webauthn_update_sign_count($credIdB64, $newCount) {
	if (!file_exists(PASSKEY_FILE)) { return; }

	$handle = fopen(PASSKEY_FILE, 'c+');
	if (!flock($handle, LOCK_EX)) { fclose($handle); return; }

	$lines = [];
	while (($line = fgets($handle)) !== false) {
		$line = rtrim($line, "\n");
		if ($line === '') { continue; }
		$rec = json_decode($line, true);
		if ($rec && $rec['credId'] === $credIdB64) {
			$rec['signCount'] = $newCount;
		}
		if ($rec) { $lines[] = json_encode($rec); }
	}

	ftruncate($handle, 0);
	rewind($handle);
	fwrite($handle, implode("\n", $lines) . "\n");
	flock($handle, LOCK_UN);
	fclose($handle);
}

// rekonstruiert das COSE-Key-Array aus dem gespeicherten Record (für cose_key_to_pem)
function webauthn_record_to_cose($rec) {
	if ($rec['kty'] === 'EC2') {
		return [
			1  => 2,
			-1 => $rec['crv'],
			-2 => base64url_decode($rec['x']),
			-3 => base64url_decode($rec['y']),
		];
	}
	return [
		1  => 3,
		-1 => base64url_decode($rec['n']),
		-2 => base64url_decode($rec['e']),
	];
}


// ---------- Assertion (Login) komplett prüfen ----------
// $body = json_decode-tes Objekt von navigator.credentials.get(), vom Client gesendet:
//   ['id' => b64url, 'rawId' => b64url, 'response' => ['clientDataJSON'=>b64url,
//    'authenticatorData'=>b64url, 'signature'=>b64url, 'userHandle'=>b64url|null]]
// Gibt bei Erfolg ['nickname'=>..., 'credId'=>...] zurück, sonst false.

function webauthn_verify_assertion($body, $expectedChallengeB64, $expectedRpId, $expectedOrigin) {
	if (!isset($body['id'], $body['response']['clientDataJSON'], $body['response']['authenticatorData'], $body['response']['signature'])) {
		return false;
	}

	$credIdB64 = $body['id'];
	$rec = webauthn_find_credential_by_id($credIdB64);
	if (!$rec) { return false; }

	$clientDataJSON = base64url_decode($body['response']['clientDataJSON']);
	$authData = base64url_decode($body['response']['authenticatorData']);
	$signature = base64url_decode($body['response']['signature']);

	$clientData = json_decode($clientDataJSON, true);
	if (!$clientData || ($clientData['type'] ?? '') !== 'webauthn.get') { return false; }
	if (($clientData['challenge'] ?? '') !== $expectedChallengeB64) { return false; }
	if (rtrim($clientData['origin'] ?? '', '/') !== rtrim($expectedOrigin, '/')) { return false; }

	$parsed = webauthn_parse_auth_data($authData);

	$expectedRpIdHash = hash('sha256', $expectedRpId, true);
	if ($parsed['rpIdHash'] !== $expectedRpIdHash) { return false; }
	if (!$parsed['up']) { return false; }

	$coseKey = webauthn_record_to_cose($rec);
	$keyInfo = cose_key_to_pem($coseKey);

	$signedData = $authData . hash('sha256', $clientDataJSON, true);

	$ok = openssl_verify($signedData, $signature, $keyInfo['pem'], OPENSSL_ALGO_SHA256);
	if ($ok !== 1) { return false; }

	// Replay-/Clone-Schutz: manche Authenticator (v.a. iCloud-Keychain-Passkeys) liefern
	// dauerhaft signCount=0 - das ist laut Spec zulässig, dann einfach nicht prüfen.
	if ($parsed['signCount'] > 0 && $rec['signCount'] > 0 && $parsed['signCount'] <= $rec['signCount']) {
		return false;
	}
	webauthn_update_sign_count($credIdB64, $parsed['signCount']);

	return ['nickname' => $rec['nickname'], 'credId' => $credIdB64];
}
